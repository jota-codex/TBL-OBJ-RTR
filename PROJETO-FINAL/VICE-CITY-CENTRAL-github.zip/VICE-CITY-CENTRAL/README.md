<div align="center">

<img src="Assets/Images/logo.png" alt="Vice City Central" width="320"/>

# Vice City Central — GTA VI Management System

**Projeto Final de Programação Orientada a Objetos I**

Sistema desktop em **C# / .NET 8 (Windows Forms)** com banco de dados **SQLite**, inspirado no universo de *Grand Theft Auto VI*.
Uma central administrativa para gerenciar **personagens, veículos, missões e localidades** de Vice City e do estado de Leonida.

![C#](https://img.shields.io/badge/C%23-12-7B2FF7) ![.NET](https://img.shields.io/badge/.NET-8.0-FF2E88) ![SQLite](https://img.shields.io/badge/SQLite-3-22D3C5) ![WinForms](https://img.shields.io/badge/UI-Windows%20Forms-B388FF)

<img src="docs/screenshots/dashboard.png" alt="Dashboard" width="900"/>

</div>

---

## Sumário

1. [Descrição](#descrição)
2. [Objetivo](#objetivo)
3. [Tecnologias utilizadas](#tecnologias-utilizadas)
4. [Funcionalidades](#funcionalidades)
5. [Requisitos para execução](#requisitos-para-execução)
6. [Instalação](#instalação)
7. [Como executar](#como-executar)
8. [Estrutura das pastas](#estrutura-das-pastas)
9. [Arquitetura e Programação Orientada a Objetos](#arquitetura-e-programação-orientada-a-objetos)
10. [Banco de dados](#banco-de-dados)
11. [Experiência sonora](#experiência-sonora)
12. [Validações e tratamento de erros](#validações-e-tratamento-de-erros)
13. [Atendimento aos requisitos acadêmicos](#atendimento-aos-requisitos-acadêmicos)
14. [Imagens das telas](#imagens-das-telas)
15. [Integrantes do grupo](#integrantes-do-grupo)
16. [Créditos e aviso legal](#créditos-e-aviso-legal)

---

## Descrição

O **Vice City Central** simula o painel administrativo de uma organização que opera em Vice City. A interface usa tema escuro com tons de preto, grafite e roxo e detalhes em rosa neon, azul‑turquesa e lilás, com cards, gráficos, ícones e botões com efeito ao passar o mouse.

Todos os dados ficam gravados em um banco **SQLite** e permanecem salvos após fechar e abrir o programa.

## Objetivo

Aplicar os conceitos de **Programação Orientada a Objetos** (encapsulamento, herança, polimorfismo e abstração) em um sistema completo com interface gráfica, persistência em banco de dados, operações **CRUD**, validações e organização em camadas.

## Tecnologias utilizadas

| Tecnologia | Uso |
|---|---|
| **C# 12 / .NET 8** | Linguagem e plataforma |
| **Windows Forms** | Interface gráfica (controles próprios desenhados com GDI+) |
| **SQLite** + `Microsoft.Data.Sqlite` | Banco de dados local |
| **ADO.NET** | Acesso a dados com consultas parametrizadas |
| **Git / GitHub** | Versionamento |
| **Material Design Icons** | Ícones (licença Apache 2.0) |

## Funcionalidades

### Navegação
- Menu lateral (**sidebar**) com 6 itens: Dashboard, Personagens, Veículos, Missões, Localidades e Configurações.
- Cada item abre sua própria tela dentro da janela principal, sem sobrepor janelas.
- Atalhos de teclado: `Ctrl+1` … `Ctrl+6` (módulos), `Alt+←` (voltar), `Ctrl+M` (silenciar), `Ctrl+N` (novo), `Ctrl+S` (salvar), `Ctrl+E` (editar), `Delete` (excluir), `Esc` (cancelar), `Ctrl+F` (pesquisar), `F5` (atualizar).
- Ao sair de uma tela com alterações não salvas, o sistema pede confirmação.

### Dashboard
- Cards com **total de personagens, veículos, missões e localidades**, **missões concluídas** e **missões pendentes** (disponíveis + em andamento).
- **Gráfico de barras** de veículos por categoria e **gráfico de rosca** de missões por status.
- **Últimos registros adicionados** (clique para abrir o registro no módulo correspondente).
- **Atalhos** para cadastrar personagens, veículos, missões e localidades.
- **Data e hora** atualizadas automaticamente e atualização periódica dos indicadores (configurável).
- Todos os números são consultados no banco de dados.

### Módulos de cadastro (Personagens, Veículos, Missões e Localidades)
Cada módulo possui:
- Botões **Novo**, **Salvar**, **Editar**, **Excluir**, **Cancelar** e **Detalhes**.
- **Pesquisa por nome** (com atualização automática enquanto digita).
- **Filtros** específicos e botão **Limpar filtros**.
- **Listagem** com miniatura da imagem e status em destaque colorido.
- **Visualização detalhada** em janela própria (botão Detalhes, duplo clique ou `Enter`).
- **Imagem** do registro (Personagens, Veículos e Localidades): selecionar, trocar ou remover. A imagem escolhida é copiada para a pasta do sistema.

| Módulo | Campos | Pesquisa e filtros |
|---|---|---|
| **Personagens** | ID, nome, sobrenome, idade, gênero, profissão/ocupação, nacionalidade, descrição, status (Ativo/Inativo/Procurado), imagem | Nome; status |
| **Veículos** | ID, nome, fabricante fictício, modelo, categoria, ano, cor, velocidade máxima, tipo, status (Disponível/Em uso/Apreendido), imagem | Nome, modelo ou fabricante; categoria; status |
| **Missões** | ID, nome, descrição, personagem relacionado, localidade, categoria, dificuldade, recompensa fictícia, data de cadastro, status | Nome; categoria; dificuldade; status |
| **Localidades** | ID, nome, região, tipo de local, descrição, nível de perigo, status, imagem | Nome; região; tipo |

### Configurações
- Nome do sistema, versão, informações do projeto e créditos dos desenvolvedores.
- Preferências: nome do operador, segundos no relógio, atualização automática do Dashboard e intervalo, linhas alternadas nas listagens e notificações de sucesso.
- **Limpar filtros** de todas as telas.
- **Restaurar configurações padrão**.
- Abrir a pasta do banco e **restaurar o banco de dados inicial**.

## Requisitos para execução

- **Windows 10 ou 11** (Windows Forms é exclusivo do Windows).
- **[.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)** para compilar e executar.
- Opcional: **Visual Studio 2022** (17.8 ou superior) com a carga de trabalho *Desenvolvimento para desktop com .NET*.
- Conexão com a internet apenas na **primeira compilação**, para baixar o pacote `Microsoft.Data.Sqlite` do NuGet.

Não é necessário instalar o SQLite: a biblioteca nativa já vem no pacote NuGet.

## Instalação

```bash
git clone https://github.com/<seu-usuario>/VICE-CITY-CENTRAL.git
cd VICE-CITY-CENTRAL
dotnet restore
```

## Como executar

**Pelo terminal**

```bash
dotnet run --project ViceCityCentral.csproj
```

**Pelo Visual Studio**

1. Abra o arquivo `VICE-CITY-CENTRAL.sln`.
2. Pressione `F5` (ou *Depurar › Iniciar*).

**Gerar um executável para distribuir (opcional)**

```bash
dotnet publish ViceCityCentral.csproj -c Release -r win-x64 --self-contained true -o publicacao
```

O executável `publicacao/ViceCityCentral.exe` roda em computadores sem o .NET instalado. Copie a pasta inteira, porque ela inclui `Assets` e `Database`.

**Primeira execução:** o banco `Database/vice_city.db` é criado automaticamente, ao lado do executável, a partir do script `Database/vice_city.sql`, já com os dados iniciais. Para recomeçar do zero, use *Configurações › Restaurar banco de dados inicial* ou apague o arquivo `.db`.

## Estrutura das pastas

```
VICE-CITY-CENTRAL/
│
├── Assets/
│   ├── Images/            # logo e ilustrações dos personagens, veículos e localidades
│   │   ├── Personagens/
│   │   ├── Veiculos/
│   │   └── Localidades/
│   ├── Icons/             # ícones PNG (coloridos em tempo de execução) e app.ico
│   ├── Backgrounds/       # fundos da sidebar e do banner do Dashboard
│   └── Audio/
│       ├── music/         # 3 faixas originais (trilha ambiente)
│       └── ui/            # 16 efeitos sonoros originais
│
├── Audio/                 # motor de áudio
│   ├── AudioManager.cs        gerenciador central (música, efeitos, fades, prioridades)
│   ├── Backends.cs            IAudioBackend + implementação Windows (MCI/winmm) e silenciosa
│   ├── SomInterface.cs        catálogo de sons e regras de cada um
│   └── PreferenciasAudio.cs   preferências salvas no banco
│
├── Models/                # entidades e regras de validação (domínio)
│   ├── Interfaces.cs          IEntidade, IValidavel, IPossuiImagem, IDetalhavel
│   ├── EntidadeBase.cs        classe abstrata raiz
│   ├── EntidadeComImagem.cs   classe abstrata intermediária
│   ├── Personagem.cs · Veiculo.cs · Missao.cs · Localidade.cs
│   ├── Enums.cs · EnumExtensions.cs · Filtros.cs · Configuracoes.cs
│
├── Data/                  # infraestrutura do banco
│   ├── DatabaseConnection.cs      abre conexões (com chaves estrangeiras ativas)
│   ├── DatabaseInitializer.cs     cria/restaura o banco a partir do .sql
│   └── DataReaderExtensions.cs    leitura tipada das colunas
│
├── Repositories/          # acesso a dados (SQL) — um repositório por tabela
│   ├── IRepository.cs · RepositoryBase.cs
│   ├── PersonagemRepository.cs · VeiculoRepository.cs
│   ├── MissaoRepository.cs · LocalidadeRepository.cs · ConfiguracaoRepository.cs
│
├── Services/              # regras de negócio
│   ├── ServiceBase.cs
│   ├── PersonagemService.cs · VeiculoService.cs · MissaoService.cs · LocalidadeService.cs
│   ├── DashboardService.cs · ConfiguracaoService.cs · ImagemService.cs
│   └── AppInfo.cs · RegistroErros.cs
│
├── Exceptions/            # ValidacaoException, RegraNegocioException, DatabaseException
│
├── Views/                 # interface gráfica
│   ├── MainForm.cs                janela principal + sidebar
│   ├── ModuloBaseForm.cs          base de todas as telas
│   ├── ModuloCrudForm.cs          tela de cadastro genérica (CRUD)
│   ├── DashboardForm.cs · PersonagensForm.cs · VeiculosForm.cs
│   ├── MissoesForm.cs · LocalidadesForm.cs · ConfiguracoesForm.cs
│   ├── DetalhesForm.cs            visualização detalhada
│   ├── Components/                botões neon, cards, gráficos, diálogos, campos
│   └── Theme/                     paleta, tipografia e carregamento de recursos
│
├── Database/
│   └── vice_city.sql      # estrutura + dados iniciais (usado para criar o banco)
│
├── tools/audio/           # script que gera (sintetiza) todos os áudios originais
├── docs/screenshots/      # imagens das telas
├── Program.cs
├── ViceCityCentral.csproj
├── VICE-CITY-CENTRAL.sln
└── README.md
```

## Arquitetura e Programação Orientada a Objetos

O código é separado em camadas. A interface **não** acessa o banco diretamente:

```
Views (Forms)  →  Services (regras de negócio)  →  Repositories (SQL)  →  Data (conexão)  →  SQLite
        ↘──────────────── Models (entidades e validações) ────────────────↙
```

### Encapsulamento
- Propriedades com **campos privados** e setters que **normalizam** os dados (remoção de espaços extras).
- Setters que **protegem o estado**: `Personagem.Idade`, `Veiculo.VelocidadeMaxima` e `Missao.Recompensa` rejeitam valores negativos; `EntidadeBase.Id` não aceita IDs negativos.
- Detalhes internos das telas (estado de edição, imagem pendente etc.) ficam privados na classe base.

### Herança
```
EntidadeBase (abstrata)
├── EntidadeComImagem (abstrata)  → Personagem, Veiculo, Localidade
└── Missao

RepositoryBase<T> (abstrata)  → PersonagemRepository, VeiculoRepository, MissaoRepository, LocalidadeRepository
ServiceBase<T> (abstrata)     → PersonagemService, VeiculoService, MissaoService, LocalidadeService
ModuloBaseForm (abstrata)     → DashboardForm, ConfiguracoesForm, ModuloCrudForm<T>
ModuloCrudForm<T> (abstrata)  → PersonagensForm, VeiculosForm, MissoesForm, LocalidadesForm
GraficoBase (abstrata)        → GraficoBarras, GraficoRosca
```
A herança elimina código repetido. Por exemplo, as quatro telas de cadastro compartilham layout, pesquisa, botões, estados (novo/editando/visualizando), imagem e tratamento de erros em `ModuloCrudForm<T>`.

### Polimorfismo
- `Validar()` → cada entidade sobrescreve `ValidarCampos()` com suas regras (ex.: categoria *Barcos* exige tipo *Aquático*; missão *Concluída* exige um personagem).
- `ObterDetalhes()` → cada entidade estende a lista da classe base (uso de `base.ObterDetalhes()`); a **mesma** `DetalhesForm` exibe qualquer entidade.
- `Titulo`, `Subtitulo`, `StatusDescricao` e `NivelStatus` → o Dashboard mostra os **últimos registros** em uma única lista de `EntidadeBase` com personagens, veículos, missões e localidades juntos, cada um se descrevendo à sua maneira.
- `ServiceBase.VerificarPossibilidadeExclusao()` → Personagem e Localidade impedem a exclusão quando existem missões vinculadas.
- `RepositoryBase` (*Template Method*) → as classes derivadas fornecem apenas o SQL e o mapeamento das colunas.
- `GraficoBase.Desenhar()` → barras e rosca desenham-se de forma diferente sobre a mesma base.

### Abstração
- **Interfaces**: `IEntidade`, `IValidavel`, `IPossuiImagem`, `IDetalhavel`, `IRepository<T>` e `IModuloView` (contrato entre a janela principal e as telas).
- **Classes abstratas**: `EntidadeBase`, `EntidadeComImagem`, `RepositoryBase<T>`, `ServiceBase<T>`, `ModuloBaseForm`, `ModuloCrudForm<T>` e `GraficoBase`.

## Banco de dados

O script [`Database/vice_city.sql`](Database/vice_city.sql) contém a estrutura completa e os dados iniciais (9 personagens, 10 veículos, 10 localidades e 10 missões). Ele pode ser executado manualmente com `sqlite3 vice_city.db < Database/vice_city.sql`.

```mermaid
erDiagram
    Personagens ||--o{ Missoes : "participa de"
    Localidades ||--o{ Missoes : "acontece em"

    Personagens {
        INTEGER Id PK
        TEXT Nome
        TEXT Sobrenome
        INTEGER Idade
        TEXT Genero
        TEXT Profissao
        TEXT Nacionalidade
        TEXT Descricao
        TEXT Status
        TEXT ImagemPath
        TEXT DataCadastro
    }
    Veiculos {
        INTEGER Id PK
        TEXT Nome
        TEXT Fabricante
        TEXT Modelo
        TEXT Categoria
        INTEGER Ano
        TEXT Cor
        INTEGER VelocidadeMaxima
        TEXT Tipo
        TEXT Status
        TEXT ImagemPath
        TEXT DataCadastro
    }
    Missoes {
        INTEGER Id PK
        TEXT Nome
        TEXT Descricao
        INTEGER PersonagemId FK
        INTEGER LocalidadeId FK
        TEXT Categoria
        TEXT Dificuldade
        REAL Recompensa
        TEXT Status
        TEXT DataCadastro
    }
    Localidades {
        INTEGER Id PK
        TEXT Nome
        TEXT Regiao
        TEXT Tipo
        TEXT Descricao
        TEXT NivelPerigo
        TEXT Status
        TEXT ImagemPath
        TEXT DataCadastro
    }
```

**Integridade referencial**
- `Missoes.PersonagemId → Personagens.Id` e `Missoes.LocalidadeId → Localidades.Id` com `ON DELETE RESTRICT`: não é possível excluir um personagem ou uma localidade que tenha missões vinculadas.
- `PRAGMA foreign_keys = ON` em todas as conexões.
- Restrições `CHECK` para valores permitidos (status, categorias, idade, velocidade, recompensa) e `UNIQUE` (sem diferenciar maiúsculas/minúsculas) contra duplicidades.
- Uma tabela auxiliar `Configuracoes` (chave/valor) guarda as preferências do usuário.

## Experiência sonora

Toda a navegação tem som: uma trilha ambiente de Vice City e um efeito próprio para cada tipo de interação. O áudio é integrado sem alterar o funcionamento dos botões: os efeitos são ligados aos controles por eventos (`Views/Components/AudioHooks.cs`), inclusive nos componentes criados depois que a tela abre.

<img src="docs/screenshots/audio.png" alt="Painel de áudio" width="760"/>

**Entrada**
1. O sistema abre normalmente, sem som e sem atraso.
2. No rodapé do menu lateral aparece a opção discreta **Ativar experiência sonora**.
3. Ao ativar, toca um efeito cinematográfico de entrada. A trilha começa cerca de 1,2 s depois, com fade-in gradual de 5 s, e os efeitos de navegação são liberados.
4. Nas próximas vezes, a experiência começa sozinha na primeira interação (clique ou tecla), como fazem os navegadores com o *autoplay*.

**Trilha sonora:** 3 faixas instrumentais **originais**. A primeira é um rock suave retrô, com guitarras dedilhadas e piano elétrico; as outras misturam synthwave, batida hip-hop e sons tropicais. Elas tocam em sequência e em loop infinito, com **crossfade de 6 s** entre as faixas. O volume inicial é **20%**. A música não reinicia nem para ao trocar de tela e abaixa um pouco (*ducking*) quando toca um efeito importante.

| Interação | Efeito (`Assets/Audio/ui`) |
|---|---|
| Passar o mouse sobre botões e itens do menu | `button-hover.mp3` |
| Clique em botões | `button-click.mp3` |
| Abrir menus (listas suspensas, painel de áudio) | `menu-open.mp3` |
| Fechar menus e janelas | `menu-close.mp3` |
| Trocar de tela | `page-transition.mp3` |
| Selecionar opção, linha ou interruptor | `select.mp3` |
| Voltar à tela anterior (`Alt+←` ou botão voltar do mouse) | `navigate-back.mp3` |
| Abrir janelas e modais (Detalhes, confirmações) | `modal-open.mp3` |
| Confirmar uma ação | `confirm.mp3` |
| Cancelar uma ação | `cancel.mp3` |
| Salvar informações | `success.mp3` |
| Excluir informações (alerta da confirmação) | `delete.mp3` |
| Erros e validações | `error.mp3` |
| Avisos e notificações | `notification.mp3` |
| Carregamento (`F5`, atualizar indicadores, restaurar banco) | `loading.mp3` |
| Entrada no sistema | `login.mp3` |

**Controles de áudio:** ficam no rodapé do menu lateral (alto-falante, música e ajustes) e permitem:
- ativar e desativar a música e os efeitos separadamente;
- ajustar o volume de cada um;
- ligar o modo silencioso (`Ctrl+M`);
- pular para a próxima faixa.

As preferências ficam salvas no banco (tabela `Configuracoes`) e valem nas próximas visitas.

**Detalhes técnicos**
- `AudioManager` é o ponto central e único que toca sons. Ele aplica:
  - debounce por tipo de som;
  - prioridades: um som mais importante corta, com fade, o menos importante que acabou de tocar, e um clique logo após "salvo" é descartado;
  - limite de 3 efeitos simultâneos.
- Os efeitos mais frequentes são pré-carregados aos poucos, um por ciclo, para não travar a interface. Os demais e as faixas só são abertos quando vão tocar.
- **Erros de áudio:** um arquivo ausente ou corrompido é ignorado e registrado em `logs/erros.log`, e os outros sons continuam funcionando. Sem placa de som, o sistema segue em silêncio, sem erros.
- **Como o som é tocado:** pela MCI do Windows (`winmm.dll`), que reproduz MP3 sem dependências extras. A interface `IAudioBackend` permite trocar a implementação; os testes automatizados usam um backend simulado.

**Direitos autorais:** todas as músicas e efeitos foram **compostos e sintetizados especialmente para este projeto** pelo script [`tools/audio/gerar_audio.py`](tools/audio/gerar_audio.py), com osciladores, ruído e síntese FM. Não há samples de terceiros nem trechos de músicas comerciais. **Não são trilhas oficiais do GTA VI**, apenas inspiradas na atmosfera de Vice City. Para regerar: `python tools/audio/gerar_audio.py Assets/Audio` e depois `python tools/audio/gerar_audio_v2.py Assets/Audio`, que gera os efeitos atuais e a faixa retrô (requer numpy, scipy e ffmpeg).

## Validações e tratamento de erros

| Situação | Comportamento |
|---|---|
| Campos obrigatórios vazios | Lista com todos os campos pendentes |
| Texto em campo numérico | Digitação bloqueada; valores colados são validados |
| Idade, velocidade ou recompensa negativas | Bloqueadas pelo encapsulamento da entidade |
| Faixas inválidas (idade 1–120, ano 1900–ano seguinte, velocidade 1–800 km/h) | Mensagem explicativa |
| Registro duplicado | Bloqueado no serviço e no banco (`UNIQUE`) |
| Exclusão | Sempre pede confirmação |
| Exclusão de registro com vínculos | Mensagem informando quantas missões estão vinculadas |
| Cadastro ou atualização bem-sucedidos | Notificação de sucesso |
| Falha de conexão ou arquivo do banco ausente | Mensagem clara (e registro em `logs/erros.log`) |
| Imagem inválida (formato ou > 10 MB) | Mensagem explicativa |
| Erro inesperado | Capturado globalmente, exibido de forma amigável e registrado em log |

## Atendimento aos requisitos acadêmicos

| Requisito | Onde |
|---|---|
| Sistema em C# com interface gráfica | .NET 8 + Windows Forms |
| Individual ou em grupo de até 5 integrantes | Ver [Integrantes](#integrantes-do-grupo) |
| Projeto em repositório Git, com código e imagens | Este repositório (`Assets/`) |
| Arquivo `.sql` do banco de dados | `Database/vice_city.sql` |
| CRUD completo (Create, Read, Update, Delete) | Personagens, Veículos, Missões e Localidades |
| Menu com pelo menos 4 itens | Sidebar com 6 itens |
| Cada item abre uma tela diferente | 6 telas: Dashboard, Personagens, Veículos, Missões, Localidades e Configurações |
| Pelo menos 4 telas novas além da principal | 6 telas + janela de detalhes |

## Imagens das telas

| Dashboard | Personagens |
|---|---|
| ![Dashboard](docs/screenshots/dashboard.png) | ![Personagens](docs/screenshots/personagens.png) |
| **Cadastro de personagem** | **Detalhes** |
| ![Cadastro](docs/screenshots/personagem_cadastro.png) | ![Detalhes](docs/screenshots/detalhes.png) |
| **Veículos** | **Missões** |
| ![Veículos](docs/screenshots/veiculos.png) | ![Missões](docs/screenshots/missoes.png) |
| **Localidades** | **Configurações** |
| ![Localidades](docs/screenshots/localidades.png) | ![Configurações](docs/screenshots/configuracoes.png) |
| **Validação de campos** | |
| ![Validação](docs/screenshots/validacao.png) | |

> As capturas foram geradas em ambiente de testes. No Windows, o sistema usa as fontes *Segoe UI* e *Bahnschrift*, então a tipografia pode variar um pouco.

## Integrantes do grupo

| Nome | RA | GitHub |
|---|---|---|
| Integrante 1 | 000000 | @usuario |
| Integrante 2 | 000000 | @usuario |
| Integrante 3 | 000000 | @usuario |

> Atualize também a lista `AppInfo.Desenvolvedores` em `Services/AppInfo.cs`, exibida na tela de Configurações.

## Créditos e aviso legal

- Projeto acadêmico, sem fins lucrativos, desenvolvido para a disciplina de Programação Orientada a Objetos I.
- *Grand Theft Auto*, *GTA VI*, *Vice City* e *Leonida* são marcas da **Rockstar Games / Take-Two Interactive**. Este projeto não tem relação com essas empresas.
- Todas as ilustrações, o logotipo e os fundos foram **criados especialmente para este projeto** (arte original em estilo *synthwave*). Nenhuma imagem oficial do jogo foi usada. O usuário pode cadastrar imagens próprias pelo sistema, desde que tenha o direito de usá-las.
- Ícones: [Material Design Icons](https://pictogrammers.com/library/mdi/) — licença Apache 2.0.
- Músicas e efeitos sonoros: composições originais sintetizadas para o projeto (ver [Experiência sonora](#experiência-sonora)).
- Os nomes de personagens, veículos e locais fazem referência ao universo do jogo; idades, descrições, valores e missões são fictícios.
