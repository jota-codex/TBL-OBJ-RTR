using System;
using System.Collections.Generic;
using System.Data.Common;
using ViceCityCentral.Data;
using ViceCityCentral.Models;

namespace ViceCityCentral.Repositories
{
    public class VeiculoRepository : RepositoryBase<Veiculo>
    {
        protected override string Tabela => "Veiculos";

        protected override string SqlInsert =>
            @"INSERT INTO Veiculos (Nome, Fabricante, Modelo, Categoria, Ano, Cor, VelocidadeMaxima, Tipo, Status, ImagemPath, DataCadastro)
              VALUES (@Nome, @Fabricante, @Modelo, @Categoria, @Ano, @Cor, @VelocidadeMaxima, @Tipo, @Status, @ImagemPath, @DataCadastro);";

        protected override string SqlUpdate =>
            @"UPDATE Veiculos SET Nome = @Nome, Fabricante = @Fabricante, Modelo = @Modelo, Categoria = @Categoria,
                     Ano = @Ano, Cor = @Cor, VelocidadeMaxima = @VelocidadeMaxima, Tipo = @Tipo, Status = @Status,
                     ImagemPath = @ImagemPath, DataCadastro = @DataCadastro
              WHERE Id = @Id;";

        protected override Veiculo Mapear(DbDataReader r) => new Veiculo
        {
            Id = r.Inteiro("Id"),
            Nome = r.Texto("Nome"),
            Fabricante = r.Texto("Fabricante"),
            Modelo = r.Texto("Modelo"),
            Categoria = EnumExtensions.Converter(r.Texto("Categoria"), CategoriaVeiculo.Outros),
            Ano = r.Inteiro("Ano"),
            Cor = r.Texto("Cor"),
            VelocidadeMaxima = Math.Max(0, r.Inteiro("VelocidadeMaxima")),
            Tipo = EnumExtensions.Converter(r.Texto("Tipo"), TipoVeiculo.Terrestre),
            Status = EnumExtensions.Converter(r.Texto("Status"), StatusVeiculo.Disponivel),
            ImagemPath = r.TextoOuNulo("ImagemPath"),
            DataCadastro = r.Data("DataCadastro")
        };

        protected override void PreencherParametros(DbCommand cmd, Veiculo v)
        {
            Parametro(cmd, "@Nome", v.Nome);
            Parametro(cmd, "@Fabricante", v.Fabricante);
            Parametro(cmd, "@Modelo", v.Modelo);
            Parametro(cmd, "@Categoria", v.Categoria.ToString());
            Parametro(cmd, "@Ano", v.Ano);
            Parametro(cmd, "@Cor", v.Cor);
            Parametro(cmd, "@VelocidadeMaxima", v.VelocidadeMaxima);
            Parametro(cmd, "@Tipo", v.Tipo.ToString());
            Parametro(cmd, "@Status", v.Status.ToString());
            Parametro(cmd, "@ImagemPath", v.ImagemPath);
        }

        public List<Veiculo> Pesquisar(FiltroVeiculo filtro)
        {
            var condicoes = new List<string>();
            var parametros = new List<(string, object?)>();

            if (!string.IsNullOrWhiteSpace(filtro.Texto))
            {
                condicoes.Add(@"(Nome LIKE @Texto ESCAPE '\' OR Modelo LIKE @Texto ESCAPE '\' OR Fabricante LIKE @Texto ESCAPE '\')");
                parametros.Add(("@Texto", Like(filtro.Texto!)));
            }
            if (filtro.Categoria.HasValue)
            {
                condicoes.Add("Categoria = @Categoria");
                parametros.Add(("@Categoria", filtro.Categoria.Value.ToString()));
            }
            if (filtro.Status.HasValue)
            {
                condicoes.Add("Status = @Status");
                parametros.Add(("@Status", filtro.Status.Value.ToString()));
            }

            string where = condicoes.Count > 0 ? " WHERE " + string.Join(" AND ", condicoes) : string.Empty;
            return Consultar($"{SqlSelect}{where} ORDER BY Fabricante COLLATE NOCASE, Nome COLLATE NOCASE;", parametros.ToArray());
        }

        public bool ExisteVeiculo(string fabricante, string nome, string modelo, int ignorarId)
        {
            object? total = Escalar(
                @"SELECT COUNT(*) FROM Veiculos
                  WHERE Fabricante = @Fabricante COLLATE NOCASE AND Nome = @Nome COLLATE NOCASE
                    AND Modelo = @Modelo COLLATE NOCASE AND Id <> @Id;",
                ("@Fabricante", fabricante), ("@Nome", nome), ("@Modelo", modelo), ("@Id", ignorarId));
            return Convert.ToInt32(total) > 0;
        }

        /// <summary>Quantidade de veículos em cada categoria (inclui categorias vazias).</summary>
        public Dictionary<CategoriaVeiculo, int> ContarPorCategoria()
        {
            var brutos = ContarAgrupado("SELECT Categoria, COUNT(*) FROM Veiculos GROUP BY Categoria;");
            var resultado = new Dictionary<CategoriaVeiculo, int>();
            foreach (var opcao in EnumExtensions.ListarOpcoes<CategoriaVeiculo>())
                resultado[opcao.Valor] = brutos.TryGetValue(opcao.Valor.ToString(), out int qtd) ? qtd : 0;
            return resultado;
        }
    }
}
