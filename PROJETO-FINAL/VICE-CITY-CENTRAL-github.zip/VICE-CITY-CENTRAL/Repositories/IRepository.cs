using System.Collections.Generic;
using ViceCityCentral.Models;

namespace ViceCityCentral.Repositories
{
    /// <summary>Contrato genérico de persistência (CRUD) para qualquer entidade.</summary>
    public interface IRepository<T> where T : EntidadeBase
    {
        List<T> ObterTodos();
        T? ObterPorId(int id);
        List<T> ObterUltimos(int quantidade);
        int Inserir(T entidade);
        void Atualizar(T entidade);
        void Excluir(int id);
        int Contar();
    }
}
