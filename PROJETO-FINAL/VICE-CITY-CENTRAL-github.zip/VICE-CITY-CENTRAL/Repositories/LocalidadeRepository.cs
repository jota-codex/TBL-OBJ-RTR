using System;
using System.Collections.Generic;
using System.Data.Common;
using ViceCityCentral.Data;
using ViceCityCentral.Models;

namespace ViceCityCentral.Repositories
{
    public class LocalidadeRepository : RepositoryBase<Localidade>
    {
        protected override string Tabela => "Localidades";

        protected override string SqlInsert =>
            @"INSERT INTO Localidades (Nome, Regiao, Tipo, Descricao, NivelPerigo, Status, ImagemPath, DataCadastro)
              VALUES (@Nome, @Regiao, @Tipo, @Descricao, @NivelPerigo, @Status, @ImagemPath, @DataCadastro);";

        protected override string SqlUpdate =>
            @"UPDATE Localidades SET Nome = @Nome, Regiao = @Regiao, Tipo = @Tipo, Descricao = @Descricao,
                     NivelPerigo = @NivelPerigo, Status = @Status, ImagemPath = @ImagemPath, DataCadastro = @DataCadastro
              WHERE Id = @Id;";

        protected override Localidade Mapear(DbDataReader r) => new Localidade
        {
            Id = r.Inteiro("Id"),
            Nome = r.Texto("Nome"),
            Regiao = r.Texto("Regiao"),
            Tipo = EnumExtensions.Converter(r.Texto("Tipo"), TipoLocalidade.Outros),
            Descricao = r.Texto("Descricao"),
            NivelPerigo = EnumExtensions.Converter(r.Texto("NivelPerigo"), NivelPerigo.Baixo),
            Status = EnumExtensions.Converter(r.Texto("Status"), StatusLocalidade.Liberada),
            ImagemPath = r.TextoOuNulo("ImagemPath"),
            DataCadastro = r.Data("DataCadastro")
        };

        protected override void PreencherParametros(DbCommand cmd, Localidade l)
        {
            Parametro(cmd, "@Nome", l.Nome);
            Parametro(cmd, "@Regiao", l.Regiao);
            Parametro(cmd, "@Tipo", l.Tipo.ToString());
            Parametro(cmd, "@Descricao", l.Descricao);
            Parametro(cmd, "@NivelPerigo", l.NivelPerigo.ToString());
            Parametro(cmd, "@Status", l.Status.ToString());
            Parametro(cmd, "@ImagemPath", l.ImagemPath);
        }

        public List<Localidade> Pesquisar(FiltroLocalidade filtro)
        {
            var condicoes = new List<string>();
            var parametros = new List<(string, object?)>();

            if (!string.IsNullOrWhiteSpace(filtro.Texto))
            {
                condicoes.Add(@"Nome LIKE @Texto ESCAPE '\'");
                parametros.Add(("@Texto", Like(filtro.Texto!)));
            }
            if (!string.IsNullOrWhiteSpace(filtro.Regiao))
            {
                condicoes.Add("Regiao = @Regiao COLLATE NOCASE");
                parametros.Add(("@Regiao", filtro.Regiao));
            }
            if (filtro.Tipo.HasValue)
            {
                condicoes.Add("Tipo = @Tipo");
                parametros.Add(("@Tipo", filtro.Tipo.Value.ToString()));
            }

            string where = condicoes.Count > 0 ? " WHERE " + string.Join(" AND ", condicoes) : string.Empty;
            return Consultar($"{SqlSelect}{where} ORDER BY Nome COLLATE NOCASE;", parametros.ToArray());
        }

        public bool ExisteNome(string nome, int ignorarId)
            => Convert.ToInt32(Escalar("SELECT COUNT(*) FROM Localidades WHERE Nome = @Nome COLLATE NOCASE AND Id <> @Id;",
                ("@Nome", nome), ("@Id", ignorarId))) > 0;

        /// <summary>Regiões distintas cadastradas (para o filtro).</summary>
        public List<string> ListarRegioes()
        {
            var regioes = ContarAgrupado("SELECT Regiao, COUNT(*) FROM Localidades GROUP BY Regiao COLLATE NOCASE ORDER BY Regiao COLLATE NOCASE;");
            return new List<string>(regioes.Keys);
        }

        public int ContarMissoesVinculadas(int localidadeId)
            => Convert.ToInt32(Escalar("SELECT COUNT(*) FROM Missoes WHERE LocalidadeId = @Id;", ("@Id", localidadeId)));
    }
}
