using System;
using System.Collections.Generic;
using ViceCityCentral.Data;
using ViceCityCentral.Exceptions;

namespace ViceCityCentral.Repositories
{
    /// <summary>Acesso à tabela chave/valor de configurações.</summary>
    public class ConfiguracaoRepository
    {
        public Dictionary<string, string> CarregarTodas()
        {
            var valores = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                using (var conexao = DatabaseConnection.Abrir())
                using (var cmd = conexao.CreateCommand())
                {
                    cmd.CommandText = "SELECT Chave, Valor FROM Configuracoes;";
                    using (var r = cmd.ExecuteReader())
                        while (r.Read()) valores[r.Texto("Chave")] = r.Texto("Valor");
                }
            }
            catch (System.Data.Common.DbException ex)
            {
                throw new DatabaseException("Não foi possível ler as configurações: " + ex.Message, ex);
            }
            return valores;
        }

        public void SalvarTodas(IDictionary<string, string> valores)
        {
            try
            {
                using (var conexao = DatabaseConnection.Abrir())
                using (var transacao = conexao.BeginTransaction())
                {
                    foreach (var item in valores)
                    {
                        using (var cmd = conexao.CreateCommand())
                        {
                            cmd.Transaction = transacao;
                            cmd.CommandText = "INSERT OR REPLACE INTO Configuracoes (Chave, Valor) VALUES (@Chave, @Valor);";
                            var p1 = cmd.CreateParameter(); p1.ParameterName = "@Chave"; p1.Value = item.Key; cmd.Parameters.Add(p1);
                            var p2 = cmd.CreateParameter(); p2.ParameterName = "@Valor"; p2.Value = item.Value; cmd.Parameters.Add(p2);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    transacao.Commit();
                }
            }
            catch (System.Data.Common.DbException ex)
            {
                throw new DatabaseException("Não foi possível salvar as configurações: " + ex.Message, ex);
            }
        }
    }
}
