using System;
using System.Collections.Generic;
using System.Data.Common;
using ViceCityCentral.Data;
using ViceCityCentral.Exceptions;
using ViceCityCentral.Models;

namespace ViceCityCentral.Repositories
{
    /// <summary>
    /// Implementação base (Template Method) do CRUD com ADO.NET.
    /// As classes derivadas informam apenas o SQL específico e como mapear as colunas.
    /// </summary>
    public abstract class RepositoryBase<T> : IRepository<T> where T : EntidadeBase
    {
        /// <summary>Nome da tabela no banco.</summary>
        protected abstract string Tabela { get; }

        /// <summary>Prefixo de alias usado no SELECT (ex.: "m." quando há JOIN).</summary>
        protected virtual string Alias => string.Empty;

        /// <summary>SELECT base (sem WHERE/ORDER BY).</summary>
        protected virtual string SqlSelect => $"SELECT * FROM {Tabela}";

        /// <summary>Ordenação padrão das listagens.</summary>
        protected virtual string OrdemPadrao => $"{Alias}Nome COLLATE NOCASE";

        /// <summary>INSERT parametrizado.</summary>
        protected abstract string SqlInsert { get; }

        /// <summary>UPDATE parametrizado (deve usar @Id no WHERE).</summary>
        protected abstract string SqlUpdate { get; }

        /// <summary>Converte uma linha do resultado em objeto.</summary>
        protected abstract T Mapear(DbDataReader leitor);

        /// <summary>Adiciona os parâmetros de INSERT/UPDATE.</summary>
        protected abstract void PreencherParametros(DbCommand comando, T entidade);

        // ------------------------------------------------------------------ CRUD

        public List<T> ObterTodos() => Consultar($"{SqlSelect} ORDER BY {OrdemPadrao};");

        public T? ObterPorId(int id)
        {
            var lista = Consultar($"{SqlSelect} WHERE {Alias}Id = @Id;", ("@Id", id));
            return lista.Count > 0 ? lista[0] : null;
        }

        public List<T> ObterUltimos(int quantidade)
            => Consultar($"{SqlSelect} ORDER BY {Alias}DataCadastro DESC, {Alias}Id DESC LIMIT @Qtd;", ("@Qtd", quantidade));

        public int Inserir(T entidade)
        {
            return Executar(conexao =>
            {
                using (var cmd = conexao.CreateCommand())
                {
                    cmd.CommandText = SqlInsert + " SELECT last_insert_rowid();";
                    PreencherParametros(cmd, entidade);
                    Parametro(cmd, "@DataCadastro", entidade.DataCadastro.ParaBanco());
                    int id = Convert.ToInt32(cmd.ExecuteScalar());
                    entidade.Id = id;
                    return id;
                }
            });
        }

        public void Atualizar(T entidade)
        {
            int afetados = Executar(conexao =>
            {
                using (var cmd = conexao.CreateCommand())
                {
                    cmd.CommandText = SqlUpdate;
                    PreencherParametros(cmd, entidade);
                    Parametro(cmd, "@Id", entidade.Id);
                    Parametro(cmd, "@DataCadastro", entidade.DataCadastro.ParaBanco());
                    return cmd.ExecuteNonQuery();
                }
            });
            if (afetados == 0)
                throw new RegraNegocioException($"O registro #{entidade.Id} não foi encontrado. Ele pode ter sido excluído.");
        }

        public void Excluir(int id)
        {
            int afetados = ExecutarComando($"DELETE FROM {Tabela} WHERE Id = @Id;", ("@Id", id));
            if (afetados == 0)
                throw new RegraNegocioException($"O registro #{id} não foi encontrado. Ele pode já ter sido excluído.");
        }

        public int Contar() => Convert.ToInt32(Escalar($"SELECT COUNT(*) FROM {Tabela};"));

        // ------------------------------------------------------------ utilitários

        protected List<T> Consultar(string sql, params (string Nome, object? Valor)[] parametros)
        {
            return Executar(conexao =>
            {
                var lista = new List<T>();
                using (var cmd = conexao.CreateCommand())
                {
                    cmd.CommandText = sql;
                    foreach (var p in parametros) Parametro(cmd, p.Nome, p.Valor);
                    using (var leitor = cmd.ExecuteReader())
                    {
                        while (leitor.Read()) lista.Add(Mapear(leitor));
                    }
                }
                return lista;
            });
        }

        protected object? Escalar(string sql, params (string Nome, object? Valor)[] parametros)
        {
            return Executar(conexao =>
            {
                using (var cmd = conexao.CreateCommand())
                {
                    cmd.CommandText = sql;
                    foreach (var p in parametros) Parametro(cmd, p.Nome, p.Valor);
                    object? valor = cmd.ExecuteScalar();
                    return valor == DBNull.Value ? null : valor;
                }
            });
        }

        protected int ExecutarComando(string sql, params (string Nome, object? Valor)[] parametros)
        {
            return Executar(conexao =>
            {
                using (var cmd = conexao.CreateCommand())
                {
                    cmd.CommandText = sql;
                    foreach (var p in parametros) Parametro(cmd, p.Nome, p.Valor);
                    return cmd.ExecuteNonQuery();
                }
            });
        }

        /// <summary>Lê pares (texto, quantidade) de uma consulta GROUP BY.</summary>
        protected Dictionary<string, int> ContarAgrupado(string sql)
        {
            return Executar(conexao =>
            {
                var resultado = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                using (var cmd = conexao.CreateCommand())
                {
                    cmd.CommandText = sql;
                    using (var leitor = cmd.ExecuteReader())
                    {
                        while (leitor.Read())
                            resultado[Convert.ToString(leitor.GetValue(0)) ?? ""] = Convert.ToInt32(leitor.GetValue(1));
                    }
                }
                return resultado;
            });
        }

        protected static void Parametro(DbCommand cmd, string nome, object? valor)
        {
            var p = cmd.CreateParameter();
            p.ParameterName = nome;
            p.Value = valor ?? DBNull.Value;
            cmd.Parameters.Add(p);
        }

        /// <summary>Prepara o texto para uma busca com LIKE (escapa curingas).</summary>
        protected static string Like(string texto)
            => "%" + texto.Trim().Replace("\\", "\\\\").Replace("%", "\\%").Replace("_", "\\_") + "%";

        /// <summary>
        /// Abre a conexão, executa a ação e traduz erros do SQLite para exceções do sistema.
        /// </summary>
        protected static TResultado Executar<TResultado>(Func<DbConnection, TResultado> acao)
        {
            try
            {
                using (var conexao = DatabaseConnection.Abrir())
                {
                    return acao(conexao);
                }
            }
            catch (DbException ex)
            {
                string msg = ex.Message ?? string.Empty;
                if (msg.IndexOf("UNIQUE", StringComparison.OrdinalIgnoreCase) >= 0)
                    throw new RegraNegocioException("Já existe um registro cadastrado com esses dados.");
                if (msg.IndexOf("FOREIGN KEY", StringComparison.OrdinalIgnoreCase) >= 0)
                    throw new RegraNegocioException("A operação viola a integridade referencial: existem registros vinculados.");
                if (msg.IndexOf("CHECK", StringComparison.OrdinalIgnoreCase) >= 0)
                    throw new RegraNegocioException("Um dos valores informados não é aceito pelo banco de dados.");
                throw new DatabaseException("Erro ao acessar o banco de dados: " + msg, ex);
            }
        }
    }
}
