using System;
using System.Collections.Generic;
using System.Data.Common;
using ViceCityCentral.Data;
using ViceCityCentral.Models;

namespace ViceCityCentral.Repositories
{
    public class MissaoRepository : RepositoryBase<Missao>
    {
        protected override string Tabela => "Missoes";
        protected override string Alias => "m.";

        // JOIN para trazer o nome do personagem e da localidade relacionados.
        protected override string SqlSelect =>
            @"SELECT m.*,
                     (p.Nome || ' ' || p.Sobrenome) AS NomePersonagem,
                     l.Nome AS NomeLocalidade
              FROM Missoes m
              LEFT JOIN Personagens p ON p.Id = m.PersonagemId
              LEFT JOIN Localidades l ON l.Id = m.LocalidadeId";

        protected override string SqlInsert =>
            @"INSERT INTO Missoes (Nome, Descricao, PersonagemId, LocalidadeId, Categoria, Dificuldade, Recompensa, Status, DataCadastro)
              VALUES (@Nome, @Descricao, @PersonagemId, @LocalidadeId, @Categoria, @Dificuldade, @Recompensa, @Status, @DataCadastro);";

        protected override string SqlUpdate =>
            @"UPDATE Missoes SET Nome = @Nome, Descricao = @Descricao, PersonagemId = @PersonagemId,
                     LocalidadeId = @LocalidadeId, Categoria = @Categoria, Dificuldade = @Dificuldade,
                     Recompensa = @Recompensa, Status = @Status, DataCadastro = @DataCadastro
              WHERE Id = @Id;";

        protected override Missao Mapear(DbDataReader r) => new Missao
        {
            Id = r.Inteiro("Id"),
            Nome = r.Texto("Nome"),
            Descricao = r.Texto("Descricao"),
            PersonagemId = r.InteiroOuNulo("PersonagemId"),
            LocalidadeId = r.InteiroOuNulo("LocalidadeId"),
            NomePersonagem = r.TextoOuNulo("NomePersonagem"),
            NomeLocalidade = r.TextoOuNulo("NomeLocalidade"),
            Categoria = EnumExtensions.Converter(r.Texto("Categoria"), CategoriaMissao.Principal),
            Dificuldade = EnumExtensions.Converter(r.Texto("Dificuldade"), Dificuldade.Media),
            Recompensa = Math.Max(0m, r.Decimal("Recompensa")),
            Status = EnumExtensions.Converter(r.Texto("Status"), StatusMissao.Disponivel),
            DataCadastro = r.Data("DataCadastro")
        };

        protected override void PreencherParametros(DbCommand cmd, Missao m)
        {
            Parametro(cmd, "@Nome", m.Nome);
            Parametro(cmd, "@Descricao", m.Descricao);
            Parametro(cmd, "@PersonagemId", m.PersonagemId);
            Parametro(cmd, "@LocalidadeId", m.LocalidadeId);
            Parametro(cmd, "@Categoria", m.Categoria.ToString());
            Parametro(cmd, "@Dificuldade", m.Dificuldade.ToString());
            Parametro(cmd, "@Recompensa", (double)m.Recompensa);
            Parametro(cmd, "@Status", m.Status.ToString());
        }

        public List<Missao> Pesquisar(FiltroMissao filtro)
        {
            var condicoes = new List<string>();
            var parametros = new List<(string, object?)>();

            if (!string.IsNullOrWhiteSpace(filtro.Texto))
            {
                condicoes.Add(@"m.Nome LIKE @Texto ESCAPE '\'");
                parametros.Add(("@Texto", Like(filtro.Texto!)));
            }
            if (filtro.Categoria.HasValue)
            {
                condicoes.Add("m.Categoria = @Categoria");
                parametros.Add(("@Categoria", filtro.Categoria.Value.ToString()));
            }
            if (filtro.Dificuldade.HasValue)
            {
                condicoes.Add("m.Dificuldade = @Dificuldade");
                parametros.Add(("@Dificuldade", filtro.Dificuldade.Value.ToString()));
            }
            if (filtro.Status.HasValue)
            {
                condicoes.Add("m.Status = @Status");
                parametros.Add(("@Status", filtro.Status.Value.ToString()));
            }

            string where = condicoes.Count > 0 ? " WHERE " + string.Join(" AND ", condicoes) : string.Empty;
            return Consultar($"{SqlSelect}{where} ORDER BY m.DataCadastro DESC, m.Id DESC;", parametros.ToArray());
        }

        public bool ExisteNome(string nome, int ignorarId)
            => Convert.ToInt32(Escalar("SELECT COUNT(*) FROM Missoes WHERE Nome = @Nome COLLATE NOCASE AND Id <> @Id;",
                ("@Nome", nome), ("@Id", ignorarId))) > 0;

        /// <summary>Quantidade de missões por status (inclui status sem missões).</summary>
        public Dictionary<StatusMissao, int> ContarPorStatus()
        {
            var brutos = ContarAgrupado("SELECT Status, COUNT(*) FROM Missoes GROUP BY Status;");
            var resultado = new Dictionary<StatusMissao, int>();
            foreach (var opcao in EnumExtensions.ListarOpcoes<StatusMissao>())
                resultado[opcao.Valor] = brutos.TryGetValue(opcao.Valor.ToString(), out int qtd) ? qtd : 0;
            return resultado;
        }
    }
}
