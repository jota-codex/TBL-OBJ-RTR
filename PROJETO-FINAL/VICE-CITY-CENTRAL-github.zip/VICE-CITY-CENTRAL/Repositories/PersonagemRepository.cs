using System;
using System.Collections.Generic;
using System.Data.Common;
using ViceCityCentral.Data;
using ViceCityCentral.Models;

namespace ViceCityCentral.Repositories
{
    public class PersonagemRepository : RepositoryBase<Personagem>
    {
        protected override string Tabela => "Personagens";

        protected override string SqlInsert =>
            @"INSERT INTO Personagens (Nome, Sobrenome, Idade, Genero, Profissao, Nacionalidade, Descricao, Status, ImagemPath, DataCadastro)
              VALUES (@Nome, @Sobrenome, @Idade, @Genero, @Profissao, @Nacionalidade, @Descricao, @Status, @ImagemPath, @DataCadastro);";

        protected override string SqlUpdate =>
            @"UPDATE Personagens SET Nome = @Nome, Sobrenome = @Sobrenome, Idade = @Idade, Genero = @Genero,
                     Profissao = @Profissao, Nacionalidade = @Nacionalidade, Descricao = @Descricao,
                     Status = @Status, ImagemPath = @ImagemPath, DataCadastro = @DataCadastro
              WHERE Id = @Id;";

        protected override Personagem Mapear(DbDataReader r) => new Personagem
        {
            Id = r.Inteiro("Id"),
            Nome = r.Texto("Nome"),
            Sobrenome = r.Texto("Sobrenome"),
            Idade = Math.Max(0, r.Inteiro("Idade")),
            Genero = EnumExtensions.Converter(r.Texto("Genero"), Genero.NaoInformado),
            Profissao = r.Texto("Profissao"),
            Nacionalidade = r.Texto("Nacionalidade"),
            Descricao = r.Texto("Descricao"),
            Status = EnumExtensions.Converter(r.Texto("Status"), StatusPersonagem.Ativo),
            ImagemPath = r.TextoOuNulo("ImagemPath"),
            DataCadastro = r.Data("DataCadastro")
        };

        protected override void PreencherParametros(DbCommand cmd, Personagem p)
        {
            Parametro(cmd, "@Nome", p.Nome);
            Parametro(cmd, "@Sobrenome", p.Sobrenome);
            Parametro(cmd, "@Idade", p.Idade);
            Parametro(cmd, "@Genero", p.Genero.ToString());
            Parametro(cmd, "@Profissao", p.Profissao);
            Parametro(cmd, "@Nacionalidade", p.Nacionalidade);
            Parametro(cmd, "@Descricao", p.Descricao);
            Parametro(cmd, "@Status", p.Status.ToString());
            Parametro(cmd, "@ImagemPath", p.ImagemPath);
        }

        public List<Personagem> Pesquisar(FiltroPersonagem filtro)
        {
            var condicoes = new List<string>();
            var parametros = new List<(string, object?)>();

            if (!string.IsNullOrWhiteSpace(filtro.Texto))
            {
                condicoes.Add(@"(Nome LIKE @Texto ESCAPE '\' OR Sobrenome LIKE @Texto ESCAPE '\'
                                 OR (Nome || ' ' || Sobrenome) LIKE @Texto ESCAPE '\')");
                parametros.Add(("@Texto", Like(filtro.Texto!)));
            }
            if (filtro.Status.HasValue)
            {
                condicoes.Add("Status = @Status");
                parametros.Add(("@Status", filtro.Status.Value.ToString()));
            }

            string where = condicoes.Count > 0 ? " WHERE " + string.Join(" AND ", condicoes) : string.Empty;
            return Consultar($"{SqlSelect}{where} ORDER BY Nome COLLATE NOCASE, Sobrenome COLLATE NOCASE;", parametros.ToArray());
        }

        /// <summary>Verifica duplicidade de nome completo (ignora o próprio registro na edição).</summary>
        public bool ExisteNomeCompleto(string nome, string sobrenome, int ignorarId)
        {
            object? total = Escalar(
                @"SELECT COUNT(*) FROM Personagens
                  WHERE Nome = @Nome COLLATE NOCASE AND Sobrenome = @Sobrenome COLLATE NOCASE AND Id <> @Id;",
                ("@Nome", nome), ("@Sobrenome", sobrenome), ("@Id", ignorarId));
            return Convert.ToInt32(total) > 0;
        }

        public int ContarMissoesVinculadas(int personagemId)
            => Convert.ToInt32(Escalar("SELECT COUNT(*) FROM Missoes WHERE PersonagemId = @Id;", ("@Id", personagemId)));
    }
}
