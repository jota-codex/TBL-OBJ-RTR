using System.ComponentModel;

namespace ViceCityCentral.Models
{
    // Os valores dos enums são gravados no banco como TEXT (nome do membro).
    // O atributo [Description] define o texto amigável exibido na interface.

    public enum Genero
    {
        Masculino,
        Feminino,
        [Description("Não-binário")] NaoBinario,
        [Description("Não informado")] NaoInformado
    }

    public enum StatusPersonagem
    {
        Ativo,
        Inativo,
        Procurado
    }

    public enum CategoriaVeiculo
    {
        [Description("Carros esportivos")] CarroEsportivo,
        [Description("Supercarros")] Supercarro,
        [Description("Motocicletas")] Motocicleta,
        [Description("Caminhonetes")] Caminhonete,
        [Description("SUVs")] SUV,
        [Description("Barcos")] Barco,
        [Description("Aeronaves")] Aeronave,
        [Description("Outros")] Outros
    }

    public enum TipoVeiculo
    {
        Terrestre,
        [Description("Aquático")] Aquatico,
        [Description("Aéreo")] Aereo
    }

    public enum StatusVeiculo
    {
        [Description("Disponível")] Disponivel,
        [Description("Em uso")] EmUso,
        Apreendido
    }

    public enum CategoriaMissao
    {
        Principal,
        [Description("Secundária")] Secundaria,
        Corrida,
        [Description("Investigação")] Investigacao,
        Desafio,
        Especial
    }

    public enum Dificuldade
    {
        [Description("Fácil")] Facil,
        [Description("Média")] Media,
        [Description("Difícil")] Dificil,
        Extrema
    }

    public enum StatusMissao
    {
        [Description("Disponível")] Disponivel,
        [Description("Em andamento")] EmAndamento,
        [Description("Concluída")] Concluida,
        Cancelada
    }

    public enum TipoLocalidade
    {
        Bairro,
        Praia,
        [Description("Comércio")] Comercio,
        [Description("Área residencial")] AreaResidencial,
        [Description("Área industrial")] AreaIndustrial,
        [Description("Ponto turístico")] PontoTuristico,
        [Description("Região rural")] RegiaoRural,
        Outros
    }

    public enum NivelPerigo
    {
        Baixo,
        Moderado,
        Alto,
        Extremo
    }

    public enum StatusLocalidade
    {
        Liberada,
        Restrita,
        Interditada
    }

    /// <summary>
    /// Nível visual de um status. Cada entidade traduz o próprio status para um nível,
    /// e a interface usa o nível para escolher a cor do "badge" (polimorfismo).
    /// </summary>
    public enum NivelAlerta
    {
        Positivo,
        Neutro,
        Atencao,
        Critico
    }
}
