using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;

namespace ViceCityCentral.Models
{
    /// <summary>Item usado para preencher ComboBoxes com valores de enums.</summary>
    public sealed class OpcaoEnum<T> where T : struct, Enum
    {
        public OpcaoEnum(T valor) { Valor = valor; Texto = valor.ToDescricao(); }
        public T Valor { get; }
        public string Texto { get; }
        public override string ToString() => Texto;
    }

    public static class EnumExtensions
    {
        /// <summary>Retorna o texto do atributo [Description] ou o próprio nome do membro.</summary>
        public static string ToDescricao(this Enum valor)
        {
            FieldInfo? campo = valor.GetType().GetField(valor.ToString());
            var atributo = campo?.GetCustomAttribute<DescriptionAttribute>();
            return atributo?.Description ?? valor.ToString();
        }

        public static List<OpcaoEnum<T>> ListarOpcoes<T>() where T : struct, Enum
            => Enum.GetValues(typeof(T)).Cast<T>().Select(v => new OpcaoEnum<T>(v)).ToList();

        /// <summary>Converte o texto gravado no banco para o enum, de forma tolerante.</summary>
        public static T Converter<T>(string? texto, T padrao) where T : struct, Enum
        {
            if (!string.IsNullOrWhiteSpace(texto) && Enum.TryParse(texto, true, out T resultado)
                && Enum.IsDefined(typeof(T), resultado))
                return resultado;
            return padrao;
        }
    }
}
