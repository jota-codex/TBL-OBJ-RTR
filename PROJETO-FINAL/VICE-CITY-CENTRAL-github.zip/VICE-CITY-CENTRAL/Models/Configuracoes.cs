namespace ViceCityCentral.Models
{
    /// <summary>Preferências do usuário, gravadas na tabela Configuracoes.</summary>
    public class Configuracoes
    {
        private string _nomeOperador = PadraoOperador;
        private int _intervaloAtualizacao = 30;

        public const string PadraoOperador = "Operador";

        public string NomeOperador
        {
            get => _nomeOperador;
            set => _nomeOperador = string.IsNullOrWhiteSpace(value) ? PadraoOperador : value.Trim();
        }

        public bool ExibirSegundosRelogio { get; set; } = true;
        public bool AtualizarDashboardAutomaticamente { get; set; } = true;
        public bool DestacarLinhasAlternadas { get; set; } = true;
        public bool ExibirNotificacoesSucesso { get; set; } = true;

        /// <summary>Intervalo de atualização automática do dashboard (10 a 600 segundos).</summary>
        public int IntervaloAtualizacaoSegundos
        {
            get => _intervaloAtualizacao;
            set => _intervaloAtualizacao = value < 10 ? 10 : (value > 600 ? 600 : value);
        }

        public static Configuracoes Padrao() => new Configuracoes();
    }
}
