using System;
using System.Collections.Generic;

namespace ViceCityCentral.Models
{
    /// <summary>Personagem do universo de Vice City / Leonida.</summary>
    public class Personagem : EntidadeComImagem
    {
        public const int IdadeMaxima = 120;

        private string _nome = string.Empty;
        private string _sobrenome = string.Empty;
        private int _idade;
        private string _profissao = string.Empty;
        private string _nacionalidade = string.Empty;
        private string _descricao = string.Empty;

        public string Nome { get => _nome; set => _nome = Normalizar(value); }
        public string Sobrenome { get => _sobrenome; set => _sobrenome = Normalizar(value); }

        /// <summary>Idade em anos. O setter protege contra valores negativos (encapsulamento).</summary>
        public int Idade
        {
            get => _idade;
            set
            {
                if (value < 0) throw new ArgumentOutOfRangeException(nameof(Idade), "A idade não pode ser negativa.");
                _idade = value;
            }
        }

        public Genero Genero { get; set; } = Genero.NaoInformado;
        public string Profissao { get => _profissao; set => _profissao = Normalizar(value); }
        public string Nacionalidade { get => _nacionalidade; set => _nacionalidade = Normalizar(value); }
        public string Descricao { get => _descricao; set => _descricao = (value ?? string.Empty).Trim(); }
        public StatusPersonagem Status { get; set; } = StatusPersonagem.Ativo;

        public string NomeCompleto => string.IsNullOrEmpty(Sobrenome) ? Nome : $"{Nome} {Sobrenome}";

        public string Iniciais
        {
            get
            {
                string a = Nome.Length > 0 ? Nome.Substring(0, 1) : "";
                string b = Sobrenome.Length > 0 ? Sobrenome.Substring(0, 1) : "";
                return (a + b).ToUpperInvariant();
            }
        }

        public override string TipoEntidade => "Personagem";
        public override string Titulo => NomeCompleto;
        public override string Subtitulo => $"{Profissao} • {Idade} anos";
        public override string StatusDescricao => Status.ToDescricao();

        public override NivelAlerta NivelStatus => Status switch
        {
            StatusPersonagem.Ativo => NivelAlerta.Positivo,
            StatusPersonagem.Inativo => NivelAlerta.Neutro,
            _ => NivelAlerta.Critico
        };

        protected override void ValidarCampos(List<string> erros)
        {
            Obrigatorio(erros, Nome, "Nome");
            Obrigatorio(erros, Sobrenome, "Sobrenome");
            Obrigatorio(erros, Profissao, "Profissão/Ocupação");
            Obrigatorio(erros, Nacionalidade, "Nacionalidade");
            TamanhoMaximo(erros, Nome, 60, "Nome");
            TamanhoMaximo(erros, Sobrenome, 60, "Sobrenome");
            TamanhoMaximo(erros, Profissao, 80, "Profissão/Ocupação");
            TamanhoMaximo(erros, Nacionalidade, 60, "Nacionalidade");
            TamanhoMaximo(erros, Descricao, 1000, "Descrição");
            if (Idade < 1 || Idade > IdadeMaxima)
                erros.Add($"A idade deve estar entre 1 e {IdadeMaxima} anos.");
        }

        public override IEnumerable<KeyValuePair<string, string>> ObterDetalhes()
        {
            yield return Par("Nome completo", NomeCompleto);
            yield return Par("Idade", $"{Idade} anos");
            yield return Par("Gênero", Genero.ToDescricao());
            yield return Par("Profissão / Ocupação", Profissao);
            yield return Par("Nacionalidade", Nacionalidade);
            yield return Par("Descrição", Descricao);
            foreach (var item in base.ObterDetalhes()) yield return item;
        }
    }
}
