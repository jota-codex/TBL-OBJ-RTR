using System;
using System.Collections.Generic;

namespace ViceCityCentral.Models
{
    /// <summary>Contrato mínimo de qualquer registro persistido.</summary>
    public interface IEntidade
    {
        int Id { get; }
        DateTime DataCadastro { get; }
    }

    /// <summary>Objetos capazes de validar o próprio estado.</summary>
    public interface IValidavel
    {
        IReadOnlyList<string> Validar();
    }

    /// <summary>Entidades que possuem uma imagem ilustrativa.</summary>
    public interface IPossuiImagem
    {
        string? ImagemPath { get; set; }
    }

    /// <summary>Entidades que sabem descrever seus dados para a tela de detalhes.</summary>
    public interface IDetalhavel
    {
        IEnumerable<KeyValuePair<string, string>> ObterDetalhes();
    }
}
