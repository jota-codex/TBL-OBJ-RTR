using System.Collections.Generic;
using System.IO;

namespace ViceCityCentral.Models
{
    /// <summary>
    /// Especialização intermediária para entidades que possuem imagem
    /// (Personagem, Veículo e Localidade). Missão herda direto de EntidadeBase.
    /// </summary>
    public abstract class EntidadeComImagem : EntidadeBase, IPossuiImagem
    {
        private string? _imagemPath;

        /// <summary>Caminho relativo à pasta do aplicativo (ou absoluto).</summary>
        public string? ImagemPath
        {
            get => _imagemPath;
            set => _imagemPath = string.IsNullOrWhiteSpace(value) ? null : value!.Trim();
        }

        public bool PossuiImagem => !string.IsNullOrEmpty(ImagemPath);

        public override IEnumerable<KeyValuePair<string, string>> ObterDetalhes()
        {
            foreach (var item in base.ObterDetalhes()) yield return item;
            yield return Par("Imagem", PossuiImagem ? Path.GetFileName(ImagemPath) : "Sem imagem");
        }
    }
}
