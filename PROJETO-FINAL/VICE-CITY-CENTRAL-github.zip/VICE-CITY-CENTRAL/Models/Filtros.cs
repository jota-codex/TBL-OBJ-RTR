namespace ViceCityCentral.Models
{
    // Objetos de filtro usados pelas telas para consultar os repositórios.
    // Propriedades nulas significam "sem filtro".

    public class FiltroPersonagem
    {
        public string? Texto { get; set; }
        public StatusPersonagem? Status { get; set; }
    }

    public class FiltroVeiculo
    {
        public string? Texto { get; set; }
        public CategoriaVeiculo? Categoria { get; set; }
        public StatusVeiculo? Status { get; set; }
    }

    public class FiltroMissao
    {
        public string? Texto { get; set; }
        public CategoriaMissao? Categoria { get; set; }
        public Dificuldade? Dificuldade { get; set; }
        public StatusMissao? Status { get; set; }
    }

    public class FiltroLocalidade
    {
        public string? Texto { get; set; }
        public string? Regiao { get; set; }
        public TipoLocalidade? Tipo { get; set; }
    }
}
