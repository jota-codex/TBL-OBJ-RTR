using System;
using System.Collections.Generic;

namespace ViceCityCentral.Models
{
    /// <summary>Missão (operação) vinculada opcionalmente a um personagem e a uma localidade.</summary>
    public class Missao : EntidadeBase
    {
        public const decimal RecompensaMaxima = 100_000_000m;

        private string _nome = string.Empty;
        private string _descricao = string.Empty;
        private decimal _recompensa;

        public string Nome { get => _nome; set => _nome = Normalizar(value); }
        public string Descricao { get => _descricao; set => _descricao = (value ?? string.Empty).Trim(); }

        /// <summary>Chave estrangeira para Personagens (opcional).</summary>
        public int? PersonagemId { get; set; }

        /// <summary>Chave estrangeira para Localidades (opcional).</summary>
        public int? LocalidadeId { get; set; }

        // Preenchidos pela consulta com JOIN (somente leitura para a interface).
        public string? NomePersonagem { get; set; }
        public string? NomeLocalidade { get; set; }

        public CategoriaMissao Categoria { get; set; } = CategoriaMissao.Principal;
        public Dificuldade Dificuldade { get; set; } = Dificuldade.Media;

        /// <summary>Recompensa fictícia em dólares de Vice City. Não aceita valores negativos.</summary>
        public decimal Recompensa
        {
            get => _recompensa;
            set
            {
                if (value < 0) throw new ArgumentOutOfRangeException(nameof(Recompensa), "A recompensa não pode ser negativa.");
                _recompensa = decimal.Round(value, 2);
            }
        }

        public StatusMissao Status { get; set; } = StatusMissao.Disponivel;

        public bool EstaPendente => Status == StatusMissao.Disponivel || Status == StatusMissao.EmAndamento;

        public override string TipoEntidade => "Missão";
        public override string Titulo => Nome;
        public override string Subtitulo => $"{Categoria.ToDescricao()} • {Dificuldade.ToDescricao()} • {Recompensa.ToString("C0", PtBr)}";
        public override string StatusDescricao => Status.ToDescricao();

        public override NivelAlerta NivelStatus => Status switch
        {
            StatusMissao.Concluida => NivelAlerta.Positivo,
            StatusMissao.EmAndamento => NivelAlerta.Atencao,
            StatusMissao.Cancelada => NivelAlerta.Critico,
            _ => NivelAlerta.Neutro
        };

        protected override void ValidarCampos(List<string> erros)
        {
            Obrigatorio(erros, Nome, "Nome da missão");
            Obrigatorio(erros, Descricao, "Descrição");
            TamanhoMaximo(erros, Nome, 80, "Nome da missão");
            TamanhoMaximo(erros, Descricao, 1000, "Descrição");
            if (Recompensa > RecompensaMaxima)
                erros.Add($"A recompensa não pode ultrapassar {RecompensaMaxima.ToString("C0", PtBr)}.");

            // Regra de negócio: missão iniciada ou concluída precisa de um responsável.
            if ((Status == StatusMissao.EmAndamento || Status == StatusMissao.Concluida) && !PersonagemId.HasValue)
                erros.Add("Missões em andamento ou concluídas precisam de um personagem responsável.");
        }

        public override IEnumerable<KeyValuePair<string, string>> ObterDetalhes()
        {
            yield return Par("Missão", Nome);
            yield return Par("Categoria", Categoria.ToDescricao());
            yield return Par("Dificuldade", Dificuldade.ToDescricao());
            yield return Par("Recompensa", Recompensa.ToString("C2", PtBr));
            yield return Par("Personagem", NomePersonagem ?? "Nenhum");
            yield return Par("Localidade", NomeLocalidade ?? "Nenhuma");
            yield return Par("Descrição", Descricao);
            foreach (var item in base.ObterDetalhes()) yield return item;
        }
    }
}
