using System;
using System.Collections.Generic;

namespace ViceCityCentral.Models
{
    /// <summary>Veículo registrado na frota da organização.</summary>
    public class Veiculo : EntidadeComImagem
    {
        public const int AnoMinimo = 1900;
        public const int VelocidadeLimite = 800; // km/h

        private string _nome = string.Empty;
        private string _fabricante = string.Empty;
        private string _modelo = string.Empty;
        private string _cor = string.Empty;
        private int _velocidadeMaxima;
        private int _ano = DateTime.Now.Year;

        public string Nome { get => _nome; set => _nome = Normalizar(value); }
        public string Fabricante { get => _fabricante; set => _fabricante = Normalizar(value); }
        public string Modelo { get => _modelo; set => _modelo = Normalizar(value); }
        public CategoriaVeiculo Categoria { get; set; } = CategoriaVeiculo.CarroEsportivo;
        public int Ano { get => _ano; set => _ano = value; }
        public string Cor { get => _cor; set => _cor = Normalizar(value); }

        /// <summary>Velocidade máxima em km/h. Não aceita valores negativos.</summary>
        public int VelocidadeMaxima
        {
            get => _velocidadeMaxima;
            set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException(nameof(VelocidadeMaxima), "A velocidade máxima não pode ser negativa.");
                _velocidadeMaxima = value;
            }
        }

        public TipoVeiculo Tipo { get; set; } = TipoVeiculo.Terrestre;
        public StatusVeiculo Status { get; set; } = StatusVeiculo.Disponivel;

        /// <summary>Regra de negócio: o tipo esperado para cada categoria (null = livre).</summary>
        public static TipoVeiculo? TipoEsperado(CategoriaVeiculo categoria) => categoria switch
        {
            CategoriaVeiculo.Barco => TipoVeiculo.Aquatico,
            CategoriaVeiculo.Aeronave => TipoVeiculo.Aereo,
            CategoriaVeiculo.Outros => null,
            _ => TipoVeiculo.Terrestre
        };

        public override string TipoEntidade => "Veículo";
        public override string Titulo => $"{Fabricante} {Nome}".Trim();
        public override string Subtitulo => $"{Categoria.ToDescricao()} • {VelocidadeMaxima} km/h";
        public override string StatusDescricao => Status.ToDescricao();

        public override NivelAlerta NivelStatus => Status switch
        {
            StatusVeiculo.Disponivel => NivelAlerta.Positivo,
            StatusVeiculo.EmUso => NivelAlerta.Atencao,
            _ => NivelAlerta.Critico
        };

        protected override void ValidarCampos(List<string> erros)
        {
            Obrigatorio(erros, Nome, "Nome do veículo");
            Obrigatorio(erros, Fabricante, "Fabricante");
            Obrigatorio(erros, Modelo, "Modelo");
            Obrigatorio(erros, Cor, "Cor");
            TamanhoMaximo(erros, Nome, 60, "Nome do veículo");
            TamanhoMaximo(erros, Fabricante, 60, "Fabricante");
            TamanhoMaximo(erros, Modelo, 60, "Modelo");
            TamanhoMaximo(erros, Cor, 40, "Cor");

            int anoMaximo = DateTime.Now.Year + 1;
            if (Ano < AnoMinimo || Ano > anoMaximo)
                erros.Add($"O ano deve estar entre {AnoMinimo} e {anoMaximo}.");

            if (VelocidadeMaxima <= 0 || VelocidadeMaxima > VelocidadeLimite)
                erros.Add($"A velocidade máxima deve estar entre 1 e {VelocidadeLimite} km/h.");

            TipoVeiculo? esperado = TipoEsperado(Categoria);
            if (esperado.HasValue && esperado.Value != Tipo)
                erros.Add($"Veículos da categoria \"{Categoria.ToDescricao()}\" devem ser do tipo \"{esperado.Value.ToDescricao()}\".");
        }

        public override IEnumerable<KeyValuePair<string, string>> ObterDetalhes()
        {
            yield return Par("Nome", Nome);
            yield return Par("Fabricante", Fabricante);
            yield return Par("Modelo", Modelo);
            yield return Par("Categoria", Categoria.ToDescricao());
            yield return Par("Tipo", Tipo.ToDescricao());
            yield return Par("Ano", Ano.ToString());
            yield return Par("Cor", Cor);
            yield return Par("Velocidade máxima", $"{VelocidadeMaxima} km/h");
            foreach (var item in base.ObterDetalhes()) yield return item;
        }
    }
}
