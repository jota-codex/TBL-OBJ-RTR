using System.Collections.Generic;

namespace ViceCityCentral.Models
{
    /// <summary>Localidade de Vice City e das regiões do estado de Leonida.</summary>
    public class Localidade : EntidadeComImagem
    {
        /// <summary>Regiões sugeridas na interface (o usuário pode digitar outras).</summary>
        public static readonly string[] RegioesSugeridas =
        {
            "Vice City", "Leonida Keys", "Grassrivers", "Port Gellhorn", "Ambrosia", "Mount Kalaga"
        };

        private string _nome = string.Empty;
        private string _regiao = string.Empty;
        private string _descricao = string.Empty;

        public string Nome { get => _nome; set => _nome = Normalizar(value); }
        public string Regiao { get => _regiao; set => _regiao = Normalizar(value); }
        public TipoLocalidade Tipo { get; set; } = TipoLocalidade.Bairro;
        public string Descricao { get => _descricao; set => _descricao = (value ?? string.Empty).Trim(); }
        public NivelPerigo NivelPerigo { get; set; } = NivelPerigo.Baixo;
        public StatusLocalidade Status { get; set; } = StatusLocalidade.Liberada;

        public override string TipoEntidade => "Localidade";
        public override string Titulo => Nome;
        public override string Subtitulo => $"{Regiao} • {Tipo.ToDescricao()}";
        public override string StatusDescricao => Status.ToDescricao();

        // Para localidades, o alerta combina o status de acesso com o nível de perigo.
        public override NivelAlerta NivelStatus
        {
            get
            {
                if (Status == StatusLocalidade.Interditada || NivelPerigo == NivelPerigo.Extremo) return NivelAlerta.Critico;
                if (Status == StatusLocalidade.Restrita || NivelPerigo == NivelPerigo.Alto) return NivelAlerta.Atencao;
                return NivelAlerta.Positivo;
            }
        }

        protected override void ValidarCampos(List<string> erros)
        {
            Obrigatorio(erros, Nome, "Nome da localidade");
            Obrigatorio(erros, Regiao, "Região");
            TamanhoMaximo(erros, Nome, 80, "Nome da localidade");
            TamanhoMaximo(erros, Regiao, 60, "Região");
            TamanhoMaximo(erros, Descricao, 1000, "Descrição");
        }

        public override IEnumerable<KeyValuePair<string, string>> ObterDetalhes()
        {
            yield return Par("Localidade", Nome);
            yield return Par("Região", Regiao);
            yield return Par("Tipo de local", Tipo.ToDescricao());
            yield return Par("Nível de perigo", NivelPerigo.ToDescricao());
            yield return Par("Descrição", Descricao);
            foreach (var item in base.ObterDetalhes()) yield return item;
        }
    }
}
