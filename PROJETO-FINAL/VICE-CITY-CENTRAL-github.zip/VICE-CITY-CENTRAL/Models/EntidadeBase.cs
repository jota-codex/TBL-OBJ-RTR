using System;
using System.Collections.Generic;
using System.Globalization;

namespace ViceCityCentral.Models
{
    /// <summary>
    /// Classe abstrata raiz de todas as entidades do sistema.
    /// Concentra o que é comum (ID, data de cadastro, validação e detalhes)
    /// e obriga as classes derivadas a especializar o comportamento (polimorfismo).
    /// </summary>
    public abstract class EntidadeBase : IEntidade, IValidavel, IDetalhavel
    {
        protected static readonly CultureInfo PtBr = new CultureInfo("pt-BR");

        private int _id;

        public int Id
        {
            get => _id;
            set
            {
                if (value < 0) throw new ArgumentOutOfRangeException(nameof(Id), "O ID não pode ser negativo.");
                _id = value;
            }
        }

        public DateTime DataCadastro { get; set; } = DateTime.Now;

        /// <summary>Indica se o registro ainda não foi gravado no banco.</summary>
        public bool EhNovo => Id == 0;

        /// <summary>Nome do tipo da entidade (ex.: "Personagem").</summary>
        public abstract string TipoEntidade { get; }

        /// <summary>Texto principal usado em listas e títulos.</summary>
        public abstract string Titulo { get; }

        /// <summary>Resumo curto exibido abaixo do título.</summary>
        public abstract string Subtitulo { get; }

        /// <summary>Texto do status atual.</summary>
        public abstract string StatusDescricao { get; }

        /// <summary>Nível visual do status (cada entidade decide o seu).</summary>
        public abstract NivelAlerta NivelStatus { get; }

        /// <summary>Valida campos comuns e delega as regras específicas às classes derivadas.</summary>
        public IReadOnlyList<string> Validar()
        {
            var erros = new List<string>();
            if (DataCadastro > DateTime.Now.AddDays(1))
                erros.Add("A data de cadastro não pode estar no futuro.");
            ValidarCampos(erros);
            return erros;
        }

        /// <summary>Regras de validação específicas de cada entidade.</summary>
        protected abstract void ValidarCampos(List<string> erros);

        public virtual IEnumerable<KeyValuePair<string, string>> ObterDetalhes()
        {
            yield return Par("ID", EhNovo ? "(novo)" : "#" + Id.ToString("000"));
            yield return Par("Tipo", TipoEntidade);
            yield return Par("Status", StatusDescricao);
            yield return Par("Cadastrado em", DataCadastro.ToString("dd/MM/yyyy HH:mm", PtBr));
        }

        // ---------- utilitários protegidos para as classes derivadas ----------

        protected static KeyValuePair<string, string> Par(string chave, string? valor)
            => new KeyValuePair<string, string>(chave, string.IsNullOrWhiteSpace(valor) ? "—" : valor!);

        protected static string Normalizar(string? texto)
        {
            if (string.IsNullOrWhiteSpace(texto)) return string.Empty;
            // remove espaços duplicados internos
            return string.Join(" ", texto!.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries));
        }

        protected static void Obrigatorio(List<string> erros, string valor, string campo)
        {
            if (string.IsNullOrWhiteSpace(valor)) erros.Add($"O campo \"{campo}\" é obrigatório.");
        }

        protected static void TamanhoMaximo(List<string> erros, string valor, int maximo, string campo)
        {
            if (valor.Length > maximo) erros.Add($"O campo \"{campo}\" aceita no máximo {maximo} caracteres.");
        }

        public override string ToString() => Titulo;
    }
}
