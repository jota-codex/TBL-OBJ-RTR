using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using ViceCityCentral.Audio;
using ViceCityCentral.Data;
using ViceCityCentral.Models;
using ViceCityCentral.Services;
using ViceCityCentral.Views.Components;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views
{
    /// <summary>Informações do sistema, preferências do usuário e manutenção.</summary>
    public class ConfiguracoesForm : ModuloBaseForm
    {
        private readonly TextBox _txtOperador = Ui.CaixaTexto(40);
        private readonly ToggleSwitch _tglSegundos = new ToggleSwitch("Exibir segundos no relógio do Dashboard");
        private readonly ToggleSwitch _tglAtualizar = new ToggleSwitch("Atualizar o Dashboard automaticamente");
        private readonly ToggleSwitch _tglLinhas = new ToggleSwitch("Destacar linhas alternadas nas listagens");
        private readonly ToggleSwitch _tglNotificacoes = new ToggleSwitch("Exibir notificações de sucesso");
        private readonly ComboTema _cmbIntervalo = new ComboTema();
        private readonly Label _lblBanco = new Label();

        private static readonly int[] Intervalos = { 15, 30, 60, 120, 300 };

        /// <summary>Disparado quando o usuário pede para limpar os filtros de todas as telas.</summary>
        public event EventHandler? LimparFiltrosSolicitado;

        /// <summary>Disparado depois que o banco de dados é restaurado.</summary>
        public event EventHandler? BancoRestaurado;

        public ConfiguracoesForm()
        {
            AutoScroll = true;
            AutoScrollMinSize = new Size(940, 700);

            var raiz = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, BackColor = Tema.Fundo };
            raiz.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 52));
            raiz.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48));
            raiz.RowStyles.Add(new RowStyle(SizeType.Percent, 57));
            raiz.RowStyles.Add(new RowStyle(SizeType.Percent, 43));

            raiz.Controls.Add(CriarCardSobre(), 0, 0);
            raiz.Controls.Add(CriarCardCreditos(), 0, 1);
            raiz.Controls.Add(CriarCardPreferencias(), 1, 0);
            raiz.Controls.Add(CriarCardManutencao(), 1, 1);

            Controls.Add(raiz);
            Controls.Add(CriarCabecalho("Configurações", "Preferências, informações do projeto e manutenção do sistema", "cog", Tema.Lilas));
        }

        public override Modulo Modulo => Modulo.Configuracoes;

        public override void AoAtivar()
        {
            CarregarPreferencias(ConfiguracaoService.Instancia.Atual);
            AtualizarInfoBanco();
        }

        // ------------------------------------------------------------------ cards
        private Control CriarCardSobre()
        {
            var card = new CardPanel { Dock = DockStyle.Fill, Titulo = "Sobre o sistema", IconeTitulo = "information", CorDestaque = Tema.Rosa };
            var fluxo = Fluxo();

            var logo = new PictureBox
            {
                Image = Recursos.Asset("Images/logo.png"), SizeMode = PictureBoxSizeMode.Zoom, Size = new Size(240, 96),
                BackColor = Tema.Superficie, Margin = new Padding(0, 0, 0, 4)
            };
            fluxo.Controls.Add(logo);
            fluxo.Controls.Add(Linha("Nome do sistema", $"{AppInfo.Nome} — {AppInfo.Subtitulo}"));
            fluxo.Controls.Add(Linha("Versão do aplicativo", "v" + AppInfo.Versao));
            fluxo.Controls.Add(Linha("Disciplina", $"{AppInfo.Disciplina} · {AppInfo.Projeto}"));
            fluxo.Controls.Add(Paragrafo(AppInfo.Descricao, Tema.TextoSecundario));
            fluxo.Controls.Add(Paragrafo("Tecnologias: " + string.Join(" · ", AppInfo.Tecnologias), Tema.TextoTerciario));
            _lblBanco.AutoSize = true;
            _lblBanco.ForeColor = Tema.Turquesa;
            _lblBanco.Font = Tema.Fonte(8.75f);
            _lblBanco.Margin = new Padding(0, 8, 0, 0);
            fluxo.Controls.Add(_lblBanco);
            card.Controls.Add(fluxo);
            AjustarLarguraAoRedimensionar(fluxo);
            return card;
        }

        private Control CriarCardCreditos()
        {
            var card = new CardPanel { Dock = DockStyle.Fill, Titulo = "Créditos dos desenvolvedores", IconeTitulo = "account-group", CorDestaque = Tema.Turquesa };
            var fluxo = Fluxo();
            foreach (string dev in AppInfo.Desenvolvedores)
                fluxo.Controls.Add(Paragrafo("•  " + dev, Tema.Texto));
            fluxo.Controls.Add(Paragrafo(AppInfo.AvisoLegal, Tema.TextoTerciario));
            card.Controls.Add(fluxo);
            AjustarLarguraAoRedimensionar(fluxo);
            return card;
        }

        private Control CriarCardPreferencias()
        {
            var card = new CardPanel { Dock = DockStyle.Fill, Titulo = "Preferências", IconeTitulo = "cog", CorDestaque = Tema.Lilas };
            var fluxo = Fluxo();

            fluxo.Controls.Add(Ui.Rotulo("NOME DO OPERADOR (exibido no menu e no Dashboard)", 8.25f));
            var container = new CampoContainer(_txtOperador, "account") { Width = 320, Height = 38, Margin = new Padding(0, 4, 0, 10) };
            fluxo.Controls.Add(container);

            foreach (ToggleSwitch t in new[] { _tglSegundos, _tglAtualizar, _tglLinhas, _tglNotificacoes })
            {
                t.Width = 380;
                t.Height = 31;
                t.Margin = new Padding(0, 1, 0, 1);
                fluxo.Controls.Add(t);
            }

            fluxo.Controls.Add(new Label { Text = "INTERVALO DE ATUALIZAÇÃO DO DASHBOARD", AutoSize = true, ForeColor = Tema.TextoSecundario, Font = Tema.Fonte(8.25f, FontStyle.Bold), Margin = new Padding(0, 10, 0, 4) });
            foreach (int s in Intervalos) _cmbIntervalo.Items.Add(new ItemCombo(s, s < 60 ? $"A cada {s} segundos" : $"A cada {s / 60} minuto(s)"));
            _cmbIntervalo.Width = 220;
            fluxo.Controls.Add(_cmbIntervalo);

            var botoes = new FlowLayoutPanel { AutoSize = true, BackColor = Tema.Superficie, Margin = new Padding(0, 12, 0, 0), WrapContents = true };
            var btnSalvar = new NeonButton("Salvar preferências", VarianteBotao.Primario, "content-save") { Height = 40, Margin = new Padding(0, 0, 8, 6) };
            btnSalvar.AjustarLargura();
            btnSalvar.Click += (s, e) => SalvarPreferencias();
            var btnPadrao = new NeonButton("Restaurar configurações padrão", VarianteBotao.Secundario, "restore") { Height = 40, Margin = new Padding(0, 0, 0, 6) };
            btnPadrao.AjustarLargura();
            btnPadrao.Click += (s, e) => RestaurarPadrao();
            botoes.Controls.Add(btnSalvar);
            botoes.Controls.Add(btnPadrao);
            fluxo.Controls.Add(botoes);

            card.Controls.Add(fluxo);
            return card;
        }

        private Control CriarCardManutencao()
        {
            var card = new CardPanel { Dock = DockStyle.Fill, Titulo = "Manutenção", IconeTitulo = "database-refresh", CorDestaque = Tema.Laranja };
            var fluxo = Fluxo();

            var btnFiltros = new NeonButton("Limpar filtros de todas as telas", VarianteBotao.Sucesso, "filter-remove") { Height = 38, Margin = new Padding(0, 0, 0, 2) };
            btnFiltros.AjustarLargura(300);
            btnFiltros.Click += (s, e) =>
            {
                LimparFiltrosSolicitado?.Invoke(this, EventArgs.Empty);
                Mensagem.Notificar(this, "Pesquisas e filtros de todos os módulos foram limpos.", SomInterface.Notificacao);
            };
            fluxo.Controls.Add(btnFiltros);
            fluxo.Controls.Add(Paragrafo("Remove o texto de pesquisa e volta todos os filtros para \"Todos\" em Personagens, Veículos, Missões e Localidades.", Tema.TextoTerciario));

            var btnPasta = new NeonButton("Abrir pasta do banco de dados", VarianteBotao.Secundario, "folder-open") { Height = 38, Margin = new Padding(0, 6, 0, 2) };
            btnPasta.AjustarLargura(300);
            btnPasta.Click += (s, e) => AbrirPastaBanco();
            fluxo.Controls.Add(btnPasta);

            var btnRestaurar = new NeonButton("Restaurar banco de dados inicial", VarianteBotao.Perigo, "database-refresh") { Height = 38, Margin = new Padding(0, 6, 0, 2) };
            btnRestaurar.AjustarLargura(300);
            btnRestaurar.Click += (s, e) => RestaurarBanco();
            fluxo.Controls.Add(btnRestaurar);
            fluxo.Controls.Add(Paragrafo("Apaga todos os dados atuais e recria o banco a partir do arquivo Database/vice_city.sql.", Tema.TextoTerciario));

            card.Controls.Add(fluxo);
            AjustarLarguraAoRedimensionar(fluxo);
            return card;
        }

        // ------------------------------------------------------------ ações
        private void CarregarPreferencias(Configuracoes cfg)
        {
            _txtOperador.Text = cfg.NomeOperador;
            _tglSegundos.Ligado = cfg.ExibirSegundosRelogio;
            _tglAtualizar.Ligado = cfg.AtualizarDashboardAutomaticamente;
            _tglLinhas.Ligado = cfg.DestacarLinhasAlternadas;
            _tglNotificacoes.Ligado = cfg.ExibirNotificacoesSucesso;
            int indice = Array.IndexOf(Intervalos, cfg.IntervaloAtualizacaoSegundos);
            _cmbIntervalo.SelectedIndex = indice >= 0 ? indice : 1;
        }

        private void SalvarPreferencias()
        {
            string operador = _txtOperador.Text.Trim();
            if (operador.Length == 0)
            {
                Mensagem.Aviso(this, "Informe o nome do operador.", null, "Campo obrigatório");
                _txtOperador.Focus();
                return;
            }

            try
            {
                var cfg = new Configuracoes
                {
                    NomeOperador = operador,
                    ExibirSegundosRelogio = _tglSegundos.Ligado,
                    AtualizarDashboardAutomaticamente = _tglAtualizar.Ligado,
                    DestacarLinhasAlternadas = _tglLinhas.Ligado,
                    ExibirNotificacoesSucesso = _tglNotificacoes.Ligado,
                    IntervaloAtualizacaoSegundos = (_cmbIntervalo.SelectedItem as ItemCombo)?.Id ?? 30
                };
                ConfiguracaoService.Instancia.Salvar(cfg);
                Mensagem.Sucesso(this, "As preferências foram salvas e já estão em uso.");
            }
            catch (Exception ex)
            {
                TratarErro(ex, "salvar as preferências");
            }
        }

        private void RestaurarPadrao()
        {
            if (!Mensagem.Confirmar(this, "Restaurar configurações", "Deseja voltar todas as preferências para os valores padrão?", "Restaurar"))
                return;
            try
            {
                CarregarPreferencias(ConfiguracaoService.Instancia.RestaurarPadrao());
                LimparFiltrosSolicitado?.Invoke(this, EventArgs.Empty);
                Mensagem.Sucesso(this, "As configurações padrão foram restauradas.");
            }
            catch (Exception ex)
            {
                TratarErro(ex, "restaurar as configurações");
            }
        }

        private void RestaurarBanco()
        {
            bool confirmado = Mensagem.Confirmar(this, "Restaurar banco de dados",
                "TODOS os personagens, veículos, missões e localidades cadastrados serão apagados e substituídos pelos dados iniciais.\n\nDeseja continuar?",
                "Restaurar banco", "Cancelar", perigoso: true);
            if (!confirmado) return;

            try
            {
                Cursor = Cursors.WaitCursor;
                AudioManager.Instancia.Tocar(SomInterface.Carregando);
                DatabaseInitializer.RestaurarBancoPadrao();
                ConfiguracaoService.Instancia.Carregar();
                ConfiguracaoService.Instancia.NotificarAlteracao();
                Recursos.LimparCacheMiniaturas();
                CarregarPreferencias(ConfiguracaoService.Instancia.Atual);
                AtualizarInfoBanco();
                BancoRestaurado?.Invoke(this, EventArgs.Empty);
                Mensagem.Sucesso(this, "O banco de dados foi restaurado com os dados iniciais.");
            }
            catch (Exception ex)
            {
                TratarErro(ex, "restaurar o banco de dados");
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void AbrirPastaBanco()
        {
            try
            {
                string pasta = Path.GetDirectoryName(DatabaseConnection.CaminhoBanco) ?? DatabaseConnection.PastaAplicacao;
                Process.Start(new ProcessStartInfo { FileName = pasta, UseShellExecute = true });
            }
            catch (Exception ex)
            {
                Mensagem.Erro(this, "Não foi possível abrir a pasta: " + ex.Message, ex);
            }
        }

        private void AtualizarInfoBanco()
        {
            bool ok = DatabaseConnection.TestarConexao(out string info);
            _lblBanco.ForeColor = ok ? Tema.Turquesa : Tema.Vermelho;
            _lblBanco.Text = ok
                ? $"● Banco conectado ({info}) — {DatabaseConnection.CaminhoBanco}"
                : $"● Falha na conexão com o banco: {info}";
        }

        // ---------------------------------------------------------- utilitários
        private static FlowLayoutPanel Fluxo() => new FlowLayoutPanel
        {
            Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, BackColor = Tema.Superficie
        };

        private static Control Linha(string rotulo, string valor)
        {
            var painel = new FlowLayoutPanel { AutoSize = true, BackColor = Tema.Superficie, Margin = new Padding(0, 2, 0, 2), WrapContents = false };
            painel.Controls.Add(new Label { Text = rotulo + ":", AutoSize = true, ForeColor = Tema.TextoSecundario, Font = Tema.Fonte(9.25f, FontStyle.Bold), Margin = new Padding(0, 0, 6, 0) });
            painel.Controls.Add(new Label { Text = valor, AutoSize = true, ForeColor = Tema.Texto, Font = Tema.Fonte(9.25f), Margin = new Padding(0) });
            return painel;
        }

        private static Label Paragrafo(string texto, Color cor) => new Label
        {
            Text = texto, AutoSize = true, ForeColor = cor, Font = Tema.Fonte(9f), MaximumSize = new Size(480, 0), Margin = new Padding(0, 6, 0, 2)
        };

        /// <summary>Faz os parágrafos quebrarem linha conforme a largura do card.</summary>
        private static void AjustarLarguraAoRedimensionar(FlowLayoutPanel fluxo)
        {
            fluxo.Resize += (s, e) =>
            {
                int largura = Math.Max(200, fluxo.ClientSize.Width - 24);
                foreach (Control c in fluxo.Controls)
                    if (c is Label l && l.MaximumSize.Width > 0) l.MaximumSize = new Size(largura, 0);
            };
        }
    }
}
