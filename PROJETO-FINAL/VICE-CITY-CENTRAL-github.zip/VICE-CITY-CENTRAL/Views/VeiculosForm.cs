using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using ViceCityCentral.Models;
using ViceCityCentral.Services;
using ViceCityCentral.Views.Components;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views
{
    /// <summary>Tela de gerenciamento da frota de veículos.</summary>
    public class VeiculosForm : ModuloCrudForm<Veiculo>
    {
        private static readonly string[] FabricantesConhecidos =
        {
            "Albany", "Annis", "Benefactor", "Bravado", "Buckingham", "Canis", "Cheval", "Declasse", "Dewbauchee",
            "Dinka", "Enus", "Grotti", "Imponte", "Karin", "Lampadati", "Maibatsu", "Nagasaki", "Obey", "Ocelot",
            "Pegassi", "Pfister", "Shitzu", "Speedophile", "Truffade", "Ubermacht", "Vapid", "Western", "Zirconium"
        };

        private readonly VeiculoService _servico = new VeiculoService();

        private ComboTema _filtroCategoria = null!;
        private ComboTema _filtroStatus = null!;

        private TextBox _txtNome = null!;
        private TextBox _txtFabricante = null!;
        private TextBox _txtModelo = null!;
        private ComboTema _cmbCategoria = null!;
        private ComboTema _cmbTipo = null!;
        private TextBox _txtAno = null!;
        private TextBox _txtCor = null!;
        private TextBox _txtVelocidade = null!;
        private ComboTema _cmbStatus = null!;

        public VeiculosForm()
        {
            Construir();
        }

        public override Modulo Modulo => Modulo.Veiculos;
        protected override string Titulo => "Veículos";
        protected override string Subtitulo => "Frota registrada: carros, motos, barcos e aeronaves";
        protected override string Icone => "car-sports";
        protected override Color CorModulo => Tema.Turquesa;
        protected override string TextoNovo => "Novo veículo";
        protected override string NomeSingular => "veículo";
        protected override bool PossuiImagem => true;
        protected override ServiceBase<Veiculo> Servico => _servico;

        protected override void CriarFiltros()
        {
            _filtroCategoria = CriarFiltro<CategoriaVeiculo>("Todas as categorias", 185);
            _filtroStatus = CriarFiltro<StatusVeiculo>("Todos os status", 160);
        }

        protected override void LimparFiltrosEspecificos()
        {
            _filtroCategoria.SelectedIndex = 0;
            _filtroStatus.SelectedIndex = 0;
        }

        protected override List<Veiculo> Pesquisar(string texto)
            => _servico.Pesquisar(new FiltroVeiculo
            {
                Texto = texto,
                Categoria = ValorFiltro<CategoriaVeiculo>(_filtroCategoria),
                Status = ValorFiltro<StatusVeiculo>(_filtroStatus)
            });

        protected override void CriarColunas()
        {
            AdicionarColuna("Veiculo", "Veículo", 150, 120);
            AdicionarColuna("Modelo", "Modelo", 80, 70);
            AdicionarColuna("Categoria", "Categoria", 100, 90);
            AdicionarColuna("Velocidade", "Vel. máx.", 72, 80, DataGridViewContentAlignment.MiddleRight);
            AdicionarColuna("Status", "Status", 90, 120);
        }

        protected override object?[] ValoresLinha(Veiculo v)
            => new object?[] { v.Titulo, v.Modelo, v.Categoria.ToDescricao(), $"{v.VelocidadeMaxima} km/h", v.StatusDescricao };

        protected override void CriarCampos()
        {
            _txtNome = AdicionarTexto("Nome do veículo", true, 60);
            _txtFabricante = AdicionarTexto("Fabricante (fictício)", true, 60);
            _txtFabricante.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            _txtFabricante.AutoCompleteSource = AutoCompleteSource.CustomSource;
            _txtFabricante.AutoCompleteCustomSource.AddRange(FabricantesConhecidos);
            _txtModelo = AdicionarTexto("Modelo", true, 60);
            _cmbCategoria = AdicionarCombo<CategoriaVeiculo>("Categoria");
            _cmbTipo = AdicionarCombo<TipoVeiculo>("Tipo de veículo");
            _txtAno = AdicionarTexto("Ano", true, 4, numerico: true);
            _txtCor = AdicionarTexto("Cor", true, 40);
            _txtVelocidade = AdicionarTexto("Velocidade máxima (km/h)", true, 4, numerico: true);
            _cmbStatus = AdicionarCombo<StatusVeiculo>("Status");

            // Regra de negócio refletida na interface: a categoria define o tipo esperado.
            _cmbCategoria.SelectedIndexChanged += (s, e) =>
            {
                if (!_cmbCategoria.Enabled) return;
                TipoVeiculo? esperado = Veiculo.TipoEsperado(ValorCombo(_cmbCategoria, CategoriaVeiculo.Outros));
                if (esperado.HasValue) SelecionarCombo(_cmbTipo, esperado.Value);
            };
        }

        protected override void PreencherCampos(Veiculo v)
        {
            _txtNome.Text = v.Nome;
            _txtFabricante.Text = v.Fabricante;
            _txtModelo.Text = v.Modelo;
            SelecionarCombo(_cmbCategoria, v.Categoria);
            SelecionarCombo(_cmbTipo, v.Tipo);
            _txtAno.Text = v.Ano.ToString();
            _txtCor.Text = v.Cor;
            _txtVelocidade.Text = v.VelocidadeMaxima.ToString();
            SelecionarCombo(_cmbStatus, v.Status);
        }

        protected override void LimparCampos()
        {
            _txtNome.Clear();
            _txtFabricante.Clear();
            _txtModelo.Clear();
            SelecionarCombo(_cmbCategoria, CategoriaVeiculo.CarroEsportivo);
            SelecionarCombo(_cmbTipo, TipoVeiculo.Terrestre);
            _txtAno.Text = DateTime.Now.Year.ToString();
            _txtCor.Clear();
            _txtVelocidade.Clear();
            SelecionarCombo(_cmbStatus, StatusVeiculo.Disponivel);
        }

        protected override Veiculo LerCampos(List<string> erros)
        {
            var v = new Veiculo
            {
                Nome = _txtNome.Text,
                Fabricante = _txtFabricante.Text,
                Modelo = _txtModelo.Text,
                Categoria = ValorCombo(_cmbCategoria, CategoriaVeiculo.Outros),
                Tipo = ValorCombo(_cmbTipo, TipoVeiculo.Terrestre),
                Cor = _txtCor.Text,
                Status = ValorCombo(_cmbStatus, StatusVeiculo.Disponivel)
            };
            int? ano = LerInteiro(_txtAno, "Ano", erros);
            if (ano.HasValue) v.Ano = ano.Value;
            int? velocidade = LerInteiro(_txtVelocidade, "Velocidade máxima", erros);
            if (velocidade.HasValue) Atribuir(erros, () => v.VelocidadeMaxima = velocidade.Value);
            return v;
        }
    }
}
