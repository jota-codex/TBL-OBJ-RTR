using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using ViceCityCentral.Models;
using ViceCityCentral.Services;
using ViceCityCentral.Views.Components;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views
{
    /// <summary>Tela de gerenciamento das localidades de Vice City e regiões de Leonida.</summary>
    public class LocalidadesForm : ModuloCrudForm<Localidade>
    {
        private readonly LocalidadeService _servico = new LocalidadeService();

        private ComboTema _filtroRegiao = null!;
        private ComboTema _filtroTipo = null!;

        private TextBox _txtNome = null!;
        private TextBox _txtRegiao = null!;
        private ComboTema _cmbTipo = null!;
        private ComboTema _cmbPerigo = null!;
        private ComboTema _cmbStatus = null!;
        private TextBox _txtDescricao = null!;

        public LocalidadesForm()
        {
            Construir();
            Grade.CellFormatting += FormatarCelula;
        }

        public override Modulo Modulo => Modulo.Localidades;
        protected override string Titulo => "Localidades";
        protected override string Subtitulo => "Bairros, praias e regiões do estado de Leonida";
        protected override string Icone => "map-marker-radius";
        protected override Color CorModulo => Tema.Laranja;
        protected override string TextoNovo => "Nova localidade";
        protected override string NomeSingular => "localidade";
        protected override bool PossuiImagem => true;
        protected override ServiceBase<Localidade> Servico => _servico;

        protected override void CriarFiltros()
        {
            _filtroRegiao = CriarFiltroTexto("Todas as regiões", _servico.ListarRegioes());
            _filtroTipo = CriarFiltro<TipoLocalidade>("Todos os tipos");
        }

        protected override void LimparFiltrosEspecificos()
        {
            _filtroRegiao.SelectedIndex = 0;
            _filtroTipo.SelectedIndex = 0;
        }

        protected override List<Localidade> Pesquisar(string texto)
            => _servico.Pesquisar(new FiltroLocalidade
            {
                Texto = texto,
                Regiao = TextoFiltro(_filtroRegiao),
                Tipo = ValorFiltro<TipoLocalidade>(_filtroTipo)
            });

        protected override void AtualizarListasAuxiliares()
        {
            List<string> regioes = _servico.ListarRegioes();
            AtualizarFiltroTexto(_filtroRegiao, regioes);
            _txtRegiao.AutoCompleteCustomSource.Clear();
            _txtRegiao.AutoCompleteCustomSource.AddRange(regioes.ToArray());
        }

        protected override void AoSalvar() => AtualizarListasAuxiliares();

        protected override void CriarColunas()
        {
            AdicionarColuna("Localidade", "Localidade", 150, 110);
            AdicionarColuna("Regiao", "Região", 90, 80);
            AdicionarColuna("Tipo", "Tipo", 95, 80);
            AdicionarColuna("Perigo", "Perigo", 75, 82);
            AdicionarColuna("Status", "Status", 90, 110);
        }

        protected override object?[] ValoresLinha(Localidade l)
            => new object?[] { l.Nome, l.Regiao, l.Tipo.ToDescricao(), l.NivelPerigo.ToDescricao(), l.StatusDescricao };

        private void FormatarCelula(object? sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || Grade.Columns[e.ColumnIndex].Name != "Perigo") return;
            if (!(Grade.Rows[e.RowIndex].Tag is Localidade l) || e.CellStyle == null) return;
            e.CellStyle.ForeColor = l.NivelPerigo switch
            {
                NivelPerigo.Baixo => Tema.Verde,
                NivelPerigo.Moderado => Tema.Turquesa,
                NivelPerigo.Alto => Tema.Laranja,
                _ => Tema.Vermelho
            };
        }

        protected override void CriarCampos()
        {
            _txtNome = AdicionarTexto("Nome da localidade", true, 80);
            _txtRegiao = AdicionarTexto("Região", true, 60);
            _txtRegiao.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            _txtRegiao.AutoCompleteSource = AutoCompleteSource.CustomSource;
            _txtRegiao.AutoCompleteCustomSource.AddRange(Localidade.RegioesSugeridas);
            _cmbTipo = AdicionarCombo<TipoLocalidade>("Tipo de local");
            _cmbPerigo = AdicionarCombo<NivelPerigo>("Nível de perigo");
            _cmbStatus = AdicionarCombo<StatusLocalidade>("Status de acesso");
            PularCelula();
            _txtDescricao = AdicionarTexto("Descrição", false, 1000, larguraTotal: true, multilinha: true);
        }

        protected override void PreencherCampos(Localidade l)
        {
            _txtNome.Text = l.Nome;
            _txtRegiao.Text = l.Regiao;
            SelecionarCombo(_cmbTipo, l.Tipo);
            SelecionarCombo(_cmbPerigo, l.NivelPerigo);
            SelecionarCombo(_cmbStatus, l.Status);
            _txtDescricao.Text = l.Descricao;
        }

        protected override void LimparCampos()
        {
            _txtNome.Clear();
            _txtRegiao.Text = "Vice City";
            SelecionarCombo(_cmbTipo, TipoLocalidade.Bairro);
            SelecionarCombo(_cmbPerigo, NivelPerigo.Baixo);
            SelecionarCombo(_cmbStatus, StatusLocalidade.Liberada);
            _txtDescricao.Clear();
        }

        protected override Localidade LerCampos(List<string> erros) => new Localidade
        {
            Nome = _txtNome.Text,
            Regiao = _txtRegiao.Text,
            Tipo = ValorCombo(_cmbTipo, TipoLocalidade.Outros),
            NivelPerigo = ValorCombo(_cmbPerigo, NivelPerigo.Baixo),
            Status = ValorCombo(_cmbStatus, StatusLocalidade.Liberada),
            Descricao = _txtDescricao.Text
        };
    }
}
