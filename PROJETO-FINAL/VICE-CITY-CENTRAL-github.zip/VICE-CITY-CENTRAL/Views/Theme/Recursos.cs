using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using ViceCityCentral.Data;
using ViceCityCentral.Services;

namespace ViceCityCentral.Views.Theme
{
    /// <summary>
    /// Carrega imagens e ícones da pasta Assets com cache em memória.
    /// Ícones são PNG brancos (Material Design Icons) coloridos em tempo de execução.
    /// As imagens são lidas para a memória para não bloquear o arquivo em disco.
    /// </summary>
    public static class Recursos
    {
        private static readonly Dictionary<string, Image?> CacheImagens = new Dictionary<string, Image?>(StringComparer.OrdinalIgnoreCase);
        private static readonly Dictionary<string, Image?> CacheIcones = new Dictionary<string, Image?>(StringComparer.OrdinalIgnoreCase);
        private static readonly Dictionary<string, Image?> CacheMiniaturas = new Dictionary<string, Image?>(StringComparer.OrdinalIgnoreCase);

        public static string PastaAssets => Path.Combine(DatabaseConnection.PastaAplicacao, "Assets");

        /// <summary>Ícone colorido (ex.: Icone("plus", Tema.Rosa, 18)).</summary>
        public static Image? Icone(string nome, Color cor, int tamanho = 20)
        {
            string chave = $"{nome}|{cor.ToArgb()}|{tamanho}";
            if (CacheIcones.TryGetValue(chave, out Image? img)) return img;

            Image? original = CarregarArquivo(Path.Combine(PastaAssets, "Icons", nome + ".png"));
            Image? resultado = null;
            if (original != null)
            {
                var bmp = new Bitmap(tamanho, tamanho, PixelFormat.Format32bppArgb);
                using (var g = Graphics.FromImage(bmp))
                using (var atributos = new ImageAttributes())
                {
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                    // Multiplica o branco pela cor desejada mantendo o canal alfa.
                    var matriz = new ColorMatrix(new[]
                    {
                        new float[] { cor.R / 255f, 0, 0, 0, 0 },
                        new float[] { 0, cor.G / 255f, 0, 0, 0 },
                        new float[] { 0, 0, cor.B / 255f, 0, 0 },
                        new float[] { 0, 0, 0, cor.A / 255f, 0 },
                        new float[] { 0, 0, 0, 0, 1 }
                    });
                    atributos.SetColorMatrix(matriz);
                    g.DrawImage(original, new Rectangle(0, 0, tamanho, tamanho), 0, 0, original.Width, original.Height, GraphicsUnit.Pixel, atributos);
                }
                resultado = bmp;
                original.Dispose();
            }
            CacheIcones[chave] = resultado;
            return resultado;
        }

        /// <summary>Imagem de Assets (ex.: "Images/logo.png").</summary>
        public static Image? Asset(string caminhoRelativo)
        {
            string caminho = Path.Combine(PastaAssets, caminhoRelativo.Replace('/', Path.DirectorySeparatorChar));
            if (CacheImagens.TryGetValue(caminho, out Image? img)) return img;
            img = CarregarArquivo(caminho);
            CacheImagens[caminho] = img;
            return img;
        }

        /// <summary>Carrega a imagem de uma entidade (caminho gravado no banco). Retorna uma cópia nova.</summary>
        public static Image? ImagemEntidade(string? caminho)
        {
            string? absoluto = ImagemService.ResolverCaminho(caminho);
            return absoluto == null ? null : CarregarArquivo(absoluto);
        }

        /// <summary>Miniatura (recorte central) usada nas listagens.</summary>
        public static Image? Miniatura(string? caminho, int largura, int altura)
        {
            string? absoluto = ImagemService.ResolverCaminho(caminho);
            if (absoluto == null) return null;
            string chave = $"{absoluto}|{largura}x{altura}";
            if (CacheMiniaturas.TryGetValue(chave, out Image? mini)) return mini;

            using (Image? original = CarregarArquivo(absoluto))
            {
                if (original != null)
                {
                    var bmp = new Bitmap(largura, altura, PixelFormat.Format32bppArgb);
                    using (var g = Graphics.FromImage(bmp))
                    {
                        Tema.PrepararQualidade(g);
                        g.Clear(Color.Transparent);
                        using (var path = Tema.Arredondado(new RectangleF(0, 0, largura - 1, altura - 1), 6))
                        {
                            g.SetClip(path);
                            DesenharCobrindo(g, original, new Rectangle(0, 0, largura, altura));
                        }
                    }
                    mini = bmp;
                }
            }
            CacheMiniaturas[chave] = mini;
            return mini;
        }

        /// <summary>Desenha a imagem preenchendo o retângulo inteiro (modo "cover"), recortando o excesso.</summary>
        public static void DesenharCobrindo(Graphics g, Image imagem, Rectangle destino)
        {
            float escala = Math.Max((float)destino.Width / imagem.Width, (float)destino.Height / imagem.Height);
            float w = destino.Width / escala;
            float h = destino.Height / escala;
            var origem = new RectangleF((imagem.Width - w) / 2f, (imagem.Height - h) / 2f, w, h);
            g.DrawImage(imagem, destino, origem, GraphicsUnit.Pixel);
        }

        public static void LimparCacheMiniaturas()
        {
            foreach (var img in CacheMiniaturas.Values) img?.Dispose();
            CacheMiniaturas.Clear();
        }

        private static Image? CarregarArquivo(string caminho)
        {
            try
            {
                if (!File.Exists(caminho)) return null;
                byte[] bytes = File.ReadAllBytes(caminho);
                using (var ms = new MemoryStream(bytes))
                using (var temp = Image.FromStream(ms))
                {
                    return new Bitmap(temp); // cópia independente do stream
                }
            }
            catch (Exception)
            {
                return null; // arquivo corrompido ou formato inválido: a interface mostra o placeholder
            }
        }
    }
}
