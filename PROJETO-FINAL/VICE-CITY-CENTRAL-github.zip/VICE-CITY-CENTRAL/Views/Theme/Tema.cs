using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Linq;
using ViceCityCentral.Models;

namespace ViceCityCentral.Views.Theme
{
    /// <summary>
    /// Identidade visual "Vice City Central": paleta escura com acentos neon,
    /// tipografia e utilitários de desenho reutilizados pelos componentes.
    /// </summary>
    public static class Tema
    {
        // ------------------------------------------------------------ Paleta
        public static readonly Color Fundo = Hex("#0D0B14");
        public static readonly Color Sidebar = Hex("#110D1B");
        public static readonly Color Superficie = Hex("#17121F");
        public static readonly Color SuperficieAlternada = Hex("#1B1526");
        public static readonly Color SuperficieElevada = Hex("#211A31");
        public static readonly Color SuperficieHover = Hex("#2A2140");
        public static readonly Color Borda = Hex("#2D2440");
        public static readonly Color BordaForte = Hex("#46385F");

        public static readonly Color Texto = Hex("#EEEAF6");
        public static readonly Color TextoSecundario = Hex("#A097B8");
        public static readonly Color TextoTerciario = Hex("#6E6589");

        public static readonly Color Rosa = Hex("#FF2E88");
        public static readonly Color Turquesa = Hex("#22D3C5");
        public static readonly Color Lilas = Hex("#B388FF");
        public static readonly Color Roxo = Hex("#7B2FF7");
        public static readonly Color Laranja = Hex("#FFB547");
        public static readonly Color Verde = Hex("#3DDC97");
        public static readonly Color Vermelho = Hex("#FF4D6D");
        public static readonly Color Azul = Hex("#5B8CFF");

        /// <summary>Paleta categórica usada nos gráficos (ordem fixa).</summary>
        public static readonly Color[] PaletaGraficos =
        {
            Rosa, Turquesa, Lilas, Laranja, Azul, Verde, Hex("#F472B6"), Hex("#94A3B8")
        };

        public static Color CorDoNivel(NivelAlerta nivel) => nivel switch
        {
            NivelAlerta.Positivo => Verde,
            NivelAlerta.Atencao => Laranja,
            NivelAlerta.Critico => Vermelho,
            _ => Lilas
        };

        // --------------------------------------------------------- Tipografia
        private static readonly Dictionary<string, Font> CacheFontes = new Dictionary<string, Font>();
        private static string? _familiaTexto;
        private static string? _familiaTitulo;

        public static string FamiliaTexto => _familiaTexto ??= Primeira("Segoe UI", "Inter", "Montserrat", "DejaVu Sans");
        public static string FamiliaTitulo => _familiaTitulo ??= Primeira("Bahnschrift SemiBold", "Bahnschrift", "Montserrat", "Segoe UI Semibold", "Segoe UI");

        public static Font Fonte(float tamanho, FontStyle estilo = FontStyle.Regular) => Obter(FamiliaTexto, tamanho, estilo);
        public static Font FonteTitulo(float tamanho, FontStyle estilo = FontStyle.Regular) => Obter(FamiliaTitulo, tamanho, estilo);

        private static Font Obter(string familia, float tamanho, FontStyle estilo)
        {
            string chave = $"{familia}|{tamanho}|{estilo}";
            if (!CacheFontes.TryGetValue(chave, out Font? f))
            {
                f = new Font(familia, tamanho, estilo, GraphicsUnit.Point);
                CacheFontes[chave] = f;
            }
            return f;
        }

        private static string Primeira(params string[] familias)
        {
            using (var instaladas = new InstalledFontCollection())
            {
                var nomes = new HashSet<string>(instaladas.Families.Select(f => f.Name), StringComparer.OrdinalIgnoreCase);
                foreach (string f in familias)
                    if (nomes.Contains(f)) return f;
            }
            return SystemFonts.DefaultFont.FontFamily.Name;
        }

        // ----------------------------------------------------- Utilitários
        public static Color Hex(string hex)
        {
            hex = hex.TrimStart('#');
            return Color.FromArgb(Convert.ToInt32(hex.Substring(0, 2), 16),
                                  Convert.ToInt32(hex.Substring(2, 2), 16),
                                  Convert.ToInt32(hex.Substring(4, 2), 16));
        }

        public static Color ComAlfa(Color cor, int alfa) => Color.FromArgb(Math.Max(0, Math.Min(255, alfa)), cor);

        /// <summary>Mistura duas cores (t = 0 → a; t = 1 → b).</summary>
        public static Color Misturar(Color a, Color b, float t)
        {
            t = Math.Max(0, Math.Min(1, t));
            return Color.FromArgb(
                (int)(a.R + (b.R - a.R) * t),
                (int)(a.G + (b.G - a.G) * t),
                (int)(a.B + (b.B - a.B) * t));
        }

        public static GraphicsPath Arredondado(RectangleF r, float raio)
        {
            var path = new GraphicsPath();
            float d = Math.Min(raio * 2, Math.Min(r.Width, r.Height));
            if (d <= 1)
            {
                path.AddRectangle(r);
                return path;
            }
            path.AddArc(r.X, r.Y, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        public static void PrepararQualidade(Graphics g)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        }
    }
}
