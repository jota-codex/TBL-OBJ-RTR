using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using ViceCityCentral.Models;
using ViceCityCentral.Services;
using ViceCityCentral.Views.Components;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views
{
    /// <summary>Tela de gerenciamento de missões (relacionadas a personagens e localidades).</summary>
    public class MissoesForm : ModuloCrudForm<Missao>
    {
        private readonly MissaoService _servico = new MissaoService();

        private ComboTema _filtroCategoria = null!;
        private ComboTema _filtroDificuldade = null!;
        private ComboTema _filtroStatus = null!;

        private TextBox _txtNome = null!;
        private ComboTema _cmbPersonagem = null!;
        private ComboTema _cmbLocalidade = null!;
        private ComboTema _cmbCategoria = null!;
        private ComboTema _cmbDificuldade = null!;
        private TextBox _txtRecompensa = null!;
        private MaskedTextBox _txtData = null!;
        private ComboTema _cmbStatus = null!;
        private TextBox _txtDescricao = null!;

        public MissoesForm()
        {
            Construir();
            Grade.CellFormatting += FormatarCelula;
        }

        public override Modulo Modulo => Modulo.Missoes;
        protected override string Titulo => "Missões";
        protected override string Subtitulo => "Operações, corridas e golpes planejados pela organização";
        protected override string Icone => "target";
        protected override Color CorModulo => Tema.Lilas;
        protected override string TextoNovo => "Nova missão";
        protected override string NomeSingular => "missão";
        protected override bool PossuiImagem => false;
        protected override bool CamposDefinemDataCadastro => true;
        protected override int LarguraBusca => 220;
        protected override ServiceBase<Missao> Servico => _servico;

        protected override void CriarFiltros()
        {
            _filtroCategoria = CriarFiltro<CategoriaMissao>("Todas as categorias", 180);
            _filtroDificuldade = CriarFiltro<Dificuldade>("Todas as dificuldades", 185);
            _filtroStatus = CriarFiltro<StatusMissao>("Todos os status", 150);
        }

        protected override void LimparFiltrosEspecificos()
        {
            _filtroCategoria.SelectedIndex = 0;
            _filtroDificuldade.SelectedIndex = 0;
            _filtroStatus.SelectedIndex = 0;
        }

        protected override List<Missao> Pesquisar(string texto)
            => _servico.Pesquisar(new FiltroMissao
            {
                Texto = texto,
                Categoria = ValorFiltro<CategoriaMissao>(_filtroCategoria),
                Dificuldade = ValorFiltro<Dificuldade>(_filtroDificuldade),
                Status = ValorFiltro<StatusMissao>(_filtroStatus)
            });

        protected override void CriarColunas()
        {
            AdicionarColuna("Missao", "Missão", 150, 120);
            AdicionarColuna("Personagem", "Personagem", 105, 90);
            AdicionarColuna("Categoria", "Categoria", 88, 95);
            AdicionarColuna("Dificuldade", "Dificuldade", 70, 80);
            AdicionarColuna("Recompensa", "Recompensa", 85, 90, DataGridViewContentAlignment.MiddleRight);
            AdicionarColuna("Status", "Status", 100, 130);
        }

        protected override object?[] ValoresLinha(Missao m)
            => new object?[]
            {
                m.Nome, m.NomePersonagem ?? "—", m.Categoria.ToDescricao(), m.Dificuldade.ToDescricao(),
                m.Recompensa.ToString("C0", PtBr), m.StatusDescricao
            };

        /// <summary>Colore a dificuldade conforme o nível.</summary>
        private void FormatarCelula(object? sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || Grade.Columns[e.ColumnIndex].Name != "Dificuldade") return;
            if (!(Grade.Rows[e.RowIndex].Tag is Missao m) || e.CellStyle == null) return;
            e.CellStyle.ForeColor = m.Dificuldade switch
            {
                Dificuldade.Facil => Tema.Verde,
                Dificuldade.Media => Tema.Turquesa,
                Dificuldade.Dificil => Tema.Laranja,
                _ => Tema.Vermelho
            };
        }

        protected override void CriarCampos()
        {
            _txtNome = AdicionarTexto("Nome da missão", true, 80, larguraTotal: true);
            _cmbPersonagem = AdicionarComboItens("Personagem relacionado");
            _cmbLocalidade = AdicionarComboItens("Localidade");
            _cmbCategoria = AdicionarCombo<CategoriaMissao>("Categoria");
            _cmbDificuldade = AdicionarCombo<Dificuldade>("Nível de dificuldade");
            _txtRecompensa = AdicionarTexto("Recompensa fictícia (R$)", true, 15, numerico: true, permitirDecimal: true);
            _txtData = AdicionarDataHora("Data de cadastro", true);
            _cmbStatus = AdicionarCombo<StatusMissao>("Status da missão");
            PularCelula();
            _txtDescricao = AdicionarTexto("Descrição", true, 1000, larguraTotal: true, multilinha: true);

            // carrega personagens/localidades antes da primeira exibição
            AtualizarListasAuxiliares();
        }

        /// <summary>Recarrega personagens e localidades disponíveis para associação.</summary>
        protected override void AtualizarListasAuxiliares()
        {
            int? personagem = (_cmbPersonagem.SelectedItem as ItemCombo)?.Id;
            int? localidade = (_cmbLocalidade.SelectedItem as ItemCombo)?.Id;

            _cmbPersonagem.Items.Clear();
            _cmbPersonagem.Items.Add(new ItemCombo(null, "(Nenhum personagem)"));
            foreach (Personagem p in _servico.ListarPersonagens())
                _cmbPersonagem.Items.Add(new ItemCombo(p.Id, p.NomeCompleto));

            _cmbLocalidade.Items.Clear();
            _cmbLocalidade.Items.Add(new ItemCombo(null, "(Nenhuma localidade)"));
            foreach (Localidade l in _servico.ListarLocalidades())
                _cmbLocalidade.Items.Add(new ItemCombo(l.Id, $"{l.Nome} — {l.Regiao}"));

            SelecionarItem(_cmbPersonagem, personagem);
            SelecionarItem(_cmbLocalidade, localidade);
        }

        protected override void PreencherCampos(Missao m)
        {
            _txtNome.Text = m.Nome;
            SelecionarItem(_cmbPersonagem, m.PersonagemId);
            SelecionarItem(_cmbLocalidade, m.LocalidadeId);
            SelecionarCombo(_cmbCategoria, m.Categoria);
            SelecionarCombo(_cmbDificuldade, m.Dificuldade);
            _txtRecompensa.Text = m.Recompensa.ToString("0.##", PtBr);
            _txtData.Text = m.DataCadastro.ToString("dd/MM/yyyy HH:mm", PtBr);
            SelecionarCombo(_cmbStatus, m.Status);
            _txtDescricao.Text = m.Descricao;
        }

        protected override void LimparCampos()
        {
            _txtNome.Clear();
            SelecionarItem(_cmbPersonagem, null);
            SelecionarItem(_cmbLocalidade, null);
            SelecionarCombo(_cmbCategoria, CategoriaMissao.Principal);
            SelecionarCombo(_cmbDificuldade, Dificuldade.Media);
            _txtRecompensa.Text = "0";
            _txtData.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm", PtBr);
            SelecionarCombo(_cmbStatus, StatusMissao.Disponivel);
            _txtDescricao.Clear();
        }

        protected override Missao LerCampos(List<string> erros)
        {
            var m = new Missao
            {
                Nome = _txtNome.Text,
                Descricao = _txtDescricao.Text,
                PersonagemId = (_cmbPersonagem.SelectedItem as ItemCombo)?.Id,
                LocalidadeId = (_cmbLocalidade.SelectedItem as ItemCombo)?.Id,
                Categoria = ValorCombo(_cmbCategoria, CategoriaMissao.Principal),
                Dificuldade = ValorCombo(_cmbDificuldade, Dificuldade.Media),
                Status = ValorCombo(_cmbStatus, StatusMissao.Disponivel)
            };
            decimal? recompensa = LerDecimal(_txtRecompensa, "Recompensa", erros);
            if (recompensa.HasValue) Atribuir(erros, () => m.Recompensa = recompensa.Value);
            DateTime? data = LerDataHora(_txtData, "Data de cadastro", erros);
            if (data.HasValue) m.DataCadastro = data.Value;
            return m;
        }
    }
}
