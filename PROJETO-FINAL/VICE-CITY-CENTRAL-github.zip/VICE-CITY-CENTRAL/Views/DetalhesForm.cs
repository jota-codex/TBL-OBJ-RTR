using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ViceCityCentral.Audio;
using ViceCityCentral.Models;
using ViceCityCentral.Views.Components;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views
{
    /// <summary>
    /// Visualização detalhada de qualquer entidade. Funciona para todos os tipos porque
    /// usa apenas o contrato da classe base (Titulo, ObterDetalhes, NivelStatus...).
    /// </summary>
    public class DetalhesForm : Form
    {
        private readonly Color _cor;

        public DetalhesForm(EntidadeBase entidade)
        {
            _cor = Ui.CorEntidade(entidade);
            Text = $"Detalhes — {entidade.Titulo}";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            KeyPreview = true;
            Size = new Size(860, 540);
            BackColor = Tema.Superficie;
            ForeColor = Tema.Texto;
            Font = Tema.Fonte(10f);
            DoubleBuffered = true;
            Padding = new Padding(1);

            // ---------- coluna da imagem
            var painelImagem = new Panel { Dock = DockStyle.Left, Width = 360, BackColor = Tema.SuperficieElevada, Padding = new Padding(20) };
            // proporção das ilustrações (640x440) para não cortar a arte
            var preview = new ImagemPreview { Dock = DockStyle.Top, Height = 220, Raio = 12, TextoVazio = "Sem imagem cadastrada" };
            var resumo = new Label
            {
                Dock = DockStyle.Top, Height = 64, Text = entidade.Subtitulo, ForeColor = Tema.TextoSecundario,
                Font = Tema.Fonte(9.5f), TextAlign = ContentAlignment.MiddleCenter, Padding = new Padding(0, 12, 0, 0)
            };
            if (entidade is IPossuiImagem comImagem)
                preview.Imagem = Recursos.ImagemEntidade(comImagem.ImagemPath);
            else
            {
                preview.IconeVazio = Ui.IconeEntidade(entidade);
                preview.TextoVazio = entidade.TipoEntidade;
            }
            painelImagem.Controls.Add(resumo);
            painelImagem.Controls.Add(preview);

            // ---------- cabeçalho
            var cabecalho = new Panel { Dock = DockStyle.Top, Height = 96, BackColor = Tema.Superficie };
            var lblTipo = new Label
            {
                Text = entidade.TipoEntidade.ToUpperInvariant() + (entidade.EhNovo ? "" : $"  ·  #{entidade.Id:000}"),
                Font = Tema.Fonte(8.5f, FontStyle.Bold), ForeColor = _cor, AutoSize = true, Location = new Point(26, 22)
            };
            var lblTitulo = new Label
            {
                Text = entidade.Titulo, Font = Tema.FonteTitulo(18f), ForeColor = Tema.Texto, AutoSize = false,
                AutoEllipsis = true, Location = new Point(24, 42), Size = new Size(330, 36)
            };
            var badge = new BadgeLabel(entidade.StatusDescricao, Tema.CorDoNivel(entidade.NivelStatus))
            { Location = new Point(360, 46) };
            var btnFechar = new NeonButton("", VarianteBotao.Fantasma, "close") { Size = new Size(38, 38), Location = new Point(440, 12), DialogResult = DialogResult.OK };
            cabecalho.Controls.AddRange(new Control[] { lblTipo, lblTitulo, badge, btnFechar });
            cabecalho.Resize += (s, e) =>
            {
                btnFechar.Left = cabecalho.Width - btnFechar.Width - 14;
                badge.Left = cabecalho.Width - badge.Width - 24;
                lblTitulo.Width = badge.Left - lblTitulo.Left - 12;
            };

            // ---------- lista de propriedades (ObterDetalhes é polimórfico)
            var tabela = new TableLayoutPanel
            {
                Dock = DockStyle.Top, ColumnCount = 2, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
                BackColor = Tema.Superficie, Padding = new Padding(24, 4, 24, 12)
            };
            tabela.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170));
            tabela.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            foreach (var par in entidade.ObterDetalhes())
            {
                if (par.Key == "Status") continue; // já exibido no badge
                tabela.Controls.Add(new Label
                {
                    Text = par.Key, AutoSize = true, ForeColor = Tema.TextoSecundario, Font = Tema.Fonte(9f, FontStyle.Bold),
                    Margin = new Padding(0, 9, 8, 9)
                });
                tabela.Controls.Add(new Label
                {
                    Text = par.Value, AutoSize = true, ForeColor = Tema.Texto, Font = Tema.Fonte(10f),
                    MaximumSize = new Size(270, 0), Margin = new Padding(0, 8, 0, 8)
                });
            }
            var rolagem = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Tema.Superficie };
            rolagem.Controls.Add(tabela);

            var rodape = new Panel { Dock = DockStyle.Bottom, Height = 64, BackColor = Tema.Superficie, Padding = new Padding(24, 12, 24, 14) };
            var btnOk = new NeonButton("Fechar", VarianteBotao.Primario) { Dock = DockStyle.Right, Width = 120, DialogResult = DialogResult.OK };
            rodape.Controls.Add(btnOk);
            AcceptButton = btnOk;
            CancelButton = btnOk;

            var direita = new Panel { Dock = DockStyle.Fill, BackColor = Tema.Superficie };
            direita.Controls.Add(rolagem);
            direita.Controls.Add(rodape);
            direita.Controls.Add(cabecalho);

            Controls.Add(direita);
            Controls.Add(painelImagem);

            AudioHooks.Registrar(this);
            Shown += (s, e) => AudioManager.Instancia.Tocar(SomInterface.ModalAbrir);
            FormClosed += (s, e) => AudioManager.Instancia.Tocar(SomInterface.MenuFechar);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();
            base.OnKeyDown(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using (var p = new Pen(Tema.ComAlfa(_cor, 180))) e.Graphics.DrawRectangle(p, 0, 0, Width - 1, Height - 1);
        }

        /// <summary>Pequeno rótulo em forma de pílula para o status.</summary>
        private class BadgeLabel : Control
        {
            private readonly Color _cor;

            public BadgeLabel(string texto, Color cor)
            {
                SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
                Text = texto;
                _cor = cor;
                Font = Tema.Fonte(8.5f, FontStyle.Bold);
                Size = new Size(TextRenderer.MeasureText(texto, Font).Width + 44, 30);
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                e.Graphics.Clear(Parent?.BackColor ?? Tema.Superficie);
                Ui.DesenharBadge(e.Graphics, new Rectangle(-10, 0, Width, Height), Text, _cor, Font);
            }
        }
    }
}
