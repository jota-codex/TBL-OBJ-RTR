using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using ViceCityCentral.Models;
using ViceCityCentral.Services;
using ViceCityCentral.Views.Components;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views
{
    /// <summary>Tela de gerenciamento de personagens.</summary>
    public class PersonagensForm : ModuloCrudForm<Personagem>
    {
        private readonly PersonagemService _servico = new PersonagemService();

        private ComboTema _filtroStatus = null!;

        private TextBox _txtNome = null!;
        private TextBox _txtSobrenome = null!;
        private TextBox _txtIdade = null!;
        private ComboTema _cmbGenero = null!;
        private TextBox _txtProfissao = null!;
        private TextBox _txtNacionalidade = null!;
        private ComboTema _cmbStatus = null!;
        private TextBox _txtDescricao = null!;

        public PersonagensForm()
        {
            Construir();
        }

        public override Modulo Modulo => Modulo.Personagens;
        protected override string Titulo => "Personagens";
        protected override string Subtitulo => "Gerencie os personagens que circulam por Vice City e Leonida";
        protected override string Icone => "account-group";
        protected override Color CorModulo => Tema.Rosa;
        protected override string TextoNovo => "Novo personagem";
        protected override string NomeSingular => "personagem";
        protected override bool PossuiImagem => true;
        protected override ServiceBase<Personagem> Servico => _servico;

        protected override void CriarFiltros()
        {
            _filtroStatus = CriarFiltro<StatusPersonagem>("Todos os status");
        }

        protected override void LimparFiltrosEspecificos() => _filtroStatus.SelectedIndex = 0;

        protected override List<Personagem> Pesquisar(string texto)
            => _servico.Pesquisar(new FiltroPersonagem { Texto = texto, Status = ValorFiltro<StatusPersonagem>(_filtroStatus) });

        protected override void CriarColunas()
        {
            AdicionarColuna("Nome", "Personagem", 150, 120);
            AdicionarColuna("Profissao", "Profissão", 130, 90);
            AdicionarColuna("Idade", "Idade", 45, 50, DataGridViewContentAlignment.MiddleCenter);
            AdicionarColuna("Status", "Status", 85, 110);
        }

        protected override object?[] ValoresLinha(Personagem p)
            => new object?[] { p.NomeCompleto, p.Profissao, p.Idade, p.StatusDescricao };

        protected override void CriarCampos()
        {
            _txtNome = AdicionarTexto("Nome", true, 60);
            _txtSobrenome = AdicionarTexto("Sobrenome", true, 60);
            _txtIdade = AdicionarTexto("Idade", true, 3, numerico: true);
            _cmbGenero = AdicionarCombo<Genero>("Gênero");
            _txtProfissao = AdicionarTexto("Profissão / Ocupação", true, 80);
            _txtNacionalidade = AdicionarTexto("Nacionalidade", true, 60);
            _cmbStatus = AdicionarCombo<StatusPersonagem>("Status");
            PularCelula();
            _txtDescricao = AdicionarTexto("Descrição", false, 1000, larguraTotal: true, multilinha: true);
        }

        protected override void PreencherCampos(Personagem p)
        {
            _txtNome.Text = p.Nome;
            _txtSobrenome.Text = p.Sobrenome;
            _txtIdade.Text = p.Idade.ToString();
            SelecionarCombo(_cmbGenero, p.Genero);
            _txtProfissao.Text = p.Profissao;
            _txtNacionalidade.Text = p.Nacionalidade;
            SelecionarCombo(_cmbStatus, p.Status);
            _txtDescricao.Text = p.Descricao;
        }

        protected override void LimparCampos()
        {
            _txtNome.Clear();
            _txtSobrenome.Clear();
            _txtIdade.Clear();
            SelecionarCombo(_cmbGenero, Genero.NaoInformado);
            _txtProfissao.Clear();
            _txtNacionalidade.Clear();
            SelecionarCombo(_cmbStatus, StatusPersonagem.Ativo);
            _txtDescricao.Clear();
        }

        protected override Personagem LerCampos(List<string> erros)
        {
            var p = new Personagem
            {
                Nome = _txtNome.Text,
                Sobrenome = _txtSobrenome.Text,
                Genero = ValorCombo(_cmbGenero, Genero.NaoInformado),
                Profissao = _txtProfissao.Text,
                Nacionalidade = _txtNacionalidade.Text,
                Status = ValorCombo(_cmbStatus, StatusPersonagem.Ativo),
                Descricao = _txtDescricao.Text
            };
            int? idade = LerInteiro(_txtIdade, "Idade", erros);
            if (idade.HasValue) Atribuir(erros, () => p.Idade = idade.Value);
            return p;
        }
    }
}
