using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views.Components
{
    /// <summary>Exibe uma imagem com cantos arredondados no modo "cover" ou um placeholder.</summary>
    public class ImagemPreview : Control
    {
        private Image? _imagem;

        public ImagemPreview()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw, true);
            Font = Tema.Fonte(9f);
        }

        public string TextoVazio { get; set; } = "Sem imagem";
        public string IconeVazio { get; set; } = "image-plus";
        public int Raio { get; set; } = 10;

        /// <summary>A imagem passa a pertencer ao controle (é descartada ao trocar).</summary>
        public Image? Imagem
        {
            get => _imagem;
            set
            {
                if (ReferenceEquals(_imagem, value)) return;
                _imagem?.Dispose();
                _imagem = value;
                Invalidate();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) { _imagem?.Dispose(); _imagem = null; }
            base.Dispose(disposing);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Parent?.BackColor ?? Tema.Superficie);
            Tema.PrepararQualidade(g);
            var r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f);

            using (GraphicsPath path = Tema.Arredondado(r, Raio))
            {
                if (_imagem != null)
                {
                    g.SetClip(path);
                    Recursos.DesenharCobrindo(g, _imagem, ClientRectangle);
                    g.ResetClip();
                    using (var p = new Pen(Tema.ComAlfa(Tema.Lilas, 110))) g.DrawPath(p, path);
                }
                else
                {
                    using (var b = new SolidBrush(Tema.SuperficieElevada)) g.FillPath(b, path);
                    using (var p = new Pen(Tema.BordaForte) { DashStyle = DashStyle.Dash }) g.DrawPath(p, path);
                    int tam = 34;
                    Image? ic = Recursos.Icone(IconeVazio, Tema.TextoTerciario, tam);
                    if (ic != null) g.DrawImage(ic, (Width - tam) / 2, Height / 2 - tam + 2, tam, tam);
                    TextRenderer.DrawText(g, TextoVazio, Font, new Rectangle(0, Height / 2 + 6, Width, 20), Tema.TextoTerciario,
                        TextFormatFlags.HorizontalCenter | TextFormatFlags.Top);
                }
            }
        }
    }
}
