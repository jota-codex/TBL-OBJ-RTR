using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views.Components
{
    /// <summary>Painel em formato de "card": fundo elevado, cantos arredondados e borda discreta.</summary>
    public class CardPanel : Panel
    {
        private Color? _corDestaque;
        private string _titulo = string.Empty;

        public CardPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw, true);
            BackColor = Tema.Superficie;
            ForeColor = Tema.Texto;
            Padding = new Padding(18);
            Margin = new Padding(8);
        }

        public int Raio { get; set; } = 12;

        /// <summary>Cor opcional de uma linha fina no topo do card.</summary>
        public Color? CorDestaque { get => _corDestaque; set { _corDestaque = value; Invalidate(); } }

        /// <summary>Título opcional desenhado no topo (reserve Padding.Top suficiente).</summary>
        [DefaultValue("")]
        public string Titulo
        {
            get => _titulo;
            set
            {
                _titulo = value ?? string.Empty;
                if (_titulo.Length > 0 && Padding.Top < 48) Padding = new Padding(Padding.Left, 50, Padding.Right, Padding.Bottom);
                Invalidate();
            }
        }

        public string? IconeTitulo { get; set; }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Parent?.BackColor ?? Tema.Fundo);
            Tema.PrepararQualidade(g);
            var r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f);
            using (GraphicsPath path = Tema.Arredondado(r, Raio))
            {
                using (var b = new SolidBrush(BackColor)) g.FillPath(b, path);
                using (var p = new Pen(Tema.Borda)) g.DrawPath(p, path);
            }

            if (CorDestaque.HasValue)
            {
                var linha = new RectangleF(Raio, 0, Width - Raio * 2, 2.5f);
                using (var b = new LinearGradientBrush(new RectangleF(linha.X, 0, linha.Width + 1, 3),
                           CorDestaque.Value, Tema.ComAlfa(CorDestaque.Value, 0), LinearGradientMode.Horizontal))
                    g.FillRectangle(b, linha);
            }

            if (_titulo.Length > 0)
            {
                int x = Padding.Left;
                if (!string.IsNullOrEmpty(IconeTitulo))
                {
                    Image? ic = Recursos.Icone(IconeTitulo!, CorDestaque ?? Tema.Lilas, 18);
                    if (ic != null) g.DrawImage(ic, x, 18, 18, 18);
                    x += 26;
                }
                TextRenderer.DrawText(g, _titulo, Tema.FonteTitulo(12f), new Rectangle(x, 12, Width - x - Padding.Right, 30),
                    Tema.Texto, TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
            }
        }
    }
}
