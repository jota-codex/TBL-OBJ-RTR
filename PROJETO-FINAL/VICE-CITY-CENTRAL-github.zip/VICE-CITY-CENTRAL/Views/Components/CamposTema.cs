using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views.Components
{
    /// <summary>
    /// Moldura escura para TextBox/MaskedTextBox: desenha a borda arredondada e
    /// destaca em rosa quando o campo está em foco.
    /// </summary>
    public class CampoContainer : Panel
    {
        private bool _foco;

        public CampoContainer(Control campo, string? icone = null)
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw, true);
            Campo = campo;
            Icone = icone;
            BackColor = Tema.SuperficieElevada;
            Padding = new Padding(icone == null ? 10 : 36, 8, 10, 6);
            Height = 36;
            campo.BackColor = Tema.SuperficieElevada;
            campo.ForeColor = Tema.Texto;
            campo.Dock = DockStyle.Fill;
            Controls.Add(campo);
            campo.GotFocus += (s, e) => { _foco = true; Invalidate(); };
            campo.LostFocus += (s, e) => { _foco = false; Invalidate(); };
            campo.EnabledChanged += (s, e) => Invalidate();
            Click += (s, e) => campo.Focus();
        }

        public Control Campo { get; }
        public string? Icone { get; }

        /// <summary>Somente leitura: muda a aparência para indicar que não é editável.</summary>
        public bool Bloqueado
        {
            get => Campo is TextBoxBase t && t.ReadOnly;
            set
            {
                if (Campo is TextBoxBase t)
                {
                    t.ReadOnly = value;
                    t.BackColor = value ? Tema.Superficie : Tema.SuperficieElevada;
                    t.ForeColor = value ? Tema.TextoSecundario : Tema.Texto;
                    t.TabStop = !value;
                }
                BackColor = value ? Tema.Superficie : Tema.SuperficieElevada;
                Invalidate();
            }
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Parent?.BackColor ?? Tema.Superficie);
            Tema.PrepararQualidade(g);
            var r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f);
            using (GraphicsPath path = Tema.Arredondado(r, 7))
            {
                using (var b = new SolidBrush(BackColor)) g.FillPath(b, path);
                Color borda = _foco && !Bloqueado ? Tema.Rosa : (Bloqueado ? Tema.Borda : Tema.BordaForte);
                using (var p = new Pen(borda, _foco && !Bloqueado ? 1.5f : 1f)) g.DrawPath(p, path);
            }
            if (Icone != null)
            {
                Image? ic = Recursos.Icone(Icone, _foco ? Tema.Rosa : Tema.TextoSecundario, 18);
                if (ic != null) g.DrawImage(ic, 11, (Height - 18) / 2, 18, 18);
            }
        }
    }

    /// <summary>ComboBox (lista suspensa) com aparência escura desenhada manualmente.</summary>
    public class ComboTema : ComboBox
    {
        private bool _hover;

        public ComboTema()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            DropDownStyle = ComboBoxStyle.DropDownList;
            DrawMode = DrawMode.OwnerDrawFixed;
            FlatStyle = FlatStyle.Flat;
            BackColor = Tema.SuperficieElevada;
            ForeColor = Tema.Texto;
            Font = Tema.Fonte(9.75f);
            ItemHeight = 28;
            IntegralHeight = false;
            MaxDropDownItems = 12;
            Cursor = Cursors.Hand;
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }
        protected override void OnSelectedIndexChanged(EventArgs e) { Invalidate(); base.OnSelectedIndexChanged(e); }
        protected override void OnEnabledChanged(EventArgs e) { Invalidate(); base.OnEnabledChanged(e); }
        protected override void OnDropDownClosed(EventArgs e) { Invalidate(); base.OnDropDownClosed(e); }

        /// <summary>Itens da lista aberta.</summary>
        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            bool selecionado = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
            using (var b = new SolidBrush(selecionado ? Tema.Misturar(Tema.SuperficieElevada, Tema.Rosa, 0.35f) : Tema.SuperficieElevada))
                e.Graphics.FillRectangle(b, e.Bounds);
            var area = new Rectangle(e.Bounds.X + 10, e.Bounds.Y, e.Bounds.Width - 12, e.Bounds.Height);
            TextRenderer.DrawText(e.Graphics, GetItemText(Items[e.Index]), Font, area, selecionado ? Color.White : Tema.Texto,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
        }

        /// <summary>Área fechada do combo.</summary>
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Parent?.BackColor ?? Tema.Superficie);
            Tema.PrepararQualidade(g);
            var r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f);
            Color fundo = Enabled ? (_hover ? Tema.SuperficieHover : Tema.SuperficieElevada) : Tema.Superficie;
            Color borda = Focused && Enabled ? Tema.Rosa : (Enabled ? Tema.BordaForte : Tema.Borda);
            using (GraphicsPath path = Tema.Arredondado(r, 7))
            {
                using (var b = new SolidBrush(fundo)) g.FillPath(b, path);
                using (var p = new Pen(borda, Focused && Enabled ? 1.5f : 1f)) g.DrawPath(p, path);
            }

            string texto = SelectedIndex >= 0 ? GetItemText(SelectedItem) : string.Empty;
            TextRenderer.DrawText(g, texto, Font, new Rectangle(10, 0, Width - 38, Height), Enabled ? Tema.Texto : Tema.TextoSecundario,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);

            // seta (chevron)
            float cx = Width - 18, cy = Height / 2f;
            using (var p = new Pen(Enabled ? (_hover || Focused ? Tema.Rosa : Tema.TextoSecundario) : Tema.TextoTerciario, 1.8f))
            {
                p.StartCap = LineCap.Round;
                p.EndCap = LineCap.Round;
                g.DrawLines(p, new[] { new PointF(cx - 4.5f, cy - 2), new PointF(cx, cy + 2.5f), new PointF(cx + 4.5f, cy - 2) });
            }
        }
    }

    /// <summary>Interruptor (liga/desliga) para as preferências.</summary>
    public class ToggleSwitch : Control
    {
        private bool _ligado;

        public ToggleSwitch(string texto)
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            Text = texto;
            Height = 34;
            Cursor = Cursors.Hand;
            Font = Tema.Fonte(9.75f);
            TabStop = true;
        }

        public event EventHandler? AlteradoPeloUsuario;

        public bool Ligado
        {
            get => _ligado;
            set { _ligado = value; Invalidate(); }
        }

        protected override void OnClick(EventArgs e)
        {
            Focus();
            Ligado = !Ligado;
            AlteradoPeloUsuario?.Invoke(this, EventArgs.Empty);
            base.OnClick(e);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space) OnClick(EventArgs.Empty);
            base.OnKeyUp(e);
        }

        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Parent?.BackColor ?? Tema.Superficie);
            Tema.PrepararQualidade(g);
            var trilho = new RectangleF(0, (Height - 22) / 2f, 42, 22);
            using (GraphicsPath p = Tema.Arredondado(trilho, 11))
            {
                if (Ligado)
                    using (var b = new LinearGradientBrush(trilho, Tema.Rosa, Tema.Roxo, LinearGradientMode.Horizontal)) g.FillPath(b, p);
                else
                    using (var b = new SolidBrush(Tema.SuperficieHover)) g.FillPath(b, p);
                using (var pen = new Pen(Focused ? Tema.Turquesa : Tema.BordaForte)) g.DrawPath(pen, p);
            }
            float xBola = Ligado ? trilho.Right - 19 : trilho.X + 3;
            using (var b = new SolidBrush(Color.White)) g.FillEllipse(b, xBola, trilho.Y + 3, 16, 16);

            TextRenderer.DrawText(g, Text, Font, new Rectangle(54, 0, Width - 54, Height), Tema.Texto,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
        }
    }

    /// <summary>Item genérico para ComboBox (ID opcional + texto).</summary>
    public class ItemCombo
    {
        public ItemCombo(int? id, string texto) { Id = id; Texto = texto; }
        public int? Id { get; }
        public string Texto { get; }
        public override string ToString() => Texto;
    }
}
