using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views.Components
{
    /// <summary>Item do menu lateral, com indicador neon quando ativo.</summary>
    public class SidebarButton : Control
    {
        private bool _hover;
        private bool _ativo;

        public SidebarButton(string texto, string icone, string atalho = "")
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            Text = texto;
            Icone = icone;
            Atalho = atalho;
            Height = 46;
            Cursor = Cursors.Hand;
            Font = Tema.Fonte(10.5f, FontStyle.Regular);
            BackColor = Color.Transparent;
        }

        public string Icone { get; }
        public string Atalho { get; }

        public bool Ativo
        {
            get => _ativo;
            set { _ativo = value; Invalidate(); }
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Tema.PrepararQualidade(g);

            var area = new RectangleF(12, 3, Width - 24, Height - 6);
            using (GraphicsPath path = Tema.Arredondado(area, 8))
            {
                if (Ativo)
                {
                    using (var b = new LinearGradientBrush(area, Tema.ComAlfa(Tema.Rosa, 70), Tema.ComAlfa(Tema.Roxo, 15), LinearGradientMode.Horizontal))
                        g.FillPath(b, path);
                    using (var p = new Pen(Tema.ComAlfa(Tema.Rosa, 90))) g.DrawPath(p, path);
                }
                else if (_hover)
                {
                    using (var b = new SolidBrush(Tema.ComAlfa(Tema.SuperficieHover, 220))) g.FillPath(b, path);
                }
            }

            if (Ativo)
            {
                // barra indicadora à esquerda
                var barra = new RectangleF(0, 10, 4, Height - 20);
                using (var b = new LinearGradientBrush(barra, Tema.Rosa, Tema.Lilas, LinearGradientMode.Vertical))
                using (GraphicsPath p = Tema.Arredondado(barra, 2))
                    g.FillPath(b, p);
            }

            Color corIcone = Ativo ? Tema.Rosa : (_hover ? Tema.Turquesa : Tema.TextoSecundario);
            Color corTexto = Ativo || _hover ? Tema.Texto : Tema.TextoSecundario;

            Image? icone = Recursos.Icone(Icone, corIcone, 20);
            if (icone != null) g.DrawImage(icone, 28, (Height - 20) / 2, 20, 20);

            var font = Ativo ? Tema.Fonte(10.5f, FontStyle.Bold) : Font;
            TextRenderer.DrawText(g, Text, font, new Rectangle(60, 0, Width - 100, Height), corTexto,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);

            if (!string.IsNullOrEmpty(Atalho))
                TextRenderer.DrawText(g, Atalho, Tema.Fonte(7.5f), new Rectangle(Width - 46, 0, 30, Height), Tema.TextoTerciario,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
        }
    }
}
