using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ViceCityCentral.Audio;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views.Components
{
    /// <summary>Controle deslizante de volume (0–100%) com o visual neon do sistema.</summary>
    public class VolumeSlider : Control
    {
        private int _valor;
        private bool _arrastando;
        private bool _hover;

        public VolumeSlider()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            Height = 28;
            Cursor = Cursors.Hand;
            TabStop = true;
        }

        public Color Cor { get; set; } = Tema.Rosa;

        /// <summary>Alterado enquanto o usuário arrasta (aplicação imediata do volume).</summary>
        public event EventHandler? ValorAlterado;

        /// <summary>O usuário terminou o ajuste (momento de salvar a preferência).</summary>
        public event EventHandler? SoltoPeloUsuario;

        public int Valor
        {
            get => _valor;
            set
            {
                int v = Math.Max(0, Math.Min(100, value));
                if (v == _valor) return;
                _valor = v;
                Invalidate();
                ValorAlterado?.Invoke(this, EventArgs.Empty);
            }
        }

        private RectangleF Trilho => new RectangleF(9, Height / 2f - 3, Width - 18, 6);

        private void DefinirPorX(int x) => Valor = (int)Math.Round((x - Trilho.X) / Trilho.Width * 100);

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && Enabled) { Focus(); _arrastando = true; DefinirPorX(e.X); }
            base.OnMouseDown(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (_arrastando) DefinirPorX(e.X);
            base.OnMouseMove(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (_arrastando) { _arrastando = false; SoltoPeloUsuario?.Invoke(this, EventArgs.Empty); }
            base.OnMouseUp(e);
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            if (!Enabled) return;
            Valor += e.Delta > 0 ? 5 : -5;
            SoltoPeloUsuario?.Invoke(this, EventArgs.Empty);
            base.OnMouseWheel(e);
        }

        protected override bool IsInputKey(Keys keyData) => keyData == Keys.Left || keyData == Keys.Right || base.IsInputKey(keyData);

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Down) { Valor -= 5; SoltoPeloUsuario?.Invoke(this, EventArgs.Empty); }
            else if (e.KeyCode == Keys.Right || e.KeyCode == Keys.Up) { Valor += 5; SoltoPeloUsuario?.Invoke(this, EventArgs.Empty); }
            base.OnKeyDown(e);
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnEnabledChanged(EventArgs e) { Invalidate(); base.OnEnabledChanged(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Parent?.BackColor ?? Tema.Superficie);
            Tema.PrepararQualidade(g);
            RectangleF trilho = Trilho;
            using (GraphicsPath p = Tema.Arredondado(trilho, 3))
            using (var b = new SolidBrush(Tema.SuperficieHover))
                g.FillPath(b, p);

            float x = trilho.X + trilho.Width * _valor / 100f;
            if (_valor > 0)
            {
                var cheio = new RectangleF(trilho.X, trilho.Y, Math.Max(6, x - trilho.X), trilho.Height);
                Color c1 = Enabled ? Cor : Tema.TextoTerciario;
                Color c2 = Enabled ? Tema.Lilas : Tema.TextoTerciario;
                using (GraphicsPath p = Tema.Arredondado(cheio, 3))
                using (var b = new LinearGradientBrush(new RectangleF(cheio.X - 1, cheio.Y, cheio.Width + 2, cheio.Height), c1, c2, LinearGradientMode.Horizontal))
                    g.FillPath(b, p);
            }

            float r = _hover || _arrastando || Focused ? 8 : 7;
            if (Enabled && (_hover || _arrastando))
                using (var b = new SolidBrush(Tema.ComAlfa(Cor, 60))) g.FillEllipse(b, x - r - 4, Height / 2f - r - 4, (r + 4) * 2, (r + 4) * 2);
            using (var b = new SolidBrush(Enabled ? Color.White : Tema.TextoSecundario)) g.FillEllipse(b, x - r, Height / 2f - r, r * 2, r * 2);
            if (Focused)
                using (var p = new Pen(Tema.Turquesa, 1.5f)) g.DrawEllipse(p, x - r, Height / 2f - r, r * 2, r * 2);
        }
    }

    /// <summary>Pequeno equalizador animado que indica música tocando.</summary>
    public class EqualizadorMini : Control
    {
        private readonly Timer _timer = new Timer { Interval = 90 };
        private readonly float[] _barras = { 0.4f, 0.8f, 0.6f, 0.3f };
        private readonly Random _aleatorio = new Random();
        private bool _ativo;

        public EqualizadorMini()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Size = new Size(22, 18);
            _timer.Tick += (s, e) =>
            {
                for (int i = 0; i < _barras.Length; i++)
                    _barras[i] += ((float)_aleatorio.NextDouble() - _barras[i]) * 0.6f;
                Invalidate();
            };
        }

        public bool Ativo
        {
            get => _ativo;
            set
            {
                if (_ativo == value) return;
                _ativo = value;
                if (value) _timer.Start(); else _timer.Stop();
                Invalidate();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _timer.Dispose();
            base.Dispose(disposing);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float largura = 3, espaco = 2;
            for (int i = 0; i < _barras.Length; i++)
            {
                float h = _ativo ? 3 + _barras[i] * (Height - 3) : 3;
                using (var b = new LinearGradientBrush(new RectangleF(0, 0, Width, Height + 1), Tema.Turquesa, Tema.Rosa, LinearGradientMode.Vertical))
                    g.FillRectangle(b, i * (largura + espaco) + 1, Height - h, largura, h);
            }
        }
    }

    /// <summary>
    /// Barra compacta de áudio (rodapé da sidebar): botão de início da experiência sonora e,
    /// depois de iniciada, atalhos para modo silencioso, música e o painel de ajustes.
    /// </summary>
    public class AudioDock : Panel
    {
        private readonly NeonButton _btnIniciar = new NeonButton("Ativar experiência sonora", VarianteBotao.Secundario, "play-circle");
        private readonly NeonButton _btnMudo = new NeonButton("", VarianteBotao.Fantasma, "volume-high");
        private readonly NeonButton _btnMusica = new NeonButton("", VarianteBotao.Fantasma, "music");
        private readonly NeonButton _btnAjustes = new NeonButton("", VarianteBotao.Fantasma, "tune-vertical");
        private readonly EqualizadorMini _equalizador = new EqualizadorMini();
        private readonly Label _lblFaixa = new Label();
        private readonly ToolTip _dicas = new ToolTip();
        private AudioPanel? _painel;
        private DateTime _painelFechadoEm = DateTime.MinValue;

        public AudioDock()
        {
            SetStyle(ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer, true);
            BackColor = Color.Transparent;
            Height = 52;
            Padding = new Padding(12, 6, 12, 6);

            _btnIniciar.Height = 38;
            _btnIniciar.Font = Tema.Fonte(8.75f, FontStyle.Bold);
            _btnIniciar.Click += (s, e) => AudioManager.Instancia.IniciarExperiencia();
            _dicas.SetToolTip(_btnIniciar, "Inicia a trilha ambiente e os efeitos sonoros da interface");

            foreach (NeonButton b in new[] { _btnIniciar, _btnMudo, _btnMusica, _btnAjustes }) b.BackColor = Color.Transparent;
            foreach (NeonButton b in new[] { _btnMudo, _btnMusica, _btnAjustes }) b.Size = new Size(36, 36);
            _btnMudo.Som = SomInterface.Selecionar;
            _btnMusica.Som = SomInterface.Selecionar;
            _btnMudo.Click += (s, e) => AudioManager.Instancia.AlternarMudo();
            _btnMusica.Click += (s, e) => AudioManager.Instancia.DefinirMusicaAtiva(!AudioManager.Instancia.Preferencias.MusicaAtiva);
            _btnAjustes.Click += (s, e) => AlternarPainel();

            _lblFaixa.AutoSize = false;
            _lblFaixa.AutoEllipsis = true;
            _lblFaixa.BackColor = Color.Transparent;
            _lblFaixa.ForeColor = Tema.TextoSecundario;
            _lblFaixa.Font = Tema.Fonte(8f);
            _lblFaixa.TextAlign = ContentAlignment.MiddleLeft;
            _lblFaixa.Cursor = Cursors.Hand;
            _lblFaixa.Click += (s, e) => AlternarPainel();

            Controls.AddRange(new Control[] { _btnIniciar, _btnMudo, _btnMusica, _equalizador, _lblFaixa, _btnAjustes });
            AudioManager.Instancia.EstadoAlterado += AoMudarEstado;
            Atualizar();
        }

        protected override void OnLayout(LayoutEventArgs levent)
        {
            base.OnLayout(levent);
            int y = (Height - 36) / 2;
            _btnIniciar.Bounds = new Rectangle(Padding.Left, (Height - 38) / 2, Width - Padding.Horizontal, 38);
            _btnMudo.Location = new Point(Padding.Left, y);
            _btnMusica.Location = new Point(Padding.Left + 38, y);
            _equalizador.Location = new Point(Padding.Left + 82, (Height - _equalizador.Height) / 2);
            _btnAjustes.Location = new Point(Width - Padding.Right - 36, y);
            _lblFaixa.Bounds = new Rectangle(Padding.Left + 108, (Height - 18) / 2, Math.Max(10, _btnAjustes.Left - Padding.Left - 112), 18);
        }

        private void AoMudarEstado(object? sender, EventArgs e)
        {
            if (IsDisposed) return;
            if (InvokeRequired) BeginInvoke(new Action(Atualizar));
            else Atualizar();
        }

        /// <summary>Atualiza ícones, dicas e o nome da faixa conforme o estado do áudio.</summary>
        public void Atualizar()
        {
            AudioManager audio = AudioManager.Instancia;
            PreferenciasAudio p = audio.Preferencias;
            bool iniciada = audio.ExperienciaIniciada;

            _btnIniciar.Visible = !iniciada;
            foreach (Control c in new Control[] { _btnMudo, _btnMusica, _btnAjustes, _equalizador, _lblFaixa }) c.Visible = iniciada;

            _btnMudo.Icone = p.Mudo ? "volume-off" : "volume-high";
            _btnMudo.Variante = p.Mudo ? VarianteBotao.Perigo : VarianteBotao.Fantasma;
            _dicas.SetToolTip(_btnMudo, p.Mudo ? "Sair do modo silencioso (Ctrl+M)" : "Ativar modo silencioso (Ctrl+M)");

            _btnMusica.Icone = p.MusicaAtiva ? "music" : "music-off";
            _dicas.SetToolTip(_btnMusica, p.MusicaAtiva ? "Desativar música de fundo" : "Ativar música de fundo");
            _dicas.SetToolTip(_btnAjustes, "Painel de áudio: volumes e efeitos");

            if (!audio.Disponivel) _lblFaixa.Text = "Áudio indisponível";
            else if (p.Mudo) _lblFaixa.Text = "Modo silencioso";
            else if (!p.MusicaAtiva) _lblFaixa.Text = "Música desligada";
            else _lblFaixa.Text = audio.FaixaAtual ?? "Iniciando trilha…";
            _equalizador.Ativo = iniciada && audio.Disponivel && p.MusicaAtiva && !p.Mudo;
            _painel?.Sincronizar();
        }

        private void AlternarPainel()
        {
            if (_painel != null && _painel.Visible) { _painel.Close(); return; }
            // clique no próprio botão logo após fechar (perda de foco) não deve reabrir
            if ((DateTime.Now - _painelFechadoEm).TotalMilliseconds < 250) return;

            Form? dono = FindForm();
            _painel = new AudioPanel();
            _painel.FormClosed += (s, e) => { _painelFechadoEm = DateTime.Now; _painel = null; };
            Point canto = PointToScreen(new Point(Width + 8, Height));
            _painel.Location = new Point(canto.X, Math.Max(0, canto.Y - _painel.Height));
            _painel.Show(dono);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                AudioManager.Instancia.EstadoAlterado -= AoMudarEstado;
                _dicas.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    /// <summary>Painel flutuante de controle de áudio (fecha ao clicar fora).</summary>
    public class AudioPanel : Form
    {
        private readonly ToggleSwitch _tglMudo = new ToggleSwitch("Modo silencioso");
        private readonly ToggleSwitch _tglMusica = new ToggleSwitch("Música de fundo");
        private readonly ToggleSwitch _tglEfeitos = new ToggleSwitch("Efeitos sonoros");
        private readonly VolumeSlider _sldMusica = new VolumeSlider { Cor = Tema.Rosa };
        private readonly VolumeSlider _sldEfeitos = new VolumeSlider { Cor = Tema.Turquesa };
        private readonly Label _lblMusicaPct = new Label();
        private readonly Label _lblEfeitosPct = new Label();
        private readonly Label _lblFaixa = new Label();
        private readonly NeonButton _btnProxima = new NeonButton("Próxima faixa", VarianteBotao.Fantasma, "skip-next");
        private readonly NeonButton _btnTestar = new NeonButton("Testar", VarianteBotao.Fantasma, "speaker");
        private bool _sincronizando;

        public AudioPanel()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            BackColor = Tema.Superficie;
            ForeColor = Tema.Texto;
            Font = Tema.Fonte(9.5f);
            Size = new Size(320, 392);
            DoubleBuffered = true;
            KeyPreview = true;

            var titulo = new Label { Text = "Áudio", Font = Tema.FonteTitulo(13f), ForeColor = Tema.Texto, AutoSize = true, Location = new Point(50, 16) };
            var icone = new PictureBox { Image = Recursos.Icone("volume-high", Tema.Rosa, 22), Size = new Size(26, 26), Location = new Point(18, 16), SizeMode = PictureBoxSizeMode.CenterImage };
            var btnFechar = new NeonButton("", VarianteBotao.Fantasma, "close") { Size = new Size(32, 32), Location = new Point(Width - 46, 12) };
            btnFechar.Som = SomInterface.MenuFechar;
            btnFechar.Click += (s, e) => Close();

            int y = 60;
            _tglMudo.SetBounds(18, y, Width - 36, 32); y += 44;

            Secao("MÚSICA", "music", ref y);
            _tglMusica.SetBounds(18, y, Width - 36, 32); y += 36;
            _sldMusica.SetBounds(18, y, Width - 84, 28);
            Porcentagem(_lblMusicaPct, y); y += 32;
            _lblFaixa.SetBounds(18, y, Width - 150, 30);
            _lblFaixa.ForeColor = Tema.TextoSecundario;
            _lblFaixa.Font = Tema.Fonte(8.25f);
            _lblFaixa.AutoEllipsis = true;
            _lblFaixa.TextAlign = ContentAlignment.MiddleLeft;
            _btnProxima.SetBounds(Width - 136, y - 2, 118, 32);
            y += 44;

            Secao("EFEITOS", "speaker", ref y);
            _tglEfeitos.SetBounds(18, y, Width - 36, 32); y += 36;
            _sldEfeitos.SetBounds(18, y, Width - 84, 28);
            Porcentagem(_lblEfeitosPct, y); y += 34;
            _btnTestar.SetBounds(18, y, 100, 32);
            var nota = new Label
            {
                Text = "Ajustes salvos automaticamente · Ctrl+M silencia", ForeColor = Tema.TextoTerciario, Font = Tema.Fonte(7.75f),
                AutoSize = false, TextAlign = ContentAlignment.MiddleRight, Bounds = new Rectangle(124, y, Width - 142, 32)
            };

            Controls.AddRange(new Control[] { titulo, icone, btnFechar, _tglMudo, _tglMusica, _sldMusica, _lblMusicaPct, _lblFaixa, _btnProxima,
                                              _tglEfeitos, _sldEfeitos, _lblEfeitosPct, _btnTestar, nota });

            AudioManager audio = AudioManager.Instancia;
            _tglMudo.AlteradoPeloUsuario += (s, e) => audio.DefinirMudo(_tglMudo.Ligado);
            _tglMusica.AlteradoPeloUsuario += (s, e) => audio.DefinirMusicaAtiva(_tglMusica.Ligado);
            _tglEfeitos.AlteradoPeloUsuario += (s, e) => audio.DefinirEfeitosAtivos(_tglEfeitos.Ligado);
            _sldMusica.ValorAlterado += (s, e) => { if (!_sincronizando) { audio.DefinirVolumeMusica(_sldMusica.Valor); AtualizarPorcentagens(); } };
            _sldEfeitos.ValorAlterado += (s, e) => { if (!_sincronizando) { audio.DefinirVolumeEfeitos(_sldEfeitos.Valor); AtualizarPorcentagens(); } };
            _sldMusica.SoltoPeloUsuario += (s, e) => audio.SalvarPreferencias();
            _sldEfeitos.SoltoPeloUsuario += (s, e) => audio.SalvarPreferencias();
            _btnProxima.Click += (s, e) => audio.ProximaFaixa();
            _btnTestar.Som = SomInterface.Confirmar;

            AudioHooks.Registrar(this);
            Sincronizar();
            Shown += (s, e) => AudioManager.Instancia.Tocar(SomInterface.MenuAbrir);
        }

        private void Secao(string texto, string icone, ref int y)
        {
            var linha = new Panel { Bounds = new Rectangle(18, y, Width - 36, 1), BackColor = Tema.Borda };
            var ic = new PictureBox { Image = Recursos.Icone(icone, Tema.Lilas, 16), Bounds = new Rectangle(18, y + 10, 18, 18), SizeMode = PictureBoxSizeMode.CenterImage };
            var lbl = new Label { Text = texto, AutoSize = true, Font = Tema.Fonte(8f, FontStyle.Bold), ForeColor = Tema.TextoSecundario, Location = new Point(40, y + 11) };
            Controls.AddRange(new Control[] { linha, ic, lbl });
            y += 34;
        }

        private void Porcentagem(Label lbl, int y)
        {
            lbl.SetBounds(Width - 62, y, 44, 28);
            lbl.TextAlign = ContentAlignment.MiddleRight;
            lbl.Font = Tema.Fonte(9f, FontStyle.Bold);
            lbl.ForeColor = Tema.Texto;
        }

        private void AtualizarPorcentagens()
        {
            _lblMusicaPct.Text = _sldMusica.Valor + "%";
            _lblEfeitosPct.Text = _sldEfeitos.Valor + "%";
        }

        /// <summary>Reflete o estado atual do gerenciador nos controles.</summary>
        public void Sincronizar()
        {
            if (IsDisposed) return;
            _sincronizando = true;
            AudioManager audio = AudioManager.Instancia;
            PreferenciasAudio p = audio.Preferencias;
            _tglMudo.Ligado = p.Mudo;
            _tglMusica.Ligado = p.MusicaAtiva;
            _tglEfeitos.Ligado = p.EfeitosAtivos;
            _sldMusica.Valor = p.VolumeMusica;
            _sldEfeitos.Valor = p.VolumeEfeitos;
            bool som = !p.Mudo && audio.Disponivel;
            _tglMusica.Enabled = som;
            _tglEfeitos.Enabled = som;
            _sldMusica.Enabled = som && p.MusicaAtiva;
            _sldEfeitos.Enabled = som && p.EfeitosAtivos;
            _btnProxima.Enabled = som && p.MusicaAtiva && audio.FaixaAtual != null;
            _btnTestar.Enabled = som && p.EfeitosAtivos;
            _lblFaixa.Text = !audio.Disponivel ? "Dispositivo de som indisponível"
                : audio.FaixaAtual != null ? "♪ " + audio.FaixaAtual + " · trilha original" : "Sem música no momento";
            AtualizarPorcentagens();
            _sincronizando = false;
        }

        protected override void OnDeactivate(EventArgs e)
        {
            base.OnDeactivate(e);
            if (!IsDisposed) Close();
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();
            base.OnKeyDown(e);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            AudioManager.Instancia.SalvarPreferencias();
            AudioManager.Instancia.Tocar(SomInterface.MenuFechar);
            base.OnFormClosed(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            using (var p = new Pen(Tema.BordaForte)) g.DrawRectangle(p, 0, 0, Width - 1, Height - 1);
            using (var b = new LinearGradientBrush(new Rectangle(0, 0, Width, 3), Tema.Rosa, Tema.Turquesa, LinearGradientMode.Horizontal))
                g.FillRectangle(b, 0, 0, Width, 3);
        }
    }
}
