using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using ViceCityCentral.Audio;

namespace ViceCityCentral.Views.Components
{
    /// <summary>
    /// Liga os efeitos sonoros aos controles da interface SEM alterar o comportamento deles:
    /// apenas assina eventos (MouseEnter, MouseDown, DropDown...) depois que os controles existem.
    ///
    /// O registro é recursivo e acompanha o evento ControlAdded, então telas e componentes
    /// criados dinamicamente (módulos abertos depois, diálogos, linhas, filtros) também ganham som.
    /// </summary>
    public static class AudioHooks
    {
        private static readonly ConditionalWeakTable<Control, object> Registrados = new ConditionalWeakTable<Control, object>();
        private static readonly object Marca = new object();

        private static WeakReference<Control>? _ultimoHover;
        private static DateTime _ultimoHoverEm = DateTime.MinValue;
        private static readonly Dictionary<ComboBox, DateTime> UltimaSelecaoCombo = new Dictionary<ComboBox, DateTime>();

        /// <summary>Disparado quando o usuário usa o botão "voltar" do mouse.</summary>
        public static event EventHandler? VoltarSolicitado;

        private static AudioManager Audio => AudioManager.Instancia;

        /// <summary>Registra um controle (normalmente um Form) e todos os filhos, atuais e futuros.</summary>
        public static void Registrar(Control raiz)
        {
            if (raiz == null) return;
            if (Registrados.TryGetValue(raiz, out _)) return;
            Registrados.Add(raiz, Marca);

            AnexarPorTipo(raiz);

            // botão "voltar" do mouse (XButton1) em qualquer ponto da interface
            raiz.MouseDown += (s, e) => { if (e.Button == MouseButtons.XButton1) VoltarSolicitado?.Invoke(s, EventArgs.Empty); };

            raiz.ControlAdded += (s, e) => { if (e.Control != null) Registrar(e.Control); };
            foreach (Control filho in raiz.Controls) Registrar(filho);
        }

        private static void AnexarPorTipo(Control c)
        {
            switch (c)
            {
                case NeonButton botao:
                    AnexarHover(botao);
                    botao.MouseDown += (s, e) => { if (e.Button == MouseButtons.Left && botao.Enabled) TocarClique(botao); };
                    // teclado: Enter/Espaço tocam no KeyDown, antes da ação (que pode abrir um diálogo modal)
                    botao.KeyDown += (s, e) => { if ((e.KeyCode == Keys.Enter || e.KeyCode == Keys.Space) && botao.Enabled) TocarClique(botao); };
                    break;

                case SidebarButton item:
                    AnexarHover(item);
                    item.MouseDown += (s, e) => { if (e.Button == MouseButtons.Left) Audio.Tocar(SomInterface.Clique); };
                    break;

                case StatCard card:
                    AnexarHover(card);
                    card.MouseDown += (s, e) => { if (e.Button == MouseButtons.Left) Audio.Tocar(SomInterface.Clique); };
                    break;

                case ToggleSwitch chave:
                    AnexarHover(chave);
                    chave.MouseDown += (s, e) => { if (e.Button == MouseButtons.Left) Audio.Tocar(SomInterface.Selecionar); };
                    chave.KeyDown += (s, e) => { if (e.KeyCode == Keys.Space) Audio.Tocar(SomInterface.Selecionar); };
                    break;

                case VolumeSlider slider:
                    slider.SoltoPeloUsuario += (s, e) => Audio.Tocar(SomInterface.Selecionar);
                    break;

                case ComboBox combo:
                    combo.DropDown += (s, e) => Audio.Tocar(SomInterface.MenuAbrir);
                    combo.SelectionChangeCommitted += (s, e) =>
                    {
                        UltimaSelecaoCombo[combo] = DateTime.Now;
                        Audio.Tocar(SomInterface.Selecionar);
                    };
                    combo.DropDownClosed += (s, e) =>
                    {
                        // se o usuário escolheu uma opção, o som de seleção já representa o fechamento
                        bool selecionou = UltimaSelecaoCombo.TryGetValue(combo, out DateTime quando) && (DateTime.Now - quando).TotalMilliseconds < 400;
                        if (!selecionou) Audio.Tocar(SomInterface.MenuFechar);
                    };
                    combo.Disposed += (s, e) => UltimaSelecaoCombo.Remove(combo);
                    break;

                case DataGridView grade:
                    grade.CellMouseDown += (s, e) =>
                    {
                        if (e.Button != MouseButtons.Left) return;
                        Audio.Tocar(e.RowIndex >= 0 ? SomInterface.Selecionar : SomInterface.Clique);
                    };
                    break;

                case ListaRegistros lista:
                    lista.MouseDown += (s, e) => { if (e.Button == MouseButtons.Left) Audio.Tocar(SomInterface.Clique); };
                    break;

                case PictureBox imagem when imagem.Cursor == Cursors.Hand:
                    imagem.MouseDown += (s, e) => { if (e.Button == MouseButtons.Left) Audio.Tocar(SomInterface.Clique); };
                    break;
            }
        }

        /// <summary>Som de clique conforme o papel do botão.</summary>
        private static void TocarClique(NeonButton botao)
        {
            // botões dentro de diálogos: o próprio diálogo toca confirmar/cancelar ao fechar
            Form? form = botao.FindForm();
            if (form is MensagemDialog || form is DetalhesForm) return;

            if (botao.Som.HasValue) Audio.Tocar(botao.Som.Value);
            else if (botao.DialogResult == DialogResult.Cancel) Audio.Tocar(SomInterface.Cancelar);
            else Audio.Tocar(SomInterface.Clique);
        }

        /// <summary>Hover com controle de repetição: o mesmo controle não repete o som em sequência.</summary>
        private static void AnexarHover(Control c)
        {
            c.MouseEnter += (s, e) =>
            {
                if (!c.Enabled) return;
                bool mesmo = _ultimoHover != null && _ultimoHover.TryGetTarget(out Control? anterior) && ReferenceEquals(anterior, c);
                if (mesmo && (DateTime.Now - _ultimoHoverEm).TotalMilliseconds < 600) return;
                _ultimoHover = new WeakReference<Control>(c);
                _ultimoHoverEm = DateTime.Now;
                Audio.Tocar(SomInterface.Hover);
            };
        }
    }
}
