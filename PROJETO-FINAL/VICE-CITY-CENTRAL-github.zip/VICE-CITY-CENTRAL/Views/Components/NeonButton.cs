using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ViceCityCentral.Audio;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views.Components
{
    public enum VarianteBotao
    {
        Primario,   // gradiente rosa → roxo
        Secundario, // contorno discreto
        Fantasma,   // apenas texto/ícone
        Perigo,     // contorno vermelho
        Sucesso     // turquesa
    }

    /// <summary>Botão desenhado manualmente com cantos arredondados e efeito "neon" ao passar o mouse.</summary>
    public class NeonButton : Control, IButtonControl
    {
        private bool _hover;
        private bool _pressionado;
        private VarianteBotao _variante = VarianteBotao.Secundario;
        private string? _icone;

        public NeonButton()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor, true);
            Cursor = Cursors.Hand;
            Font = Tema.Fonte(9.75f, FontStyle.Bold);
            Size = new Size(130, 38);
            TabStop = true;
        }

        public NeonButton(string texto, VarianteBotao variante, string? icone = null) : this()
        {
            Text = texto;
            Variante = variante;
            Icone = icone;
            AjustarLargura();
        }

        [DefaultValue(VarianteBotao.Secundario)]
        public VarianteBotao Variante { get => _variante; set { _variante = value; Invalidate(); } }

        /// <summary>Nome do ícone em Assets/Icons (sem extensão).</summary>
        public string? Icone { get => _icone; set { _icone = value; Invalidate(); } }

        public int Raio { get; set; } = 8;

        /// <summary>Efeito sonoro específico do botão (null = clique padrão). Não altera a ação do botão.</summary>
        public SomInterface? Som { get; set; }

        public DialogResult DialogResult { get; set; } = DialogResult.None;

        public void NotifyDefault(bool value) { }

        public void PerformClick()
        {
            if (Enabled && Visible) OnClick(EventArgs.Empty);
        }

        /// <summary>Ajusta a largura ao texto e ícone.</summary>
        public void AjustarLargura(int minimo = 0)
        {
            int largura = TextRenderer.MeasureText(Text ?? "", Font).Width + 32 + (string.IsNullOrEmpty(Icone) ? 0 : 24);
            Width = Math.Max(minimo, largura);
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; _pressionado = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { if (e.Button == MouseButtons.Left) { _pressionado = true; Invalidate(); } base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { _pressionado = false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnEnabledChanged(EventArgs e) { Cursor = Enabled ? Cursors.Hand : Cursors.Default; Invalidate(); base.OnEnabledChanged(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }
        protected override void OnTextChanged(EventArgs e) { Invalidate(); base.OnTextChanged(e); }

        protected override void OnClick(EventArgs e)
        {
            if (!Enabled) return;
            base.OnClick(e);
            if (DialogResult != DialogResult.None && FindForm() is Form f) f.DialogResult = DialogResult;
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Space) PerformClick();
            base.OnKeyUp(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            // fundo transparente: o fundo do controle pai já foi pintado em OnPaintBackground
            Color fundo = Parent?.BackColor ?? Tema.Fundo;
            if (BackColor.A == 255 && fundo.A == 255) g.Clear(fundo);
            Tema.PrepararQualidade(g);

            var r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f);
            Color corTexto;
            using (GraphicsPath path = Tema.Arredondado(r, Raio))
            {
                if (!Enabled)
                {
                    using (var b = new SolidBrush(Tema.ComAlfa(Tema.SuperficieElevada, 160))) g.FillPath(b, path);
                    using (var p = new Pen(Tema.Borda)) g.DrawPath(p, path);
                    corTexto = Tema.TextoTerciario;
                }
                else
                {
                    corTexto = PintarVariante(g, path, r);
                }

                if (Focused && Enabled && ShowFocusCues)
                {
                    using (var p = new Pen(Tema.ComAlfa(Tema.Turquesa, 200), 1.5f) { DashStyle = DashStyle.Dot })
                    using (GraphicsPath foco = Tema.Arredondado(RectangleF.Inflate(r, -3, -3), Raio - 2))
                        g.DrawPath(p, foco);
                }
            }

            // Conteúdo (ícone + texto) centralizado
            Size tamTexto = TextRenderer.MeasureText(Text ?? "", Font);
            int tamIcone = 18;
            bool temTexto = !string.IsNullOrEmpty(Text);
            // em botões estreitos o ícone é omitido para preservar o texto
            bool temIcone = !string.IsNullOrEmpty(Icone) && (!temTexto || tamTexto.Width + tamIcone + 6 + 16 <= Width);
            int larguraTotal = (temTexto ? tamTexto.Width : 0) + (temIcone ? tamIcone + (temTexto ? 6 : 0) : 0);
            int x = (Width - larguraTotal) / 2;
            if (_pressionado) x += 1;

            if (temIcone)
            {
                Image? img = Recursos.Icone(Icone!, corTexto, tamIcone);
                if (img != null) g.DrawImage(img, x, (Height - tamIcone) / 2 + (_pressionado ? 1 : 0), tamIcone, tamIcone);
                x += tamIcone + 6;
            }
            if (temTexto)
            {
                var areaTexto = new Rectangle(x - 2, (_pressionado ? 1 : 0), tamTexto.Width + 4, Height);
                TextRenderer.DrawText(g, Text, Font, areaTexto, corTexto,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis);
            }
        }

        private Color PintarVariante(Graphics g, GraphicsPath path, RectangleF r)
        {
            switch (Variante)
            {
                case VarianteBotao.Primario:
                {
                    Color c1 = _hover ? Tema.Misturar(Tema.Rosa, Color.White, 0.12f) : Tema.Rosa;
                    Color c2 = _hover ? Tema.Misturar(Tema.Roxo, Color.White, 0.12f) : Tema.Roxo;
                    if (_pressionado) { c1 = Tema.Misturar(c1, Color.Black, 0.15f); c2 = Tema.Misturar(c2, Color.Black, 0.15f); }
                    using (var b = new LinearGradientBrush(r, c1, c2, LinearGradientMode.Horizontal)) g.FillPath(b, path);
                    if (_hover)
                        using (var p = new Pen(Tema.ComAlfa(Color.White, 90), 1f)) g.DrawPath(p, path);
                    return Color.White;
                }
                case VarianteBotao.Sucesso:
                {
                    Color fundo = _hover ? Tema.ComAlfa(Tema.Turquesa, 60) : Tema.ComAlfa(Tema.Turquesa, 28);
                    using (var b = new SolidBrush(fundo)) g.FillPath(b, path);
                    using (var p = new Pen(Tema.ComAlfa(Tema.Turquesa, _hover ? 255 : 150), 1.2f)) g.DrawPath(p, path);
                    return _hover ? Color.White : Tema.Turquesa;
                }
                case VarianteBotao.Perigo:
                {
                    Color fundo = _hover ? Tema.ComAlfa(Tema.Vermelho, 70) : Tema.ComAlfa(Tema.Vermelho, 18);
                    using (var b = new SolidBrush(fundo)) g.FillPath(b, path);
                    using (var p = new Pen(Tema.ComAlfa(Tema.Vermelho, _hover ? 255 : 140), 1.2f)) g.DrawPath(p, path);
                    return _hover ? Color.White : Tema.Vermelho;
                }
                case VarianteBotao.Fantasma:
                {
                    if (_hover)
                        using (var b = new SolidBrush(Tema.ComAlfa(Tema.Lilas, 30))) g.FillPath(b, path);
                    return _hover ? Tema.Texto : Tema.TextoSecundario;
                }
                default:
                {
                    using (var b = new SolidBrush(_hover ? Tema.SuperficieHover : Tema.SuperficieElevada)) g.FillPath(b, path);
                    using (var p = new Pen(_hover ? Tema.Turquesa : Tema.BordaForte, 1.2f)) g.DrawPath(p, path);
                    return _hover ? Tema.Turquesa : Tema.Texto;
                }
            }
        }
    }
}
