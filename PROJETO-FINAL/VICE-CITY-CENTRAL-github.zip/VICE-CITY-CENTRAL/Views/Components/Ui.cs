using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ViceCityCentral.Models;
using ViceCityCentral.Services;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views.Components
{
    /// <summary>Fábrica de controles padronizados e utilitários de estilo.</summary>
    public static class Ui
    {
        public static Label Rotulo(string texto, float tamanho = 9f, FontStyle estilo = FontStyle.Bold, Color? cor = null)
            => new Label
            {
                Text = texto, AutoSize = true, Font = Tema.Fonte(tamanho, estilo), ForeColor = cor ?? Tema.TextoSecundario,
                BackColor = Color.Transparent
            };

        public static TextBox CaixaTexto(int maximo = 100, bool multilinha = false)
        {
            var t = new TextBox
            {
                BorderStyle = BorderStyle.None, MaxLength = maximo, Multiline = multilinha, Font = Tema.Fonte(10f),
                BackColor = Tema.SuperficieElevada, ForeColor = Tema.Texto
            };
            if (multilinha) { t.ScrollBars = ScrollBars.Vertical; t.AcceptsReturn = true; }
            return t;
        }

        public static void Placeholder(TextBox caixa, string texto)
        {
#if !MONO
            caixa.PlaceholderText = texto;
#endif
        }

        /// <summary>Restringe a digitação a números (e, opcionalmente, separador decimal).</summary>
        public static void SomenteNumeros(TextBox caixa, bool permitirDecimal = false)
        {
            caixa.KeyPress += (s, e) =>
            {
                if (char.IsControl(e.KeyChar) || char.IsDigit(e.KeyChar)) return;
                if (permitirDecimal && (e.KeyChar == ',' || e.KeyChar == '.') ) return;
                e.Handled = true; // bloqueia letras e símbolos
            };
        }

        /// <summary>Aplica o tema escuro a um DataGridView.</summary>
        public static void EstilizarGrade(DataGridView grade)
        {
            grade.BackgroundColor = Tema.Superficie;
            grade.BorderStyle = BorderStyle.None;
            grade.GridColor = Tema.Borda;
            grade.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            grade.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            grade.EnableHeadersVisualStyles = false;
            grade.RowHeadersVisible = false;
            grade.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grade.MultiSelect = false;
            grade.ReadOnly = true;
            grade.AllowUserToAddRows = false;
            grade.AllowUserToDeleteRows = false;
            grade.AllowUserToResizeRows = false;
            grade.AllowUserToOrderColumns = false;
            grade.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grade.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            grade.ColumnHeadersHeight = 42;
            grade.RowTemplate.Height = 50;
            grade.Font = Tema.Fonte(9.75f);

            grade.ColumnHeadersDefaultCellStyle.BackColor = Tema.SuperficieElevada;
            grade.ColumnHeadersDefaultCellStyle.ForeColor = Tema.TextoSecundario;
            grade.ColumnHeadersDefaultCellStyle.SelectionBackColor = Tema.SuperficieElevada;
            grade.ColumnHeadersDefaultCellStyle.Font = Tema.Fonte(8.5f, FontStyle.Bold);
            grade.ColumnHeadersDefaultCellStyle.Padding = new Padding(10, 0, 4, 0);

            grade.DefaultCellStyle.BackColor = Tema.Superficie;
            grade.DefaultCellStyle.ForeColor = Tema.Texto;
            grade.DefaultCellStyle.SelectionBackColor = Tema.Misturar(Tema.Superficie, Tema.Rosa, 0.22f);
            grade.DefaultCellStyle.SelectionForeColor = Color.White;
            grade.DefaultCellStyle.Padding = new Padding(10, 0, 4, 0);
            grade.DefaultCellStyle.WrapMode = DataGridViewTriState.False;
            AplicarLinhasAlternadas(grade);
        }

        public static void AplicarLinhasAlternadas(DataGridView grade)
        {
            bool alternar = ConfiguracaoService.Instancia.Atual.DestacarLinhasAlternadas;
            grade.AlternatingRowsDefaultCellStyle.BackColor = alternar ? Tema.SuperficieAlternada : Tema.Superficie;
            grade.AlternatingRowsDefaultCellStyle.SelectionBackColor = grade.DefaultCellStyle.SelectionBackColor;
        }

        /// <summary>Desenha um "badge" (pílula colorida) de status.</summary>
        public static void DesenharBadge(Graphics g, Rectangle celula, string texto, Color cor, Font fonte)
        {
            Tema.PrepararQualidade(g);
            Size tam = TextRenderer.MeasureText(texto, fonte);
            int largura = tam.Width + 20;
            int altura = 24;
            var r = new RectangleF(celula.X + 10, celula.Y + (celula.Height - altura) / 2f, largura, altura);
            using (GraphicsPath p = Tema.Arredondado(r, altura / 2f))
            {
                using (var b = new SolidBrush(Tema.ComAlfa(cor, 40))) g.FillPath(b, p);
                using (var pen = new Pen(Tema.ComAlfa(cor, 120))) g.DrawPath(pen, p);
            }
            using (var b = new SolidBrush(cor)) g.FillEllipse(b, r.X + 9, r.Y + altura / 2f - 3, 6, 6);
            TextRenderer.DrawText(g, texto, fonte, new Rectangle((int)r.X + 14, (int)r.Y, largura - 12, altura), cor,
                TextFormatFlags.VerticalCenter | TextFormatFlags.HorizontalCenter | TextFormatFlags.NoPadding);
        }

        /// <summary>Ícone associado a cada tipo de entidade (usado em listas e detalhes).</summary>
        public static string IconeEntidade(EntidadeBase e) => e switch
        {
            Personagem _ => "account-group",
            Veiculo _ => "car-sports",
            Missao _ => "target",
            Localidade _ => "map-marker-radius",
            _ => "information"
        };

        public static Color CorEntidade(EntidadeBase e) => e switch
        {
            Personagem _ => Tema.Rosa,
            Veiculo _ => Tema.Turquesa,
            Missao _ => Tema.Lilas,
            Localidade _ => Tema.Laranja,
            _ => Tema.TextoSecundario
        };
    }
}
