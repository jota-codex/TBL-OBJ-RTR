using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using ViceCityCentral.Audio;
using ViceCityCentral.Services;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views.Components
{
    public enum TipoMensagem { Sucesso, Informacao, Aviso, Erro, Confirmacao }

    /// <summary>Caixa de diálogo com a identidade visual do sistema (substitui o MessageBox padrão).</summary>
    public class MensagemDialog : Form
    {
        private readonly Color _cor;

        public MensagemDialog(TipoMensagem tipo, string titulo, string mensagem, IEnumerable<string>? detalhes = null,
                              string textoConfirmar = "OK", string? textoCancelar = null, bool acaoPerigosa = false)
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            BackColor = Tema.Superficie;
            ForeColor = Tema.Texto;
            Font = Tema.Fonte(10f);
            KeyPreview = true;
            Width = 480;
            Padding = new Padding(28, 24, 28, 20);
            DoubleBuffered = true;

            string icone;
            (icone, _cor) = tipo switch
            {
                TipoMensagem.Sucesso => ("check-circle", Tema.Verde),
                TipoMensagem.Aviso => ("alert", Tema.Laranja),
                TipoMensagem.Erro => ("alert-circle", Tema.Vermelho),
                TipoMensagem.Confirmacao => ("help-circle", acaoPerigosa ? Tema.Vermelho : Tema.Lilas),
                _ => ("information", Tema.Turquesa)
            };

            var cabecalho = new Panel { Dock = DockStyle.Top, Height = 44, BackColor = BackColor };
            var picIcone = new PictureBox { Image = Recursos.Icone(icone, _cor, 32), Size = new Size(36, 36), Location = new Point(0, 2), SizeMode = PictureBoxSizeMode.CenterImage };
            var lblTitulo = new Label
            {
                Text = titulo, Font = Tema.FonteTitulo(14f), ForeColor = Tema.Texto, AutoSize = false,
                Location = new Point(48, 0), Size = new Size(Width - 104, 40), TextAlign = ContentAlignment.MiddleLeft
            };
            cabecalho.Controls.Add(picIcone);
            cabecalho.Controls.Add(lblTitulo);

            int larguraTexto = Width - Padding.Horizontal;
            var lblMensagem = new Label
            {
                Text = mensagem, AutoSize = true, MaximumSize = new Size(larguraTexto, 0), ForeColor = Tema.TextoSecundario,
                Font = Tema.Fonte(10f), Margin = new Padding(0, 10, 0, 6)
            };

            var corpo = new FlowLayoutPanel
            {
                Dock = DockStyle.Top, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink, BackColor = BackColor, Padding = new Padding(0, 6, 0, 8)
            };
            corpo.Controls.Add(lblMensagem);

            List<string> lista = detalhes?.Where(d => !string.IsNullOrWhiteSpace(d)).ToList() ?? new List<string>();
            foreach (string item in lista)
            {
                corpo.Controls.Add(new Label
                {
                    Text = "•  " + item, AutoSize = true, MaximumSize = new Size(larguraTexto, 0), ForeColor = Tema.Texto,
                    Font = Tema.Fonte(9.5f), Margin = new Padding(6, 3, 0, 3)
                });
            }

            var rodape = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom, Height = 52, FlowDirection = FlowDirection.RightToLeft, BackColor = BackColor,
                Padding = new Padding(0, 12, 0, 0)
            };
            var btnOk = new NeonButton(textoConfirmar,
                acaoPerigosa ? VarianteBotao.Perigo : VarianteBotao.Primario,
                tipo == TipoMensagem.Confirmacao ? (acaoPerigosa ? "delete" : "check-circle") : null)
            { DialogResult = DialogResult.OK };
            btnOk.AjustarLargura(110);
            rodape.Controls.Add(btnOk);
            AcceptButton = btnOk;

            if (textoCancelar != null)
            {
                var btnCancelar = new NeonButton(textoCancelar, VarianteBotao.Secundario) { DialogResult = DialogResult.Cancel };
                btnCancelar.AjustarLargura(110);
                rodape.Controls.Add(btnCancelar);
                CancelButton = btnCancelar;
            }
            else
            {
                CancelButton = btnOk;
            }

            Controls.Add(corpo);
            Controls.Add(cabecalho);
            Controls.Add(rodape);

            // altura calculada a partir do conteúdo
            corpo.PerformLayout();
            Height = Padding.Vertical + cabecalho.Height + corpo.PreferredSize.Height + rodape.Height + 8;
            Shown += (s, e) => (textoCancelar != null && acaoPerigosa ? (Control?)CancelButton : btnOk)?.Focus();

            // ---------- áudio: som de abertura conforme o tipo e de confirmação/cancelamento ao fechar
            AudioHooks.Registrar(this);
            SomInterface somAbertura = tipo switch
            {
                TipoMensagem.Sucesso => SomInterface.Sucesso,
                TipoMensagem.Erro => SomInterface.Erro,
                TipoMensagem.Aviso => SomInterface.Erro,
                TipoMensagem.Informacao => SomInterface.Notificacao,
                _ => acaoPerigosa ? SomInterface.Excluir : SomInterface.ModalAbrir
            };
            Shown += (s, e) => AudioManager.Instancia.Tocar(somAbertura);
            bool confirmacao = textoCancelar != null;
            FormClosed += (s, e) => AudioManager.Instancia.Tocar(
                confirmacao ? (DialogResult == DialogResult.OK ? SomInterface.Confirmar : SomInterface.Cancelar) : SomInterface.MenuFechar);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) { DialogResult = CancelButton is NeonButton b && b.DialogResult == DialogResult.Cancel ? DialogResult.Cancel : DialogResult.OK; }
            base.OnKeyDown(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            Tema.PrepararQualidade(g);
            using (var p = new Pen(Tema.BordaForte)) g.DrawRectangle(p, 0, 0, Width - 1, Height - 1);
            using (var b = new LinearGradientBrush(new Rectangle(0, 0, Width, 4), _cor, Tema.ComAlfa(_cor, 0), LinearGradientMode.Horizontal))
                g.FillRectangle(b, 0, 0, Width, 3);
        }
    }

    /// <summary>Fachada estática para exibir mensagens padronizadas em todo o sistema.</summary>
    public static class Mensagem
    {
        private static IWin32Window? Dono(Control? origem) => origem?.FindForm()?.TopLevelControl as Form ?? Form.ActiveForm;

        public static void Sucesso(Control? origem, string mensagem, string titulo = "Operação concluída")
            => Mostrar(origem, TipoMensagem.Sucesso, titulo, mensagem);

        public static void Informacao(Control? origem, string mensagem, string titulo = "Informação")
            => Mostrar(origem, TipoMensagem.Informacao, titulo, mensagem);

        public static void Aviso(Control? origem, string mensagem, IEnumerable<string>? detalhes = null, string titulo = "Atenção")
            => Mostrar(origem, TipoMensagem.Aviso, titulo, mensagem, detalhes);

        public static void Erro(Control? origem, string mensagem, Exception? ex = null, string titulo = "Erro")
        {
            if (ex != null) RegistroErros.Registrar(ex);
            Mostrar(origem, TipoMensagem.Erro, titulo, mensagem);
        }

        public static bool Confirmar(Control? origem, string titulo, string mensagem, string textoSim = "Confirmar",
                                     string textoNao = "Cancelar", bool perigoso = false)
        {
            using (var d = new MensagemDialog(TipoMensagem.Confirmacao, titulo, mensagem, null, textoSim, textoNao, perigoso))
                return d.ShowDialog(Dono(origem)) == DialogResult.OK;
        }

        /// <summary>Notificação rápida e não bloqueante (respeita a preferência do usuário).</summary>
        public static void Notificar(Control? origem, string mensagem, SomInterface som = SomInterface.Sucesso)
        {
            AudioManager.Instancia.Tocar(som); // o som acompanha a ação mesmo se a notificação visual estiver desligada
            if (!ConfiguracaoService.Instancia.Atual.ExibirNotificacoesSucesso) return;
            Form? dono = origem?.FindForm()?.TopLevelControl as Form;
            if (dono == null || !dono.Visible)
            {
                Sucesso(origem, mensagem);
                return;
            }
            new Toast(mensagem, Tema.Verde, "check-circle").Exibir(dono);
        }

        private static void Mostrar(Control? origem, TipoMensagem tipo, string titulo, string mensagem, IEnumerable<string>? detalhes = null)
        {
            using (var d = new MensagemDialog(tipo, titulo, mensagem, detalhes))
                d.ShowDialog(Dono(origem));
        }
    }

    /// <summary>Notificação flutuante no canto inferior direito da janela principal.</summary>
    public class Toast : Form
    {
        private readonly Timer _timer = new Timer();
        private readonly Color _cor;
        private readonly string _icone;
        private readonly string _mensagem;
        private int _ticks;

        public Toast(string mensagem, Color cor, string icone)
        {
            _mensagem = mensagem;
            _cor = cor;
            _icone = icone;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            BackColor = Tema.SuperficieElevada;
            Font = Tema.Fonte(10f);
            DoubleBuffered = true;
            Size = new Size(Math.Min(460, TextRenderer.MeasureText(mensagem, Font).Width + 90), 56);
            _timer.Interval = 40;
            _timer.Tick += (s, e) => Animar();
            Click += (s, e) => Close();
        }

        protected override bool ShowWithoutActivation => true;

        public void Exibir(Form dono)
        {
            Point canto = dono.PointToScreen(new Point(dono.ClientSize.Width, dono.ClientSize.Height));
            Location = new Point(canto.X - Width - 24, canto.Y - Height - 40);
            Opacity = 0;
            Show(dono);
            _timer.Start();
        }

        private void Animar()
        {
            _ticks++;
            if (_ticks <= 6) Opacity = Math.Min(1, _ticks / 6.0);
            else if (_ticks > 70) Opacity = Math.Max(0, 1 - (_ticks - 70) / 8.0);
            if (_ticks >= 78) { _timer.Stop(); Close(); }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _timer.Dispose();
            base.Dispose(disposing);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Tema.PrepararQualidade(g);
            using (var p = new Pen(Tema.ComAlfa(_cor, 160))) g.DrawRectangle(p, 0, 0, Width - 1, Height - 1);
            using (var b = new SolidBrush(_cor)) g.FillRectangle(b, 0, 0, 4, Height);
            Image? ic = Recursos.Icone(_icone, _cor, 22);
            if (ic != null) g.DrawImage(ic, 18, (Height - 22) / 2, 22, 22);
            TextRenderer.DrawText(g, _mensagem, Font, new Rectangle(52, 0, Width - 62, Height), Tema.Texto,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
        }
    }
}
