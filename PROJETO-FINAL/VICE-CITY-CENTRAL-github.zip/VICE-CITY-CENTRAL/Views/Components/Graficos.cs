using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views.Components
{
    /// <summary>Um item de gráfico (rótulo, valor e cor).</summary>
    public class ItemGrafico
    {
        public ItemGrafico(string rotulo, int valor, Color cor) { Rotulo = rotulo; Valor = valor; Cor = cor; }
        public string Rotulo { get; }
        public int Valor { get; }
        public Color Cor { get; }
    }

    /// <summary>
    /// Base abstrata dos gráficos: guarda os dados, trata o estado vazio e o double-buffer.
    /// Cada gráfico concreto implementa apenas o próprio desenho (polimorfismo).
    /// </summary>
    public abstract class GraficoBase : Control
    {
        private List<ItemGrafico> _itens = new List<ItemGrafico>();

        protected GraficoBase()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw, true);
            BackColor = Tema.Superficie;
            Font = Tema.Fonte(9f);
        }

        public IReadOnlyList<ItemGrafico> Itens => _itens;
        protected int Total => _itens.Sum(i => i.Valor);

        public void DefinirDados(IEnumerable<ItemGrafico> itens)
        {
            _itens = itens.ToList();
            Invalidate();
        }

        protected sealed override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(BackColor);
            Tema.PrepararQualidade(g);
            if (_itens.Count == 0 || Total == 0)
            {
                TextRenderer.DrawText(g, "Sem dados cadastrados", Font, ClientRectangle, Tema.TextoTerciario,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                return;
            }
            Desenhar(g, ClientRectangle);
        }

        protected abstract void Desenhar(Graphics g, Rectangle area);
    }

    /// <summary>Gráfico de barras horizontais.</summary>
    public class GraficoBarras : GraficoBase
    {
        protected override void Desenhar(Graphics g, Rectangle area)
        {
            int n = Itens.Count;
            int larguraRotulo = 130;
            int larguraValor = 36;
            float alturaLinha = Math.Min(30f, (area.Height - 4f) / n);
            float alturaBarra = Math.Max(6f, alturaLinha * 0.46f);
            int maximo = Math.Max(1, Itens.Max(i => i.Valor));
            float larguraUtil = area.Width - larguraRotulo - larguraValor - 8;
            float y = area.Top + (area.Height - alturaLinha * n) / 2f;

            foreach (ItemGrafico item in Itens)
            {
                var linha = new Rectangle(area.Left, (int)y, larguraRotulo - 8, (int)alturaLinha);
                TextRenderer.DrawText(g, item.Rotulo, Font, linha, Tema.TextoSecundario,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Right | TextFormatFlags.EndEllipsis);

                float topoBarra = y + (alturaLinha - alturaBarra) / 2f;
                var trilho = new RectangleF(area.Left + larguraRotulo, topoBarra, larguraUtil, alturaBarra);
                using (GraphicsPath p = Tema.Arredondado(trilho, alturaBarra / 2))
                using (var b = new SolidBrush(Tema.SuperficieElevada))
                    g.FillPath(b, p);

                if (item.Valor > 0)
                {
                    float largura = Math.Max(alturaBarra, larguraUtil * item.Valor / maximo);
                    var barra = new RectangleF(trilho.X, topoBarra, largura, alturaBarra);
                    using (GraphicsPath p = Tema.Arredondado(barra, alturaBarra / 2))
                    using (var b = new LinearGradientBrush(new RectangleF(barra.X - 1, barra.Y, barra.Width + 2, barra.Height),
                               Tema.ComAlfa(item.Cor, 150), item.Cor, LinearGradientMode.Horizontal))
                        g.FillPath(b, p);
                }

                TextRenderer.DrawText(g, item.Valor.ToString(), Tema.Fonte(9f, FontStyle.Bold),
                    new Rectangle((int)(trilho.Right + 6), (int)y, larguraValor, (int)alturaLinha), Tema.Texto,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Left);
                y += alturaLinha;
            }
        }
    }

    /// <summary>Gráfico de rosca (donut) com legenda e percentuais.</summary>
    public class GraficoRosca : GraficoBase
    {
        public string RotuloCentral { get; set; } = "total";

        protected override void Desenhar(Graphics g, Rectangle area)
        {
            int diametro = Math.Min(area.Height - 16, (int)(area.Width * 0.46));
            var circulo = new RectangleF(area.Left + 12, area.Top + (area.Height - diametro) / 2f, diametro, diametro);
            float espessura = Math.Max(12f, diametro * 0.16f);
            var anel = RectangleF.Inflate(circulo, -espessura / 2, -espessura / 2);

            using (var trilho = new Pen(Tema.SuperficieElevada, espessura)) g.DrawEllipse(trilho, anel);

            float inicio = -90f;
            int total = Total;
            foreach (ItemGrafico item in Itens.Where(i => i.Valor > 0))
            {
                float angulo = 360f * item.Valor / total;
                using (var p = new Pen(item.Cor, espessura))
                    g.DrawArc(p, anel, inicio + 0.8f, Math.Max(0.5f, angulo - 1.6f));
                inicio += angulo;
            }

            var centro = Rectangle.Round(circulo);
            TextRenderer.DrawText(g, total.ToString(), Tema.FonteTitulo(20f, FontStyle.Bold),
                new Rectangle(centro.X, centro.Y + centro.Height / 2 - 26, centro.Width, 32), Tema.Texto,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            TextRenderer.DrawText(g, RotuloCentral, Tema.Fonte(8.5f), new Rectangle(centro.X, centro.Y + centro.Height / 2 + 4, centro.Width, 18),
                Tema.TextoSecundario, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

            // legenda
            int xLeg = (int)circulo.Right + 24;
            int alturaItem = 30;
            int yLeg = area.Top + (area.Height - alturaItem * Itens.Count) / 2;
            foreach (ItemGrafico item in Itens)
            {
                using (var b = new SolidBrush(item.Cor)) g.FillEllipse(b, xLeg, yLeg + 10, 10, 10);
                TextRenderer.DrawText(g, item.Rotulo, Font, new Rectangle(xLeg + 18, yLeg, area.Right - xLeg - 90, alturaItem),
                    Tema.TextoSecundario, TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
                string pct = total == 0 ? "0%" : $"{Math.Round(100.0 * item.Valor / total)}%";
                TextRenderer.DrawText(g, $"{item.Valor}  ·  {pct}", Tema.Fonte(9f, FontStyle.Bold),
                    new Rectangle(area.Right - 86, yLeg, 80, alturaItem), Tema.Texto,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
                yLeg += alturaItem;
            }
        }
    }
}
