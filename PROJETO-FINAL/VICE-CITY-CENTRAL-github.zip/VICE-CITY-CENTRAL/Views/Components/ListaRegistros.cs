using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using ViceCityCentral.Models;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views.Components
{
    /// <summary>
    /// Lista dos últimos registros do Dashboard. Recebe entidades de tipos diferentes
    /// e usa as propriedades polimórficas (Titulo, Subtitulo, StatusDescricao, NivelStatus).
    /// </summary>
    public class ListaRegistros : Control
    {
        private const int AlturaLinha = 52;
        private List<EntidadeBase> _itens = new List<EntidadeBase>();
        private int _indiceHover = -1;
        private readonly ToolTip _dica = new ToolTip();

        public ListaRegistros()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw, true);
            BackColor = Tema.Superficie;
            Font = Tema.Fonte(9.5f);
            _dica.SetToolTip(this, "Clique para abrir o registro no módulo correspondente");
        }

        /// <summary>Disparado ao clicar em um registro.</summary>
        public event EventHandler<EntidadeBase>? RegistroSelecionado;

        public void DefinirItens(IEnumerable<EntidadeBase> itens)
        {
            _itens = itens.ToList();
            Invalidate();
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int indice = e.Y / AlturaLinha;
            if (indice >= _itens.Count) indice = -1;
            if (indice != _indiceHover)
            {
                _indiceHover = indice;
                Cursor = indice >= 0 ? Cursors.Hand : Cursors.Default;
                Invalidate();
            }
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            _indiceHover = -1;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            int indice = e.Y / AlturaLinha;
            if (indice >= 0 && indice < _itens.Count) RegistroSelecionado?.Invoke(this, _itens[indice]);
            base.OnMouseClick(e);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _dica.Dispose();
            base.Dispose(disposing);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(BackColor);
            Tema.PrepararQualidade(g);

            if (_itens.Count == 0)
            {
                TextRenderer.DrawText(g, "Nenhum registro cadastrado ainda", Font, ClientRectangle, Tema.TextoTerciario,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                return;
            }

            var cultura = new CultureInfo("pt-BR");
            for (int i = 0; i < _itens.Count; i++)
            {
                EntidadeBase item = _itens[i];
                int y = i * AlturaLinha;
                if (y > Height) break;
                var linha = new Rectangle(0, y, Width, AlturaLinha);

                if (i == _indiceHover)
                    using (GraphicsPath p = Tema.Arredondado(new RectangleF(0, y + 2, Width - 1, AlturaLinha - 4), 8))
                    using (var b = new SolidBrush(Tema.SuperficieHover))
                        g.FillPath(b, p);
                else if (i > 0)
                    using (var p = new Pen(Tema.Borda)) g.DrawLine(p, 8, y, Width - 8, y);

                Color cor = Ui.CorEntidade(item);
                var caixa = new RectangleF(8, y + 9, 34, 34);
                using (GraphicsPath p = Tema.Arredondado(caixa, 9))
                using (var b = new SolidBrush(Tema.ComAlfa(cor, 36)))
                    g.FillPath(b, p);
                Image? ic = Recursos.Icone(Ui.IconeEntidade(item), cor, 18);
                if (ic != null) g.DrawImage(ic, 16, y + 17, 18, 18);

                int larguraStatus = 120;
                int larguraData = 110;
                int xTexto = 54;
                int larguraTexto = Width - xTexto - larguraStatus - larguraData - 8;
                TextRenderer.DrawText(g, item.Titulo, Tema.Fonte(9.75f, FontStyle.Bold),
                    new Rectangle(xTexto, y + 7, larguraTexto, 20), Tema.Texto, TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
                TextRenderer.DrawText(g, $"{item.TipoEntidade} · {item.Subtitulo}", Tema.Fonte(8.5f),
                    new Rectangle(xTexto, y + 27, larguraTexto, 18), Tema.TextoSecundario, TextFormatFlags.Left | TextFormatFlags.EndEllipsis);

                TextRenderer.DrawText(g, item.DataCadastro.ToString("dd/MM/yy HH:mm", cultura), Tema.Fonte(8.5f),
                    new Rectangle(Width - larguraStatus - larguraData, y, larguraData, AlturaLinha), Tema.TextoTerciario,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Right);

                Ui.DesenharBadge(g, new Rectangle(Width - larguraStatus, y, larguraStatus, AlturaLinha), item.StatusDescricao,
                    Tema.CorDoNivel(item.NivelStatus), Tema.Fonte(8f, FontStyle.Bold));
            }
        }
    }
}
