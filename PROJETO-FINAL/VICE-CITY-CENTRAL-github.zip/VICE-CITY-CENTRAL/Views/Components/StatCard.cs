using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views.Components
{
    /// <summary>Card de indicador do Dashboard (ícone, título, valor e descrição).</summary>
    public class StatCard : Control
    {
        private bool _hover;
        private string _valor = "0";
        private string _descricao = string.Empty;

        public StatCard(string titulo, string icone, Color cor)
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw, true);
            Titulo = titulo;
            Icone = icone;
            Cor = cor;
            Margin = new Padding(6);
            Height = 108;
        }

        public string Titulo { get; }
        public string Icone { get; }
        public Color Cor { get; }

        public string Valor { get => _valor; set { _valor = value; Invalidate(); } }
        public string Descricao { get => _descricao; set { _descricao = value; Invalidate(); } }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Parent?.BackColor ?? Tema.Fundo);
            Tema.PrepararQualidade(g);

            var r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f);
            using (GraphicsPath path = Tema.Arredondado(r, 12))
            {
                using (var b = new LinearGradientBrush(r, Tema.Superficie, Tema.Misturar(Tema.Superficie, Cor, 0.08f), LinearGradientMode.ForwardDiagonal))
                    g.FillPath(b, path);
                using (var p = new Pen(_hover ? Tema.ComAlfa(Cor, 200) : Tema.Borda, _hover ? 1.4f : 1f)) g.DrawPath(p, path);
            }

            // brilho decorativo no canto
            using (var gp = new GraphicsPath())
            {
                gp.AddEllipse(Width - 70, -40, 110, 110);
                using (var pgb = new PathGradientBrush(gp) { CenterColor = Tema.ComAlfa(Cor, 45), SurroundColors = new[] { Tema.ComAlfa(Cor, 0) } })
                {
                    g.SetClip(r);
                    g.FillPath(pgb, gp);
                    g.ResetClip();
                }
            }

            // ícone em "pílula"
            var caixaIcone = new RectangleF(16, 18, 40, 40);
            using (GraphicsPath p = Tema.Arredondado(caixaIcone, 10))
            using (var b = new SolidBrush(Tema.ComAlfa(Cor, 38)))
                g.FillPath(b, p);
            Image? ic = Recursos.Icone(Icone, Cor, 22);
            if (ic != null) g.DrawImage(ic, 25, 27, 22, 22);

            int xTexto = 68;
            TextRenderer.DrawText(g, Titulo.ToUpperInvariant(), Tema.Fonte(8f, FontStyle.Bold), new Rectangle(xTexto, 16, Width - xTexto - 8, 18),
                Tema.TextoSecundario, TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
            TextRenderer.DrawText(g, Valor, Tema.FonteTitulo(22f, FontStyle.Bold), new Rectangle(xTexto - 3, 32, Width - xTexto, 40),
                Tema.Texto, TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
            TextRenderer.DrawText(g, Descricao, Tema.Fonte(8.25f), new Rectangle(16, Height - 30, Width - 24, 20),
                Tema.ComAlfa(Cor, 255), TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
        }
    }
}
