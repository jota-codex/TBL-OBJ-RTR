using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using ViceCityCentral.Audio;
using ViceCityCentral.Exceptions;
using ViceCityCentral.Models;
using ViceCityCentral.Services;
using ViceCityCentral.Views.Components;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views
{
    /// <summary>
    /// Tela genérica de cadastro (CRUD) reutilizada pelos quatro módulos.
    /// Concentra layout, pesquisa, filtros, listagem, estados de edição, imagem e tratamento de erros.
    /// Cada módulo concreto informa apenas: colunas, campos, filtros e como ler/preencher a entidade.
    /// </summary>
    public abstract class ModuloCrudForm<T> : ModuloBaseForm where T : EntidadeBase
    {
        protected enum ModoEdicao { Vazio, Visualizando, Novo, Editando }

        protected static readonly CultureInfo PtBr = new CultureInfo("pt-BR");

        private ModoEdicao _modo = ModoEdicao.Vazio;
        private T? _selecionado;
        private bool _carregando;
        private bool _suprimirFiltros;

        // ------------------------------------------------------------- controles
        protected readonly DataGridView Grade = new DataGridView();
        private readonly TextBox _txtBusca = Ui.CaixaTexto(60);
        private readonly FlowLayoutPanel _barraFiltros = new FlowLayoutPanel();
        private readonly Label _lblContagem = new Label();
        private readonly Label _lblModo = new Label();
        private readonly Label _lblTituloEditor = new Label();
        private readonly NeonButton _btnNovo = new NeonButton();
        private readonly NeonButton _btnSalvar = new NeonButton("Salvar", VarianteBotao.Primario, "content-save");
        private readonly NeonButton _btnEditar = new NeonButton("Editar", VarianteBotao.Secundario, "pencil");
        private readonly NeonButton _btnExcluir = new NeonButton("Excluir", VarianteBotao.Perigo, "delete");
        private readonly NeonButton _btnCancelar = new NeonButton("Cancelar", VarianteBotao.Fantasma, "close");
        private readonly NeonButton _btnDetalhes = new NeonButton("Detalhes", VarianteBotao.Sucesso, "eye");
        private readonly NeonButton _btnLimparFiltros = new NeonButton("Limpar filtros", VarianteBotao.Fantasma, "filter-remove");
        private readonly TableLayoutPanel _tabelaCampos = new TableLayoutPanel();
        private readonly List<CampoContainer> _containers = new List<CampoContainer>();
        private readonly List<Control> _controlesEditaveis = new List<Control>();
        private readonly Timer _timerBusca = new Timer { Interval = 300 };
        private readonly ToolTip _dicas = new ToolTip();

        private int _linhaCampo;
        private int _colunaCampo;

        // imagem
        private ImagemPreview? _preview;
        private NeonButton? _btnImagem;
        private NeonButton? _btnRemoverImagem;
        private string? _imagemAtual;
        private string? _imagemPendente;
        private bool _imagemRemovida;

        // ========================================================= contrato dos módulos
        protected abstract string Titulo { get; }
        protected abstract string Subtitulo { get; }
        protected abstract string Icone { get; }
        protected abstract Color CorModulo { get; }
        /// <summary>Ex.: "Novo personagem", "Nova missão".</summary>
        protected abstract string TextoNovo { get; }
        /// <summary>Ex.: "personagem", "missão" (usado nas mensagens).</summary>
        protected abstract string NomeSingular { get; }
        protected abstract bool PossuiImagem { get; }
        protected abstract ServiceBase<T> Servico { get; }

        protected abstract void CriarFiltros();
        protected abstract void LimparFiltrosEspecificos();
        protected abstract List<T> Pesquisar(string texto);
        protected abstract void CriarColunas();
        protected abstract object?[] ValoresLinha(T entidade);
        protected abstract void CriarCampos();
        protected abstract void PreencherCampos(T entidade);
        protected abstract void LimparCampos();
        protected abstract T LerCampos(List<string> erros);

        /// <summary>Quando true, a data de cadastro vem dos campos (não é preservada automaticamente).</summary>
        protected virtual bool CamposDefinemDataCadastro => false;

        /// <summary>Atualiza listas auxiliares (combos dependentes de outras tabelas).</summary>
        protected virtual void AtualizarListasAuxiliares() { }

        protected string PastaUploads => Modulo.ToString();

        /// <summary>Largura da caixa de pesquisa (telas com muitos filtros usam uma menor).</summary>
        protected virtual int LarguraBusca => 270;

        protected T? Selecionado => _selecionado;

        // ============================================================== construção
        /// <summary>Monta a interface. Deve ser chamado no final do construtor da tela concreta.</summary>
        protected void Construir()
        {
            SuspendLayout();

            // ---------------- cabeçalho
            Panel cabecalho = CriarCabecalho(Titulo, Subtitulo, Icone, CorModulo);
            _btnNovo.Text = TextoNovo;
            _btnNovo.Icone = "plus";
            _btnNovo.Variante = VarianteBotao.Primario;
            _btnNovo.AjustarLargura(150);
            _btnNovo.Height = 40;
            _btnNovo.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _btnNovo.Click += (s, e) => Novo();
            cabecalho.Controls.Add(_btnNovo);
            cabecalho.Resize += (s, e) => _btnNovo.Location = new Point(cabecalho.Width - _btnNovo.Width, 10);
            _dicas.SetToolTip(_btnNovo, "Cadastrar um novo registro (Ctrl+N)");

            // ---------------- barra de pesquisa e filtros
            var painelFiltros = new Panel { Dock = DockStyle.Top, Height = 52, BackColor = Tema.Fundo, Padding = new Padding(0, 6, 0, 6) };
            _barraFiltros.Dock = DockStyle.Fill;
            _barraFiltros.WrapContents = false;
            _barraFiltros.BackColor = Tema.Fundo;
            _barraFiltros.AutoScroll = false;

            Ui.Placeholder(_txtBusca, "Pesquisar por nome...");
            var buscaContainer = new CampoContainer(_txtBusca, "magnify") { Width = LarguraBusca, Height = 38, Margin = new Padding(0, 0, 10, 0) };
            _txtBusca.TextChanged += (s, e) => { if (!_suprimirFiltros) { _timerBusca.Stop(); _timerBusca.Start(); } };
            _timerBusca.Tick += (s, e) => { _timerBusca.Stop(); CarregarLista(_selecionado?.Id); };
            _barraFiltros.Controls.Add(buscaContainer);
            _dicas.SetToolTip(_txtBusca, "Digite para pesquisar (Ctrl+F)");

            CriarFiltros();

            _btnLimparFiltros.Height = 38;
            _btnLimparFiltros.Margin = new Padding(0);
            _btnLimparFiltros.Click += (s, e) => LimparFiltros();
            _barraFiltros.Controls.Add(_btnLimparFiltros);

            _lblContagem.Dock = DockStyle.Right;
            _lblContagem.Width = 150;
            _lblContagem.TextAlign = ContentAlignment.MiddleRight;
            _lblContagem.ForeColor = Tema.TextoSecundario;
            _lblContagem.Font = Tema.Fonte(9f);
            painelFiltros.Controls.Add(_barraFiltros);
            painelFiltros.Controls.Add(_lblContagem);

            // ---------------- corpo: lista + editor
            var corpo = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Tema.Fundo, Padding = new Padding(0, 8, 0, 0) };
            corpo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 56));
            corpo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 44));
            corpo.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            var cardLista = new CardPanel { Dock = DockStyle.Fill, Padding = new Padding(8), Margin = new Padding(0, 0, 10, 0) };
            ConfigurarGrade();
            cardLista.Controls.Add(Grade);

            var cardEditor = new CardPanel { Dock = DockStyle.Fill, Padding = new Padding(20, 16, 20, 14), Margin = new Padding(6, 0, 0, 0), CorDestaque = CorModulo };
            MontarEditor(cardEditor);

            corpo.Controls.Add(cardLista, 0, 0);
            corpo.Controls.Add(cardEditor, 1, 0);

            Controls.Add(corpo);
            Controls.Add(painelFiltros);
            Controls.Add(cabecalho);

            ResumeLayout(true);

            DefinirModo(ModoEdicao.Vazio);
            CarregarLista(null);
        }

        private void ConfigurarGrade()
        {
            Ui.EstilizarGrade(Grade);
            Grade.Dock = DockStyle.Fill;
            if (PossuiImagem)
            {
                var colFoto = new DataGridViewImageColumn
                {
                    Name = "Foto", HeaderText = "", Width = 78, AutoSizeMode = DataGridViewAutoSizeColumnMode.None,
                    ImageLayout = DataGridViewImageCellLayout.Normal, Resizable = DataGridViewTriState.False,
                    SortMode = DataGridViewColumnSortMode.NotSortable
                };
                colFoto.DefaultCellStyle.NullValue = null;
                colFoto.DefaultCellStyle.Padding = new Padding(10, 0, 0, 0);
                colFoto.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Grade.Columns.Add(colFoto);
            }
            CriarColunas();

            Grade.SelectionChanged += (s, e) =>
            {
                if (_carregando || _modo == ModoEdicao.Novo || _modo == ModoEdicao.Editando) return;
                MostrarSelecionado();
            };
            Grade.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) AbrirDetalhes(); };
            Grade.CellPainting += PintarCelulaStatus;
            Grade.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter) { AbrirDetalhes(); e.Handled = true; }
            };
        }

        private void MontarEditor(CardPanel card)
        {
            // topo: modo + título + botão de detalhes
            var topo = new Panel { Dock = DockStyle.Top, Height = 62, BackColor = Tema.Superficie };
            _lblModo.AutoSize = true;
            _lblModo.Font = Tema.Fonte(8f, FontStyle.Bold);
            _lblModo.Location = new Point(0, 2);
            _lblTituloEditor.AutoSize = false;
            _lblTituloEditor.AutoEllipsis = true;
            _lblTituloEditor.Font = Tema.FonteTitulo(14f);
            _lblTituloEditor.ForeColor = Tema.Texto;
            _lblTituloEditor.Location = new Point(0, 20);
            _lblTituloEditor.Size = new Size(260, 32);
            _btnDetalhes.Height = 36;
            _btnDetalhes.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _btnDetalhes.Click += (s, e) => AbrirDetalhes();
            _dicas.SetToolTip(_btnDetalhes, "Visualizar todas as informações (Enter / duplo clique)");
            topo.Controls.AddRange(new Control[] { _lblModo, _lblTituloEditor, _btnDetalhes });
            topo.Resize += (s, e) =>
            {
                _btnDetalhes.Location = new Point(topo.Width - _btnDetalhes.Width, 12);
                _lblTituloEditor.Width = Math.Max(80, _btnDetalhes.Left - 10);
            };

            // área rolável com imagem + campos
            var rolagem = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Tema.Superficie, Padding = new Padding(0, 6, 4, 6) };

            _tabelaCampos.Dock = DockStyle.Top;
            _tabelaCampos.ColumnCount = 2;
            _tabelaCampos.BackColor = Tema.Superficie;
            _tabelaCampos.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            _tabelaCampos.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            _tabelaCampos.Height = 0;
            CriarCampos();
            rolagem.Controls.Add(_tabelaCampos);

            if (PossuiImagem) rolagem.Controls.Add(CriarAreaImagem());

            // rodapé: ações
            var rodape = new TableLayoutPanel
            {
                Dock = DockStyle.Bottom, Height = 54, ColumnCount = 4, RowCount = 1,
                BackColor = Tema.Superficie, Padding = new Padding(0, 12, 0, 0)
            };
            NeonButton[] acoes = { _btnSalvar, _btnCancelar, _btnEditar, _btnExcluir };
            for (int i = 0; i < acoes.Length; i++)
            {
                rodape.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
                acoes[i].Dock = DockStyle.Fill;
                acoes[i].Margin = new Padding(i == 0 ? 0 : 4, 0, i == acoes.Length - 1 ? 0 : 4, 0);
                rodape.Controls.Add(acoes[i], i, 0);
            }
            _btnSalvar.Click += (s, e) => Salvar();
            _btnCancelar.Click += (s, e) => Cancelar();
            _btnCancelar.Som = SomInterface.Cancelar;
            _btnEditar.Click += (s, e) => Editar();
            _btnExcluir.Click += (s, e) => Excluir();
            _dicas.SetToolTip(_btnSalvar, "Salvar alterações (Ctrl+S)");
            _dicas.SetToolTip(_btnCancelar, "Descartar alterações (Esc)");
            _dicas.SetToolTip(_btnEditar, "Editar o registro selecionado (Ctrl+E)");
            _dicas.SetToolTip(_btnExcluir, "Excluir o registro selecionado (Delete)");

            var separador = new Panel { Dock = DockStyle.Bottom, Height = 1, BackColor = Tema.Borda };

            card.Controls.Add(rolagem);
            card.Controls.Add(separador);
            card.Controls.Add(rodape);
            card.Controls.Add(topo);
        }

        private Control CriarAreaImagem()
        {
            var area = new Panel { Dock = DockStyle.Top, Height = 150, BackColor = Tema.Superficie };
            _preview = new ImagemPreview { Location = new Point(0, 4), Size = new Size(206, 136), TextoVazio = "Nenhuma imagem" };
            _btnImagem = new NeonButton("Selecionar imagem", VarianteBotao.Secundario, "image-plus") { Height = 36 };
            _btnImagem.AjustarLargura(170);
            _btnRemoverImagem = new NeonButton("Remover imagem", VarianteBotao.Fantasma, "image-remove") { Height = 36 };
            _btnRemoverImagem.AjustarLargura(170);
            var dica = new Label
            {
                Text = "PNG, JPG, BMP ou GIF\naté 10 MB", AutoSize = true, ForeColor = Tema.TextoTerciario, Font = Tema.Fonte(8.5f)
            };
            _btnImagem.Location = new Point(222, 14);
            _btnRemoverImagem.Location = new Point(222, 58);
            dica.Location = new Point(226, 102);
            _btnImagem.Click += (s, e) => SelecionarImagem();
            _btnRemoverImagem.Click += (s, e) => RemoverImagem();
            _preview.Cursor = Cursors.Hand;
            _preview.DoubleClick += (s, e) => { if (_modo == ModoEdicao.Novo || _modo == ModoEdicao.Editando) SelecionarImagem(); };
            area.Controls.AddRange(new Control[] { _preview, _btnImagem, _btnRemoverImagem, dica });
            return area;
        }

        // ============================================================ helpers p/ filtros
        protected ComboTema CriarFiltro<TEnum>(string textoTodos, int largura = 175) where TEnum : struct, Enum
        {
            var combo = new ComboTema { Width = largura, Margin = new Padding(0, 4, 10, 0) };
            combo.Items.Add(textoTodos);
            foreach (var op in EnumExtensions.ListarOpcoes<TEnum>()) combo.Items.Add(op);
            combo.SelectedIndex = 0;
            combo.SelectedIndexChanged += (s, e) => { if (!_suprimirFiltros) CarregarLista(_selecionado?.Id); };
            _barraFiltros.Controls.Add(combo);
            return combo;
        }

        protected ComboTema CriarFiltroTexto(string textoTodos, IEnumerable<string> valores, int largura = 175)
        {
            var combo = new ComboTema { Width = largura, Margin = new Padding(0, 4, 10, 0) };
            combo.Items.Add(textoTodos);
            foreach (string v in valores) combo.Items.Add(v);
            combo.SelectedIndex = 0;
            combo.SelectedIndexChanged += (s, e) => { if (!_suprimirFiltros) CarregarLista(_selecionado?.Id); };
            _barraFiltros.Controls.Add(combo);
            return combo;
        }

        /// <summary>Recarrega as opções de um filtro de texto mantendo a seleção atual.</summary>
        protected void AtualizarFiltroTexto(ComboTema combo, IEnumerable<string> valores)
        {
            string? atual = combo.SelectedIndex > 0 ? combo.SelectedItem as string : null;
            object primeiro = combo.Items[0];
            _suprimirFiltros = true;
            combo.Items.Clear();
            combo.Items.Add(primeiro);
            foreach (string v in valores) combo.Items.Add(v);
            int indice = atual == null ? 0 : combo.Items.IndexOf(atual);
            combo.SelectedIndex = indice < 0 ? 0 : indice;
            _suprimirFiltros = false;
        }

        protected static TEnum? ValorFiltro<TEnum>(ComboTema combo) where TEnum : struct, Enum
            => combo.SelectedItem is OpcaoEnum<TEnum> op ? op.Valor : (TEnum?)null;

        protected static string? TextoFiltro(ComboTema combo)
            => combo.SelectedIndex > 0 ? combo.SelectedItem as string : null;

        // ============================================================= helpers p/ grade
        protected void AdicionarColuna(string nome, string cabecalho, float peso, int minimo = 60,
                                       DataGridViewContentAlignment alinhamento = DataGridViewContentAlignment.MiddleLeft)
        {
            var col = new DataGridViewTextBoxColumn
            {
                Name = nome, HeaderText = cabecalho.ToUpperInvariant(), FillWeight = peso, MinimumWidth = minimo,
                SortMode = DataGridViewColumnSortMode.Automatic
            };
            col.DefaultCellStyle.Alignment = alinhamento;
            Grade.Columns.Add(col);
        }

        private void PintarCelulaStatus(object? sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            if (Grade.Columns[e.ColumnIndex].Name != "Status") return;
            if (!(Grade.Rows[e.RowIndex].Tag is T entidade)) return;
            if (e.Graphics == null) return;

            bool selecionada = (e.State & DataGridViewElementStates.Selected) != 0;
            Color fundo = selecionada ? Grade.DefaultCellStyle.SelectionBackColor : (e.CellStyle?.BackColor ?? Tema.Superficie);
            using (var b = new SolidBrush(fundo)) e.Graphics.FillRectangle(b, e.CellBounds);
            using (var p = new Pen(Grade.GridColor)) e.Graphics.DrawLine(p, e.CellBounds.Left, e.CellBounds.Bottom - 1, e.CellBounds.Right, e.CellBounds.Bottom - 1);
            Ui.DesenharBadge(e.Graphics, e.CellBounds, entidade.StatusDescricao, Tema.CorDoNivel(entidade.NivelStatus), Tema.Fonte(8f, FontStyle.Bold));
            e.Handled = true;
        }

        // ============================================================ helpers p/ campos
        private void AdicionarCelula(string rotulo, bool obrigatorio, Control controle, bool larguraTotal, int alturaControle)
        {
            if (larguraTotal && _colunaCampo == 1) { _colunaCampo = 0; _linhaCampo++; }
            if (_colunaCampo == 0)
            {
                _tabelaCampos.RowCount = _linhaCampo + 1;
                int altura = alturaControle + 34;
                _tabelaCampos.RowStyles.Add(new RowStyle(SizeType.Absolute, altura));
                _tabelaCampos.Height += altura;
            }

            var celula = new Panel
            {
                Dock = DockStyle.Fill, BackColor = Tema.Superficie,
                Margin = new Padding(0, 0, larguraTotal || _colunaCampo == 1 ? 0 : 12, 0)
            };
            var lbl = new Label
            {
                Text = rotulo + (obrigatorio ? " *" : ""), Dock = DockStyle.Top, Height = 22, ForeColor = Tema.TextoSecundario,
                Font = Tema.Fonte(8.75f, FontStyle.Bold), TextAlign = ContentAlignment.BottomLeft
            };
            controle.Dock = DockStyle.Top;
            controle.Height = alturaControle;
            celula.Controls.Add(controle);
            celula.Controls.Add(lbl);
            controle.BringToFront(); // garante que o rótulo fique acima do campo

            _tabelaCampos.Controls.Add(celula, _colunaCampo, _linhaCampo);
            if (larguraTotal)
            {
                _tabelaCampos.SetColumnSpan(celula, 2);
                _linhaCampo++;
                _colunaCampo = 0;
            }
            else if (_colunaCampo == 0) _colunaCampo = 1;
            else { _colunaCampo = 0; _linhaCampo++; }
        }

        protected TextBox AdicionarTexto(string rotulo, bool obrigatorio, int maximo, bool larguraTotal = false,
                                         bool multilinha = false, bool numerico = false, bool permitirDecimal = false)
        {
            TextBox caixa = Ui.CaixaTexto(maximo, multilinha);
            if (numerico) Ui.SomenteNumeros(caixa, permitirDecimal);
            var container = new CampoContainer(caixa);
            _containers.Add(container);
            AdicionarCelula(rotulo, obrigatorio, container, larguraTotal, multilinha ? 86 : 36);
            return caixa;
        }

        protected MaskedTextBox AdicionarDataHora(string rotulo, bool obrigatorio)
        {
            var caixa = new MaskedTextBox
            {
                Mask = "00/00/0000 00:00", BorderStyle = BorderStyle.None, Font = Tema.Fonte(10f), PromptChar = '_',
                ValidatingType = typeof(DateTime), Culture = PtBr
            };
            var container = new CampoContainer(caixa, "calendar-month");
            _containers.Add(container);
            AdicionarCelula(rotulo, obrigatorio, container, false, 36);
            return caixa;
        }

        protected ComboTema AdicionarCombo<TEnum>(string rotulo, bool obrigatorio = true, bool larguraTotal = false) where TEnum : struct, Enum
        {
            var combo = new ComboTema();
            foreach (var op in EnumExtensions.ListarOpcoes<TEnum>()) combo.Items.Add(op);
            if (combo.Items.Count > 0) combo.SelectedIndex = 0;
            _controlesEditaveis.Add(combo);
            AdicionarCelula(rotulo, obrigatorio, combo, larguraTotal, 36);
            return combo;
        }

        protected ComboTema AdicionarComboItens(string rotulo, bool obrigatorio = false, bool larguraTotal = false)
        {
            var combo = new ComboTema();
            _controlesEditaveis.Add(combo);
            AdicionarCelula(rotulo, obrigatorio, combo, larguraTotal, 36);
            return combo;
        }

        /// <summary>Ocupa a célula vazia ao lado (para manter o alinhamento da grade de campos).</summary>
        protected void PularCelula()
        {
            if (_colunaCampo == 1) { _colunaCampo = 0; _linhaCampo++; }
        }

        protected static TEnum ValorCombo<TEnum>(ComboTema combo, TEnum padrao) where TEnum : struct, Enum
            => combo.SelectedItem is OpcaoEnum<TEnum> op ? op.Valor : padrao;

        protected static void SelecionarCombo<TEnum>(ComboTema combo, TEnum valor) where TEnum : struct, Enum
        {
            for (int i = 0; i < combo.Items.Count; i++)
                if (combo.Items[i] is OpcaoEnum<TEnum> op && op.Valor.Equals(valor)) { combo.SelectedIndex = i; return; }
        }

        protected static void SelecionarItem(ComboTema combo, int? id)
        {
            for (int i = 0; i < combo.Items.Count; i++)
                if (combo.Items[i] is ItemCombo item && item.Id == id) { combo.SelectedIndex = i; return; }
            if (combo.Items.Count > 0) combo.SelectedIndex = 0;
        }

        // ======================================================= helpers de leitura
        protected static int? LerInteiro(TextBox caixa, string campo, List<string> erros)
        {
            string texto = caixa.Text.Trim();
            if (texto.Length == 0) { erros.Add($"O campo \"{campo}\" é obrigatório."); return null; }
            if (!int.TryParse(texto, NumberStyles.Integer, PtBr, out int valor))
            {
                erros.Add($"O campo \"{campo}\" deve conter um número inteiro válido.");
                return null;
            }
            return valor;
        }

        protected static decimal? LerDecimal(TextBox caixa, string campo, List<string> erros)
        {
            string texto = caixa.Text.Trim().Replace("R$", "").Replace("$", "").Trim();
            if (texto.Length == 0) { erros.Add($"O campo \"{campo}\" é obrigatório."); return null; }
            bool ok = texto.Contains(",")
                ? decimal.TryParse(texto, NumberStyles.Number, PtBr, out decimal valor)
                : decimal.TryParse(texto, NumberStyles.Number, CultureInfo.InvariantCulture, out valor);
            if (!ok)
            {
                erros.Add($"O campo \"{campo}\" deve conter um valor numérico válido (ex.: 1500,00).");
                return null;
            }
            return valor;
        }

        protected static DateTime? LerDataHora(MaskedTextBox caixa, string campo, List<string> erros)
        {
            if (!caixa.MaskCompleted) { erros.Add($"Preencha o campo \"{campo}\" no formato dd/mm/aaaa hh:mm."); return null; }
            if (DateTime.TryParseExact(caixa.Text, "dd/MM/yyyy HH:mm", PtBr, DateTimeStyles.None, out DateTime data)) return data;
            erros.Add($"O campo \"{campo}\" contém uma data ou hora inválida.");
            return null;
        }

        /// <summary>Executa uma atribuição protegida pelo encapsulamento e coleta a mensagem de erro.</summary>
        protected static void Atribuir(List<string> erros, Action atribuicao)
        {
            try { atribuicao(); }
            catch (ArgumentException ex) { erros.Add(MensagemLimpa(ex)); }
        }

        private static string MensagemLimpa(Exception ex)
        {
            string msg = ex.Message.Split('\n')[0];
            int i = msg.IndexOf(" (Parameter", StringComparison.Ordinal);
            return i > 0 ? msg.Substring(0, i) : msg;
        }

        // ================================================================ listagem
        protected void CarregarLista(int? selecionarId)
        {
            List<T> dados;
            try
            {
                dados = Pesquisar(_txtBusca.Text);
            }
            catch (Exception ex)
            {
                TratarErro(ex, "carregar a lista");
                return;
            }

            _carregando = true;
            Grade.SuspendLayout();
            Grade.Rows.Clear();
            foreach (T item in dados)
            {
                var valores = new List<object?>();
                if (PossuiImagem)
                    valores.Add(item is IPossuiImagem pi ? Recursos.Miniatura(pi.ImagemPath, 58, 38) : null);
                valores.AddRange(ValoresLinha(item));
                int indice = Grade.Rows.Add(valores.ToArray());
                Grade.Rows[indice].Tag = item;
            }
            Grade.ResumeLayout();
            Grade.ClearSelection();

            DataGridViewRow? alvo = null;
            if (selecionarId.HasValue)
                alvo = Grade.Rows.Cast<DataGridViewRow>().FirstOrDefault(r => r.Tag is T e && e.Id == selecionarId.Value);
            if (alvo == null && Grade.Rows.Count > 0) alvo = Grade.Rows[0];
            if (alvo != null)
            {
                DataGridViewColumn? primeiraVisivel = Grade.Columns.Cast<DataGridViewColumn>().FirstOrDefault(c => c.Visible);
                if (primeiraVisivel != null) Grade.CurrentCell = alvo.Cells[primeiraVisivel.Index];
                alvo.Selected = true;
            }
            _carregando = false;

            int total = dados.Count;
            _lblContagem.Text = total == 1 ? "1 registro encontrado" : $"{total} registros encontrados";

            if (_modo != ModoEdicao.Novo && _modo != ModoEdicao.Editando) MostrarSelecionado();
        }

        private T? EntidadeDaLinhaAtual()
            => Grade.SelectedRows.Count > 0 ? Grade.SelectedRows[0].Tag as T : (Grade.CurrentRow?.Tag as T);

        private void MostrarSelecionado()
        {
            T? entidade = EntidadeDaLinhaAtual();
            _selecionado = entidade;
            if (entidade == null)
            {
                LimparEditor();
                DefinirModo(ModoEdicao.Vazio);
                return;
            }
            PreencherEditor(entidade);
            DefinirModo(ModoEdicao.Visualizando);
        }

        private void PreencherEditor(T entidade)
        {
            PreencherCampos(entidade);
            if (PossuiImagem && entidade is IPossuiImagem pi)
            {
                _imagemAtual = pi.ImagemPath;
                _imagemPendente = null;
                _imagemRemovida = false;
                if (_preview != null) _preview.Imagem = Recursos.ImagemEntidade(pi.ImagemPath);
            }
        }

        private void LimparEditor()
        {
            LimparCampos();
            _imagemAtual = null;
            _imagemPendente = null;
            _imagemRemovida = false;
            if (_preview != null) _preview.Imagem = null;
        }

        // ================================================================= estados
        protected ModoEdicao Modo => _modo;

        private void DefinirModo(ModoEdicao modo)
        {
            _modo = modo;
            bool editando = modo == ModoEdicao.Novo || modo == ModoEdicao.Editando;
            bool temSelecao = modo == ModoEdicao.Visualizando && _selecionado != null;

            foreach (CampoContainer c in _containers) c.Bloqueado = !editando;
            foreach (Control c in _controlesEditaveis) c.Enabled = editando;
            if (_btnImagem != null) _btnImagem.Enabled = editando;
            if (_btnRemoverImagem != null) _btnRemoverImagem.Enabled = editando;

            _btnNovo.Enabled = !editando;
            _btnSalvar.Enabled = editando;
            _btnCancelar.Enabled = editando;
            _btnEditar.Enabled = temSelecao;
            _btnExcluir.Enabled = temSelecao;
            _btnDetalhes.Enabled = temSelecao;

            Grade.Enabled = !editando;
            _barraFiltros.Enabled = !editando;

            switch (modo)
            {
                case ModoEdicao.Novo:
                    _lblModo.Text = "● NOVO REGISTRO";
                    _lblModo.ForeColor = Tema.Rosa;
                    _lblTituloEditor.Text = TextoNovo;
                    break;
                case ModoEdicao.Editando:
                    _lblModo.Text = $"● EDITANDO  #{_selecionado?.Id:000}";
                    _lblModo.ForeColor = Tema.Laranja;
                    _lblTituloEditor.Text = _selecionado?.Titulo ?? "";
                    break;
                case ModoEdicao.Visualizando:
                    _lblModo.Text = $"VISUALIZANDO  #{_selecionado?.Id:000}";
                    _lblModo.ForeColor = Tema.Turquesa;
                    _lblTituloEditor.Text = _selecionado?.Titulo ?? "";
                    break;
                default:
                    _lblModo.Text = "NENHUM REGISTRO SELECIONADO";
                    _lblModo.ForeColor = Tema.TextoTerciario;
                    _lblTituloEditor.Text = $"Selecione ou cadastre um {NomeSingular}";
                    break;
            }
        }

        // ================================================================== ações
        private void Novo()
        {
            if (_modo == ModoEdicao.Novo || _modo == ModoEdicao.Editando) return;
            try
            {
                AtualizarListasAuxiliares();
            }
            catch (Exception ex)
            {
                TratarErro(ex, "preparar o cadastro");
                return;
            }
            LimparEditor();
            DefinirModo(ModoEdicao.Novo);
            FocarPrimeiroCampo();
        }

        private void Editar()
        {
            if (_modo != ModoEdicao.Visualizando || _selecionado == null) return;
            try
            {
                AtualizarListasAuxiliares();
                // relê do banco para editar a versão mais recente
                T? atual = Servico.ObterPorId(_selecionado.Id);
                if (atual == null)
                {
                    Mensagem.Aviso(this, $"Este {NomeSingular} não existe mais no banco de dados.");
                    CarregarLista(null);
                    return;
                }
                _selecionado = atual;
                PreencherEditor(atual);
            }
            catch (Exception ex)
            {
                TratarErro(ex, "abrir o registro para edição");
                return;
            }
            DefinirModo(ModoEdicao.Editando);
            FocarPrimeiroCampo();
        }

        private void Salvar()
        {
            if (_modo != ModoEdicao.Novo && _modo != ModoEdicao.Editando) return;
            try
            {
                var erros = new List<string>();
                T entidade = LerCampos(erros);
                if (erros.Count > 0)
                {
                    // mostra de uma vez os erros de conversão e as demais regras da entidade
                    foreach (string e in entidade.Validar())
                        if (!erros.Contains(e)) erros.Add(e);
                    throw new ValidacaoException(erros);
                }

                if (_modo == ModoEdicao.Editando && _selecionado != null)
                {
                    entidade.Id = _selecionado.Id;
                    if (!CamposDefinemDataCadastro) entidade.DataCadastro = _selecionado.DataCadastro;
                }
                else if (!CamposDefinemDataCadastro)
                {
                    entidade.DataCadastro = DateTime.Now;
                }

                // valida antes de copiar a imagem, evitando arquivos órfãos
                var errosEntidade = entidade.Validar();
                if (errosEntidade.Count > 0) throw new ValidacaoException(errosEntidade);

                if (entidade is IPossuiImagem comImagem)
                {
                    if (_imagemPendente != null) comImagem.ImagemPath = ImagemService.Importar(_imagemPendente, PastaUploads);
                    else comImagem.ImagemPath = _imagemRemovida ? null : _imagemAtual;
                }

                bool criado = Servico.Salvar(entidade);
                _modo = ModoEdicao.Visualizando;
                CarregarLista(entidade.Id);
                Mensagem.Notificar(this, criado
                    ? $"{Capitalizar(NomeSingular)} \"{entidade.Titulo}\" cadastrado(a) com sucesso!"
                    : $"{Capitalizar(NomeSingular)} \"{entidade.Titulo}\" atualizado(a) com sucesso!");
                AoSalvar();
            }
            catch (Exception ex)
            {
                TratarErro(ex, "salvar o registro");
            }
        }

        /// <summary>Gancho para as telas reagirem após uma gravação bem-sucedida.</summary>
        protected virtual void AoSalvar() { }

        private void Excluir()
        {
            if (_modo != ModoEdicao.Visualizando || _selecionado == null) return;
            T alvo = _selecionado;
            bool confirmado = Mensagem.Confirmar(this, $"Excluir {NomeSingular}",
                $"Deseja realmente excluir \"{alvo.Titulo}\"?\n\nEsta ação não poderá ser desfeita.",
                "Excluir", "Cancelar", perigoso: true);
            if (!confirmado) return;

            // próximo registro a ser selecionado após a exclusão (vizinho na lista)
            int? proximoId = null;
            if (Grade.SelectedRows.Count > 0)
            {
                int indice = Grade.SelectedRows[0].Index;
                DataGridViewRow? vizinho = indice + 1 < Grade.Rows.Count ? Grade.Rows[indice + 1] : (indice > 0 ? Grade.Rows[indice - 1] : null);
                proximoId = (vizinho?.Tag as T)?.Id;
            }

            try
            {
                Servico.Excluir(alvo);
                _selecionado = null;
                CarregarLista(proximoId);
                Mensagem.Notificar(this, $"{Capitalizar(NomeSingular)} \"{alvo.Titulo}\" excluído(a) com sucesso.", SomInterface.Notificacao);
                AoSalvar();
            }
            catch (Exception ex)
            {
                TratarErro(ex, "excluir o registro");
            }
        }

        private void Cancelar()
        {
            if (_modo != ModoEdicao.Novo && _modo != ModoEdicao.Editando) return;
            _modo = ModoEdicao.Visualizando;
            CarregarLista(_selecionado?.Id);
        }

        private void AbrirDetalhes()
        {
            if (_modo != ModoEdicao.Visualizando) return;
            T? entidade = _selecionado ?? EntidadeDaLinhaAtual();
            if (entidade == null) return;
            using (var detalhes = new DetalhesForm(entidade))
                detalhes.ShowDialog(TopLevelControl as Form);
        }

        private void SelecionarImagem()
        {
            using (var dialogo = new OpenFileDialog { Title = "Selecionar imagem", Filter = ImagemService.FiltroDialogo, Multiselect = false })
            {
                if (dialogo.ShowDialog(TopLevelControl as Form) != DialogResult.OK) return;
                try
                {
                    ImagemService.Validar(dialogo.FileName);
                    Image? imagem = Recursos.ImagemEntidade(dialogo.FileName);
                    if (imagem == null) throw new ValidacaoException("Não foi possível abrir a imagem. O arquivo pode estar corrompido.");
                    _imagemPendente = dialogo.FileName;
                    _imagemRemovida = false;
                    if (_preview != null) _preview.Imagem = imagem;
                }
                catch (Exception ex)
                {
                    TratarErro(ex, "carregar a imagem");
                }
            }
        }

        private void RemoverImagem()
        {
            _imagemPendente = null;
            _imagemRemovida = true;
            if (_preview != null) _preview.Imagem = null;
        }

        private void FocarPrimeiroCampo()
        {
            CampoContainer? primeiro = _containers.FirstOrDefault();
            primeiro?.Campo.Focus();
        }

        private static string Capitalizar(string texto)
            => string.IsNullOrEmpty(texto) ? texto : char.ToUpper(texto[0], PtBr) + texto.Substring(1);

        // ============================================================ IModuloView
        public override void AoAtivar()
        {
            Ui.AplicarLinhasAlternadas(Grade);
            if (_modo == ModoEdicao.Novo || _modo == ModoEdicao.Editando) return;
            try
            {
                AtualizarListasAuxiliares();
            }
            catch (Exception ex)
            {
                TratarErro(ex, "atualizar as listas");
            }
            CarregarLista(_selecionado?.Id);
        }

        public override bool PodeSair()
        {
            if (_modo != ModoEdicao.Novo && _modo != ModoEdicao.Editando) return true;
            bool descartar = Mensagem.Confirmar(this, "Alterações não salvas",
                "Existem alterações que ainda não foram salvas.\nDeseja descartá-las e sair desta tela?",
                "Descartar", "Continuar editando", perigoso: true);
            if (descartar) Cancelar();
            return descartar;
        }

        public override void LimparFiltros()
        {
            if (_modo == ModoEdicao.Novo || _modo == ModoEdicao.Editando) return;
            _suprimirFiltros = true;
            _timerBusca.Stop();
            _txtBusca.Text = string.Empty;
            LimparFiltrosEspecificos();
            _suprimirFiltros = false;
            CarregarLista(_selecionado?.Id);
        }

        public override void IniciarNovoRegistro()
        {
            if (!PodeSair()) return;
            Novo();
        }

        public override void SelecionarRegistro(int id)
        {
            if (!PodeSair()) return;
            _suprimirFiltros = true;
            _txtBusca.Text = string.Empty;
            LimparFiltrosEspecificos();
            _suprimirFiltros = false;
            CarregarLista(id);
            Grade.Focus();
        }

        // ================================================================= atalhos
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            bool editando = _modo == ModoEdicao.Novo || _modo == ModoEdicao.Editando;
            switch (keyData)
            {
                case Keys.Control | Keys.N: if (!editando) Novo(); return true;
                case Keys.Control | Keys.S: if (editando) Salvar(); return true;
                case Keys.Control | Keys.E: if (!editando) Editar(); return true;
                case Keys.Control | Keys.F: if (!editando) _txtBusca.Focus(); return true;
                case Keys.F5: if (!editando) { AudioManager.Instancia.Tocar(SomInterface.Carregando); AoAtivar(); } return true;
                case Keys.Escape: if (editando) { AudioManager.Instancia.Tocar(SomInterface.Cancelar); Cancelar(); return true; } break;
                case Keys.Delete: if (!editando && Grade.Focused) { Excluir(); return true; } break;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _timerBusca.Dispose();
                _dicas.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
