using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using ViceCityCentral.Audio;
using ViceCityCentral.Data;
using ViceCityCentral.Services;
using ViceCityCentral.Views.Components;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views
{
    /// <summary>
    /// Janela principal: menu lateral (sidebar) + área de conteúdo onde cada módulo é exibido.
    /// As telas são criadas sob demanda e reaproveitadas (mantêm filtros e seleção).
    /// </summary>
    public class MainForm : Form
    {
        private readonly Panel _sidebar = new Panel();
        private readonly Panel _conteudo = new Panel();
        private readonly Label _lblStatus = new Label();
        private readonly OperadorPanel _operador = new OperadorPanel();
        private readonly Dictionary<Modulo, SidebarButton> _botoes = new Dictionary<Modulo, SidebarButton>();
        private readonly Dictionary<Modulo, ModuloBaseForm> _telas = new Dictionary<Modulo, ModuloBaseForm>();
        private ModuloBaseForm? _telaAtual;

        // áudio e histórico de navegação ("voltar")
        private readonly AudioDock _audioDock = new AudioDock();
        private readonly Stack<Modulo> _historico = new Stack<Modulo>();
        private bool _navegandoVoltar;

        public MainForm()
        {
            Text = $"{AppInfo.Nome} — {AppInfo.Subtitulo}";
            BackColor = Tema.Fundo;
            ForeColor = Tema.Texto;
            Font = Tema.Fonte(9.75f);
            MinimumSize = new Size(1180, 720);
            StartPosition = FormStartPosition.CenterScreen;
            DoubleBuffered = true;
            KeyPreview = true;
            CarregarIcone();

            Rectangle area = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1440, 900);
            if (area.Width < 1460 || area.Height < 900) WindowState = FormWindowState.Maximized;
            else Size = new Size(1440, 900);

            MontarSidebar();

            _conteudo.Dock = DockStyle.Fill;
            _conteudo.BackColor = Tema.Fundo;

            var barraStatus = new Panel { Dock = DockStyle.Bottom, Height = 28, BackColor = Tema.Sidebar };
            _lblStatus.Dock = DockStyle.Fill;
            _lblStatus.TextAlign = ContentAlignment.MiddleLeft;
            _lblStatus.Padding = new Padding(16, 0, 0, 0);
            _lblStatus.Font = Tema.Fonte(8.25f);
            var lblVersao = new Label
            {
                Dock = DockStyle.Right, Width = 560, TextAlign = ContentAlignment.MiddleRight, Padding = new Padding(0, 0, 16, 0),
                Text = $"{AppInfo.Nome} v{AppInfo.Versao}  ·  Ctrl+1…6 módulos  ·  Alt+← voltar  ·  Ctrl+M som", ForeColor = Tema.TextoTerciario, Font = Tema.Fonte(8.25f)
            };
            barraStatus.Controls.Add(_lblStatus);
            barraStatus.Controls.Add(lblVersao);
            barraStatus.Paint += (s, e) => { using (var p = new Pen(Tema.Borda)) e.Graphics.DrawLine(p, 0, 0, barraStatus.Width, 0); };

            Controls.Add(_conteudo);
            Controls.Add(barraStatus);
            Controls.Add(_sidebar);

            ConfiguracaoService.Instancia.ConfiguracoesAlteradas += (s, e) => AtualizarOperador();
            AtualizarOperador();
            AtualizarStatusBanco();

            Shown += (s, e) => Navegar(Modulo.Dashboard);

            // ---------- áudio: efeitos em todos os controles (inclusive os criados depois)
            AudioHooks.Registrar(this);
            AudioHooks.VoltarSolicitado += (s, e) => Voltar();
            InstalarInicioAutomaticoDoAudio();
            FormClosed += (s, e) => AudioManager.Instancia.Dispose();
        }

        /// <summary>
        /// Quem já ativou a experiência sonora antes tem o áudio iniciado na primeira interação
        /// (clique ou tecla), como nas políticas de autoplay dos navegadores. Na primeira visita,
        /// o usuário decide pelo botão "Ativar experiência sonora".
        /// </summary>
        private void InstalarInicioAutomaticoDoAudio()
        {
            if (!AudioManager.Instancia.Preferencias.ExperienciaAtivada) return;
            Application.AddMessageFilter(new PrimeiraInteracao(this));
        }

        private sealed class PrimeiraInteracao : IMessageFilter
        {
            private const int WmKeyDown = 0x0100, WmLButtonDown = 0x0201, WmRButtonDown = 0x0204;
            private readonly Control _alvo;
            private bool _disparado;

            public PrimeiraInteracao(Control alvo) { _alvo = alvo; }

            public bool PreFilterMessage(ref Message m)
            {
                if (_disparado || (m.Msg != WmKeyDown && m.Msg != WmLButtonDown && m.Msg != WmRButtonDown)) return false;
                _disparado = true;
                Application.RemoveMessageFilter(this);
                if (_alvo.IsHandleCreated) _alvo.BeginInvoke(new Action(() => AudioManager.Instancia.IniciarExperiencia()));
                return false; // nunca bloqueia a mensagem original
            }
        }

        /// <summary>Volta para a tela anterior (Alt+← ou botão "voltar" do mouse).</summary>
        public void Voltar()
        {
            while (_historico.Count > 0)
            {
                Modulo anterior = _historico.Pop();
                if (_telaAtual != null && anterior == _telaAtual.Modulo) continue;
                _navegandoVoltar = true;
                try { Navegar(anterior); }
                finally { _navegandoVoltar = false; }
                return;
            }
        }

        // ------------------------------------------------------------- sidebar
        private void MontarSidebar()
        {
            _sidebar.Dock = DockStyle.Left;
            _sidebar.Width = 240;
            _sidebar.BackColor = Tema.Sidebar;
            _sidebar.BackgroundImage = Recursos.Asset("Backgrounds/sidebar_bg.png");
            _sidebar.BackgroundImageLayout = ImageLayout.Stretch;
            _sidebar.Paint += (s, e) => { using (var p = new Pen(Tema.Borda)) e.Graphics.DrawLine(p, _sidebar.Width - 1, 0, _sidebar.Width - 1, _sidebar.Height); };

            var logo = new PictureBox
            {
                Image = Recursos.Asset("Images/logo.png"), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent,
                Location = new Point(0, 18), Size = new Size(240, 96), Cursor = Cursors.Hand
            };
            logo.Click += (s, e) => Navegar(Modulo.Dashboard);
            _sidebar.Controls.Add(logo);

            var lblMenu = new Label
            {
                Text = "MENU PRINCIPAL", Font = Tema.Fonte(7.75f, FontStyle.Bold), ForeColor = Tema.TextoTerciario,
                BackColor = Color.Transparent, AutoSize = true, Location = new Point(28, 132)
            };
            _sidebar.Controls.Add(lblMenu);

            var itens = new (Modulo modulo, string texto, string icone)[]
            {
                (Modulo.Dashboard, "Dashboard", "view-dashboard"),
                (Modulo.Personagens, "Personagens", "account-group"),
                (Modulo.Veiculos, "Veículos", "car-sports"),
                (Modulo.Missoes, "Missões", "target"),
                (Modulo.Localidades, "Localidades", "map-marker-radius"),
                (Modulo.Configuracoes, "Configurações", "cog")
            };
            int y = 156;
            int n = 1;
            foreach (var item in itens)
            {
                var botao = new SidebarButton(item.texto, item.icone, "Ctrl+" + n++)
                {
                    Location = new Point(0, y), Width = 240
                };
                Modulo destino = item.modulo;
                botao.Click += (s, e) => Navegar(destino);
                _sidebar.Controls.Add(botao);
                _botoes[item.modulo] = botao;
                y += botao.Height + 4;
                if (item.modulo == Modulo.Localidades) y += 14; // separa Configurações
            }

            _audioDock.Dock = DockStyle.Bottom;
            _sidebar.Controls.Add(_audioDock); // adicionado antes do operador: fica logo acima dele

            _operador.Dock = DockStyle.Bottom;
            _operador.Height = 72;
            _sidebar.Controls.Add(_operador);
        }

        private void AtualizarOperador()
        {
            _operador.Nome = ConfiguracaoService.Instancia.Atual.NomeOperador;
        }

        private void AtualizarStatusBanco()
        {
            bool ok = DatabaseConnection.TestarConexao(out string info);
            _operador.Conectado = ok;
            _lblStatus.ForeColor = ok ? Tema.Verde : Tema.Vermelho;
            _lblStatus.Text = ok
                ? $"●  Conectado ao banco {Path.GetFileName(DatabaseConnection.CaminhoBanco)}  ·  {info}"
                : $"●  Sem conexão com o banco de dados: {info}";
        }

        // ------------------------------------------------------------ navegação
        public void Navegar(Modulo modulo, bool novoRegistro = false, int? registroId = null)
        {
            if (_telaAtual != null && _telaAtual.Modulo != modulo && !_telaAtual.PodeSair()) return;

            ModuloBaseForm tela;
            try
            {
                tela = ObterTela(modulo);
            }
            catch (Exception ex)
            {
                Mensagem.Erro(this, "Não foi possível abrir esta tela.\n\n" + ex.Message, ex);
                return;
            }

            if (!ReferenceEquals(tela, _telaAtual))
            {
                if (_telaAtual != null)
                {
                    if (!_navegandoVoltar) _historico.Push(_telaAtual.Modulo);
                    AudioManager.Instancia.Tocar(_navegandoVoltar ? SomInterface.Voltar : SomInterface.TransicaoPagina);
                }
                _conteudo.SuspendLayout();
                _telaAtual?.Hide();
                if (!_conteudo.Controls.Contains(tela)) _conteudo.Controls.Add(tela);
                tela.Show();
                tela.BringToFront();
                _conteudo.ResumeLayout();
                _telaAtual = tela;
            }

            foreach (var par in _botoes) par.Value.Ativo = par.Key == modulo;
            tela.AoAtivar();
            AtualizarStatusBanco();

            if (novoRegistro) tela.IniciarNovoRegistro();
            else if (registroId.HasValue) tela.SelecionarRegistro(registroId.Value);
        }

        /// <summary>Cria a tela na primeira vez (fábrica) e reaproveita nas próximas.</summary>
        private ModuloBaseForm ObterTela(Modulo modulo)
        {
            if (_telas.TryGetValue(modulo, out ModuloBaseForm? existente)) return existente;

            ModuloBaseForm tela = modulo switch
            {
                Modulo.Dashboard => new DashboardForm(),
                Modulo.Personagens => new PersonagensForm(),
                Modulo.Veiculos => new VeiculosForm(),
                Modulo.Missoes => new MissoesForm(),
                Modulo.Localidades => new LocalidadesForm(),
                _ => CriarConfiguracoes()
            };
            tela.NavegacaoSolicitada += (s, e) => Navegar(e.Destino, e.NovoRegistro, e.RegistroId);
            _telas[modulo] = tela;
            return tela;
        }

        private ModuloBaseForm CriarConfiguracoes()
        {
            var cfg = new ConfiguracoesForm();
            cfg.LimparFiltrosSolicitado += (s, e) =>
            {
                foreach (var tela in _telas.Values) tela.LimparFiltros();
            };
            cfg.BancoRestaurado += (s, e) =>
            {
                // as telas guardam dados em memória: descarta para recriar com o banco novo
                foreach (var par in new List<KeyValuePair<Modulo, ModuloBaseForm>>(_telas))
                {
                    if (par.Key == Modulo.Configuracoes) continue;
                    _conteudo.Controls.Remove(par.Value);
                    par.Value.Dispose();
                    _telas.Remove(par.Key);
                }
                AtualizarStatusBanco();
            };
            return cfg;
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            Modulo? destino = keyData switch
            {
                Keys.Control | Keys.D1 => Modulo.Dashboard,
                Keys.Control | Keys.D2 => Modulo.Personagens,
                Keys.Control | Keys.D3 => Modulo.Veiculos,
                Keys.Control | Keys.D4 => Modulo.Missoes,
                Keys.Control | Keys.D5 => Modulo.Localidades,
                Keys.Control | Keys.D6 => Modulo.Configuracoes,
                _ => (Modulo?)null
            };
            if (keyData == (Keys.Control | Keys.M)) { AudioManager.Instancia.AlternarMudo(); return true; }
            if (keyData == (Keys.Alt | Keys.Left)) { Voltar(); return true; }
            if (destino.HasValue)
            {
                Navegar(destino.Value);
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_telaAtual != null && !_telaAtual.PodeSair()) e.Cancel = true;
            base.OnFormClosing(e);
        }

        // ------------------------------------------------------- aparência
        private void CarregarIcone()
        {
            try
            {
                string caminho = Path.Combine(Recursos.PastaAssets, "Icons", "app.ico");
                if (File.Exists(caminho)) Icon = new Icon(caminho);
            }
            catch (Exception)
            {
                // ícone é opcional
            }
        }

#if !MONO
        [DllImport("dwmapi.dll")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

        /// <summary>Barra de título escura no Windows 10 (1809+) e 11.</summary>
        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try
            {
                int ativo = 1;
                if (DwmSetWindowAttribute(Handle, 20, ref ativo, sizeof(int)) != 0)
                    DwmSetWindowAttribute(Handle, 19, ref ativo, sizeof(int));
            }
            catch (Exception)
            {
                // versões antigas do Windows não suportam: mantém a barra padrão
            }
        }
#endif

        /// <summary>Cartão do operador no rodapé da sidebar.</summary>
        private class OperadorPanel : Control
        {
            private string _nome = "";
            private bool _conectado = true;

            public OperadorPanel()
            {
                SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                         ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
                BackColor = Color.Transparent;
            }

            public string Nome { get => _nome; set { _nome = value; Invalidate(); } }
            public bool Conectado { get => _conectado; set { _conectado = value; Invalidate(); } }

            protected override void OnPaint(PaintEventArgs e)
            {
                Graphics g = e.Graphics;
                Tema.PrepararQualidade(g);
                var card = new RectangleF(12, 6, Width - 24, Height - 16);
                using (GraphicsPath p = Tema.Arredondado(card, 10))
                {
                    using (var b = new SolidBrush(Tema.ComAlfa(Tema.Superficie, 230))) g.FillPath(b, p);
                    using (var pen = new Pen(Tema.Borda)) g.DrawPath(pen, p);
                }
                var avatar = new RectangleF(24, card.Y + (card.Height - 36) / 2, 36, 36);
                using (var b = new LinearGradientBrush(avatar, Tema.Rosa, Tema.Roxo, LinearGradientMode.ForwardDiagonal))
                    g.FillEllipse(b, avatar);
                string inicial = string.IsNullOrEmpty(Nome) ? "?" : Nome.Substring(0, 1).ToUpperInvariant();
                TextRenderer.DrawText(g, inicial, Tema.Fonte(12f, FontStyle.Bold), Rectangle.Round(avatar), Color.White,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

                TextRenderer.DrawText(g, Nome, Tema.Fonte(9.5f, FontStyle.Bold), new Rectangle(70, (int)card.Y + 10, Width - 90, 20),
                    Tema.Texto, TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
                Color cor = Conectado ? Tema.Verde : Tema.Vermelho;
                using (var b = new SolidBrush(cor)) g.FillEllipse(b, 71, card.Y + 35, 7, 7);
                TextRenderer.DrawText(g, Conectado ? "Online · SQLite" : "Banco indisponível", Tema.Fonte(8f),
                    new Rectangle(82, (int)card.Y + 29, Width - 100, 18), Tema.TextoSecundario, TextFormatFlags.Left);
            }
        }
    }
}
