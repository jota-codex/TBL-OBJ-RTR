using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using ViceCityCentral.Audio;
using ViceCityCentral.Models;
using ViceCityCentral.Services;
using ViceCityCentral.Views.Components;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views
{
    /// <summary>Painel principal com indicadores, gráficos e atalhos — todos lidos do banco.</summary>
    public class DashboardForm : ModuloBaseForm
    {
        private static readonly CultureInfo PtBr = new CultureInfo("pt-BR");

        private readonly DashboardService _servico = new DashboardService();
        private readonly Timer _relogio = new Timer { Interval = 1000 };
        private readonly Timer _atualizacao = new Timer();

        private readonly BannerPanel _banner = new BannerPanel();
        private readonly StatCard _cardPersonagens = new StatCard("Personagens", "account-group", Tema.Rosa);
        private readonly StatCard _cardVeiculos = new StatCard("Veículos", "car-sports", Tema.Turquesa);
        private readonly StatCard _cardMissoes = new StatCard("Missões", "target", Tema.Lilas);
        private readonly StatCard _cardLocalidades = new StatCard("Localidades", "map-marker-radius", Tema.Laranja);
        private readonly StatCard _cardConcluidas = new StatCard("Concluídas", "check-decagram", Tema.Verde);
        private readonly StatCard _cardPendentes = new StatCard("Pendentes", "timer-sand", Tema.Azul);
        private readonly GraficoBarras _graficoVeiculos = new GraficoBarras { Dock = DockStyle.Fill };
        private readonly GraficoRosca _graficoMissoes = new GraficoRosca { Dock = DockStyle.Fill, RotuloCentral = "missões" };
        private readonly ListaRegistros _ultimos = new ListaRegistros { Dock = DockStyle.Fill };
        private readonly Label _lblAtualizado = new Label();

        public DashboardForm()
        {
            AutoScroll = true;
            AutoScrollMinSize = new Size(980, 820);

            var raiz = new TableLayoutPanel
            {
                Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, BackColor = Tema.Fundo, Margin = new Padding(0), Padding = new Padding(0)
            };
            raiz.RowStyles.Add(new RowStyle(SizeType.Absolute, 150));
            raiz.RowStyles.Add(new RowStyle(SizeType.Absolute, 124));
            raiz.RowStyles.Add(new RowStyle(SizeType.Percent, 48));
            raiz.RowStyles.Add(new RowStyle(SizeType.Percent, 52));

            // ------------------------------------------------ banner com relógio
            _banner.Dock = DockStyle.Fill;
            _banner.Margin = new Padding(6, 0, 6, 8);
            raiz.Controls.Add(_banner, 0, 0);

            // ------------------------------------------------ indicadores
            var linhaCards = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 6, RowCount = 1, BackColor = Tema.Fundo, Margin = new Padding(0) };
            StatCard[] cards = { _cardPersonagens, _cardVeiculos, _cardMissoes, _cardLocalidades, _cardConcluidas, _cardPendentes };
            Modulo[] destinos = { Modulo.Personagens, Modulo.Veiculos, Modulo.Missoes, Modulo.Localidades, Modulo.Missoes, Modulo.Missoes };
            for (int i = 0; i < cards.Length; i++)
            {
                linhaCards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / cards.Length));
                cards[i].Dock = DockStyle.Fill;
                cards[i].Cursor = Cursors.Hand;
                Modulo destino = destinos[i];
                cards[i].Click += (s, e) => SolicitarNavegacao(destino);
                linhaCards.Controls.Add(cards[i], i, 0);
            }
            raiz.Controls.Add(linhaCards, 0, 1);

            // ------------------------------------------------ gráficos
            var linhaGraficos = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Tema.Fundo, Margin = new Padding(0) };
            linhaGraficos.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 52));
            linhaGraficos.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48));
            var cardVeiculos = new CardPanel { Dock = DockStyle.Fill, Titulo = "Veículos por categoria", IconeTitulo = "car-sports", CorDestaque = Tema.Turquesa, Margin = new Padding(6) };
            cardVeiculos.Controls.Add(_graficoVeiculos);
            var cardMissoes = new CardPanel { Dock = DockStyle.Fill, Titulo = "Missões por status", IconeTitulo = "target", CorDestaque = Tema.Lilas, Margin = new Padding(6) };
            cardMissoes.Controls.Add(_graficoMissoes);
            linhaGraficos.Controls.Add(cardVeiculos, 0, 0);
            linhaGraficos.Controls.Add(cardMissoes, 1, 0);
            raiz.Controls.Add(linhaGraficos, 0, 2);

            // ------------------------------------------------ últimos registros + atalhos
            var linhaInferior = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Tema.Fundo, Margin = new Padding(0) };
            linhaInferior.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 66));
            linhaInferior.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34));

            var cardUltimos = new CardPanel { Dock = DockStyle.Fill, Titulo = "Últimos registros adicionados", IconeTitulo = "clock-outline", CorDestaque = Tema.Rosa, Margin = new Padding(6) };
            _ultimos.RegistroSelecionado += (s, entidade) => SolicitarNavegacao(ModuloDe(entidade), false, entidade.Id);
            cardUltimos.Controls.Add(_ultimos);

            var cardAtalhos = new CardPanel { Dock = DockStyle.Fill, Titulo = "Atalhos rápidos", IconeTitulo = "plus", CorDestaque = Tema.Turquesa, Margin = new Padding(6) };
            var grade = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 4, BackColor = Tema.Superficie };
            grade.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            grade.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            grade.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            grade.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            grade.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            grade.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            grade.Controls.Add(CriarAtalho("Novo personagem", "account-group", VarianteBotao.Primario, Modulo.Personagens), 0, 0);
            grade.Controls.Add(CriarAtalho("Novo veículo", "car-sports", VarianteBotao.Secundario, Modulo.Veiculos), 1, 0);
            grade.Controls.Add(CriarAtalho("Nova missão", "target", VarianteBotao.Secundario, Modulo.Missoes), 0, 1);
            grade.Controls.Add(CriarAtalho("Nova localidade", "map-marker-radius", VarianteBotao.Secundario, Modulo.Localidades), 1, 1);
            var btnAtualizar = new NeonButton("Atualizar indicadores", VarianteBotao.Fantasma, "refresh") { Dock = DockStyle.Fill, Margin = new Padding(0, 4, 0, 4) };
            btnAtualizar.Click += (s, e) => Atualizar();
            btnAtualizar.Som = SomInterface.Carregando;
            grade.Controls.Add(btnAtualizar, 0, 2);
            grade.SetColumnSpan(btnAtualizar, 2);
            _lblAtualizado.AutoSize = true;
            _lblAtualizado.ForeColor = Tema.TextoTerciario;
            _lblAtualizado.Font = Tema.Fonte(8.25f);
            _lblAtualizado.Margin = new Padding(4, 6, 0, 0);
            grade.Controls.Add(_lblAtualizado, 0, 3);
            grade.SetColumnSpan(_lblAtualizado, 2);
            cardAtalhos.Controls.Add(grade);

            linhaInferior.Controls.Add(cardUltimos, 0, 0);
            linhaInferior.Controls.Add(cardAtalhos, 1, 0);
            raiz.Controls.Add(linhaInferior, 0, 3);

            Controls.Add(raiz);

            _relogio.Tick += (s, e) => AtualizarRelogio();
            _atualizacao.Tick += (s, e) => Atualizar();
            ConfiguracaoService.Instancia.ConfiguracoesAlteradas += AoAlterarConfiguracoes;
            AtualizarRelogio();
            _relogio.Start();
        }

        public override Modulo Modulo => Modulo.Dashboard;

        public override void AoAtivar()
        {
            AplicarConfiguracoes();
            Atualizar();
        }

        private NeonButton CriarAtalho(string texto, string icone, VarianteBotao variante, Modulo destino)
        {
            var botao = new NeonButton(texto, variante, icone) { Dock = DockStyle.Fill, Margin = new Padding(0, 4, 6, 4) };
            botao.Click += (s, e) => SolicitarNavegacao(destino, novoRegistro: true);
            return botao;
        }

        private static Modulo ModuloDe(EntidadeBase entidade) => entidade switch
        {
            Personagem _ => Modulo.Personagens,
            Veiculo _ => Modulo.Veiculos,
            Missao _ => Modulo.Missoes,
            _ => Modulo.Localidades
        };

        /// <summary>Busca todos os indicadores no banco e atualiza a tela.</summary>
        public void Atualizar()
        {
            try
            {
                ResumoDashboard r = _servico.ObterResumo(8);

                _cardPersonagens.Valor = r.TotalPersonagens.ToString();
                _cardPersonagens.Descricao = $"{r.PersonagensProcurados} procurado(s) pela polícia";
                _cardVeiculos.Valor = r.TotalVeiculos.ToString();
                _cardVeiculos.Descricao = $"{r.VeiculosPorCategoria.Count(c => c.Value > 0)} categorias em uso";
                _cardMissoes.Valor = r.TotalMissoes.ToString();
                _cardMissoes.Descricao = "cadastradas no sistema";
                _cardLocalidades.Valor = r.TotalLocalidades.ToString();
                _cardLocalidades.Descricao = "em Vice City e Leonida";
                _cardConcluidas.Valor = r.MissoesConcluidas.ToString();
                _cardConcluidas.Descricao = r.TotalMissoes == 0 ? "nenhuma missão" : $"{Math.Round(100.0 * r.MissoesConcluidas / r.TotalMissoes)}% do total";
                _cardPendentes.Valor = r.MissoesPendentes.ToString();
                _cardPendentes.Descricao = "disponíveis + em andamento";

                _graficoVeiculos.DefinirDados(r.VeiculosPorCategoria.Select((kv, i) =>
                    new ItemGrafico(kv.Key.ToDescricao(), kv.Value, Tema.PaletaGraficos[i % Tema.PaletaGraficos.Length])));

                _graficoMissoes.DefinirDados(r.MissoesPorStatus.Select(kv =>
                    new ItemGrafico(kv.Key.ToDescricao(), kv.Value, CorStatus(kv.Key))));

                _ultimos.DefinirItens(r.UltimosRegistros);
                _lblAtualizado.Text = $"Atualizado às {DateTime.Now:HH:mm:ss}";
            }
            catch (Exception ex)
            {
                _relogio.Stop();
                _atualizacao.Stop();
                TratarErro(ex, "carregar os indicadores");
                _relogio.Start();
            }
        }

        private static Color CorStatus(StatusMissao status) => status switch
        {
            StatusMissao.Disponivel => Tema.Azul,
            StatusMissao.EmAndamento => Tema.Laranja,
            StatusMissao.Concluida => Tema.Verde,
            _ => Tema.Vermelho
        };

        private void AtualizarRelogio()
        {
            Configuracoes cfg = ConfiguracaoService.Instancia.Atual;
            DateTime agora = DateTime.Now;
            _banner.Hora = agora.ToString(cfg.ExibirSegundosRelogio ? "HH:mm:ss" : "HH:mm", PtBr);
            string data = agora.ToString("dddd, dd 'de' MMMM 'de' yyyy", PtBr);
            _banner.Data = char.ToUpper(data[0], PtBr) + data.Substring(1);
            _banner.Operador = cfg.NomeOperador;
        }

        private void AplicarConfiguracoes()
        {
            Configuracoes cfg = ConfiguracaoService.Instancia.Atual;
            _atualizacao.Stop();
            _atualizacao.Interval = cfg.IntervaloAtualizacaoSegundos * 1000;
            if (cfg.AtualizarDashboardAutomaticamente) _atualizacao.Start();
            AtualizarRelogio();
        }

        private void AoAlterarConfiguracoes(object? sender, EventArgs e)
        {
            if (IsDisposed) return;
            AplicarConfiguracoes();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                ConfiguracaoService.Instancia.ConfiguracoesAlteradas -= AoAlterarConfiguracoes;
                _relogio.Dispose();
                _atualizacao.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>Banner superior com arte de Vice City, saudação e relógio.</summary>
        private class BannerPanel : Control
        {
            private string _hora = "";
            private string _data = "";
            private string _operador = "";

            public BannerPanel()
            {
                SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                         ControlStyles.ResizeRedraw, true);
            }

            public string Hora { get => _hora; set { if (_hora != value) { _hora = value; Invalidate(); } } }
            public string Data { get => _data; set { if (_data != value) { _data = value; Invalidate(); } } }
            public string Operador { get => _operador; set { if (_operador != value) { _operador = value; Invalidate(); } } }

            protected override void OnPaint(PaintEventArgs e)
            {
                Graphics g = e.Graphics;
                g.Clear(Tema.Fundo);
                Tema.PrepararQualidade(g);
                var r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f);
                using (GraphicsPath path = Tema.Arredondado(r, 14))
                {
                    Image? fundo = Recursos.Asset("Backgrounds/dashboard_banner.png");
                    g.SetClip(path);
                    if (fundo != null) Recursos.DesenharCobrindo(g, fundo, ClientRectangle);
                    else using (var b = new LinearGradientBrush(r, Tema.Superficie, Tema.Roxo, LinearGradientMode.Horizontal)) g.FillPath(b, path);
                    // escurece a área do texto para manter a legibilidade
                    using (var b = new LinearGradientBrush(r, Color.FromArgb(235, 13, 11, 20), Color.FromArgb(40, 13, 11, 20), LinearGradientMode.Horizontal))
                        g.FillPath(b, path);
                    g.ResetClip();
                    using (var p = new Pen(Tema.ComAlfa(Tema.Rosa, 120))) g.DrawPath(p, path);
                }

                TextRenderer.DrawText(g, $"BEM-VINDO(A), {Operador.ToUpperInvariant()}", Tema.Fonte(8.5f, FontStyle.Bold),
                    new Rectangle(28, 26, Width / 2, 20), Tema.Turquesa, TextFormatFlags.Left);
                TextRenderer.DrawText(g, "Central de Operações de Vice City", Tema.FonteTitulo(22f),
                    new Rectangle(26, 46, Width - 300, 44), Tema.Texto, TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
                TextRenderer.DrawText(g, "Resumo em tempo real de personagens, frota, missões e territórios.", Tema.Fonte(9.5f),
                    new Rectangle(28, 92, Width - 320, 20), Tema.TextoSecundario, TextFormatFlags.Left | TextFormatFlags.EndEllipsis);

                // relógio
                var areaHora = new Rectangle(Width - 300, 34, 272, 46);
                TextRenderer.DrawText(g, Hora, Tema.FonteTitulo(28f, FontStyle.Bold), areaHora, Color.White, TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
                TextRenderer.DrawText(g, Data, Tema.Fonte(9.5f), new Rectangle(Width - 400, 84, 372, 20), Tema.Texto, TextFormatFlags.Right);
            }
        }
    }
}
