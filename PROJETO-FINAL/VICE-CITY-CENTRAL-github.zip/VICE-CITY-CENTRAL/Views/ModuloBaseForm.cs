using System;
using System.Drawing;
using System.Windows.Forms;
using ViceCityCentral.Views.Components;
using ViceCityCentral.Views.Theme;

namespace ViceCityCentral.Views
{
    /// <summary>Módulos acessíveis pelo menu lateral.</summary>
    public enum Modulo
    {
        Dashboard,
        Personagens,
        Veiculos,
        Missoes,
        Localidades,
        Configuracoes
    }

    /// <summary>Pedido de navegação feito por uma tela (ex.: atalhos do Dashboard).</summary>
    public class NavegacaoEventArgs : EventArgs
    {
        public NavegacaoEventArgs(Modulo destino, bool novoRegistro = false, int? registroId = null)
        {
            Destino = destino;
            NovoRegistro = novoRegistro;
            RegistroId = registroId;
        }

        public Modulo Destino { get; }
        public bool NovoRegistro { get; }
        public int? RegistroId { get; }
    }

    /// <summary>Contrato que a janela principal usa para conversar com cada tela.</summary>
    public interface IModuloView
    {
        Modulo Modulo { get; }
        void AoAtivar();
        bool PodeSair();
        void LimparFiltros();
        void IniciarNovoRegistro();
        void SelecionarRegistro(int id);
        event EventHandler<NavegacaoEventArgs>? NavegacaoSolicitada;
    }

    /// <summary>
    /// Base abstrata das telas exibidas dentro da janela principal (formulários "embutidos").
    /// Implementa o comportamento padrão de IModuloView; as telas sobrescrevem o necessário.
    /// </summary>
    public abstract class ModuloBaseForm : Form, IModuloView
    {
        protected ModuloBaseForm()
        {
            TopLevel = false;
            FormBorderStyle = FormBorderStyle.None;
            Dock = DockStyle.Fill;
            BackColor = Tema.Fundo;
            ForeColor = Tema.Texto;
            Font = Tema.Fonte(9.75f);
            DoubleBuffered = true;
            Padding = new Padding(28, 22, 28, 18);
        }

        public abstract Modulo Modulo { get; }

        public event EventHandler<NavegacaoEventArgs>? NavegacaoSolicitada;

        /// <summary>Chamado sempre que a tela é exibida (recarrega os dados).</summary>
        public virtual void AoAtivar() { }

        /// <summary>Permite impedir a troca de tela (ex.: edição não salva).</summary>
        public virtual bool PodeSair() => true;

        public virtual void LimparFiltros() { }
        public virtual void IniciarNovoRegistro() { }
        public virtual void SelecionarRegistro(int id) { }

        protected void SolicitarNavegacao(Modulo destino, bool novoRegistro = false, int? registroId = null)
            => NavegacaoSolicitada?.Invoke(this, new NavegacaoEventArgs(destino, novoRegistro, registroId));

        /// <summary>Cabeçalho padrão (ícone, título e subtítulo).</summary>
        protected Panel CriarCabecalho(string titulo, string subtitulo, string icone, Color cor)
        {
            var painel = new Panel { Dock = DockStyle.Top, Height = 66, BackColor = Tema.Fundo };
            var caixaIcone = new PictureBox
            {
                Size = new Size(46, 46), Location = new Point(0, 6), SizeMode = PictureBoxSizeMode.CenterImage,
                Image = Recursos.Icone(icone, cor, 26), BackColor = Tema.ComAlfa(cor, 30)
            };
            var lblTitulo = new Label
            {
                Text = titulo, Font = Tema.FonteTitulo(19f), ForeColor = Tema.Texto, AutoSize = true,
                Location = new Point(58, 2), BackColor = Color.Transparent
            };
            var lblSub = new Label
            {
                Text = subtitulo, Font = Tema.Fonte(9.5f), ForeColor = Tema.TextoSecundario, AutoSize = true,
                Location = new Point(60, 38), BackColor = Color.Transparent
            };
            painel.Controls.AddRange(new Control[] { caixaIcone, lblTitulo, lblSub });
            return painel;
        }

        /// <summary>Trata qualquer exceção exibindo a mensagem adequada ao usuário.</summary>
        protected void TratarErro(Exception ex, string contexto)
        {
            switch (ex)
            {
                case Exceptions.ValidacaoException v:
                    Mensagem.Aviso(this, "Revise os campos abaixo antes de continuar:", v.Erros, "Dados inválidos");
                    break;
                case Exceptions.RegraNegocioException r:
                    Mensagem.Aviso(this, r.Message, null, "Operação não permitida");
                    break;
                case Exceptions.DatabaseException d:
                    Mensagem.Erro(this, d.Message, d, "Falha no banco de dados");
                    break;
                default:
                    Mensagem.Erro(this, $"Ocorreu um erro inesperado ao {contexto}.\n\n{ex.Message}", ex);
                    break;
            }
        }
    }
}
