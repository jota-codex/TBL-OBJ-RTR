using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using ViceCityCentral.Data;
using ViceCityCentral.Services;

namespace ViceCityCentral.Audio
{
    /// <summary>
    /// Gerenciador central de áudio (único ponto que toca sons no sistema).
    ///
    /// Responsabilidades:
    ///  • experiência de entrada (efeito cinematográfico + trilha com fade-in gradual);
    ///  • trilha ambiente contínua com crossfade entre faixas (sem pausas perceptíveis);
    ///  • efeitos de interface com debounce, prioridades, limite de sons simultâneos e "ducking" da música;
    ///  • volumes independentes, modo silencioso e preferências persistidas;
    ///  • pré-carga apenas dos efeitos frequentes; o resto é carregado sob demanda;
    ///  • tratamento de erros: arquivo ausente/corrompido é ignorado e registrado em log;
    ///    se o dispositivo de som não existir, o sistema continua funcionando em silêncio.
    /// </summary>
    public sealed class AudioManager : IDisposable
    {
        public const int IntervaloTickMs = 40;
        public const int AtrasoMusicaMs = 1200;      // a música entra depois do efeito de entrada
        public const int FadeEntradaMs = 5000;       // início gradual da trilha
        public const int CrossfadeMs = 6000;         // transição entre faixas
        public const int FadeAlternarMs = 900;       // ligar/desligar música
        public const int FadeVozMs = 110;            // corte suave de efeitos interrompidos
        public const int MaxEfeitosSimultaneos = 3;

        private static AudioManager? _instancia;

        /// <summary>Instância única usada pelo aplicativo.</summary>
        public static AudioManager Instancia => _instancia ??= new AudioManager(CriarBackendPadrao(), null, usarTimer: true);

        /// <summary>Substitui a instância (usado pelos testes automatizados).</summary>
        public static void DefinirInstancia(AudioManager gerenciador)
        {
            _instancia?.Dispose();
            _instancia = gerenciador;
        }

        private static IAudioBackend CriarBackendPadrao()
            => Environment.OSVersion.Platform == PlatformID.Win32NT ? new MciAudioBackend() : (IAudioBackend)new SilentAudioBackend();

        // --------------------------------------------------------------- estado
        private IAudioBackend _backend;
        private readonly Func<double> _relogio;
        private readonly bool _usarTimer;
        private System.Windows.Forms.Timer? _timer;
        private readonly Stopwatch _cronometro = Stopwatch.StartNew();
        private readonly HashSet<string> _errosRegistrados = new HashSet<string>();

        private sealed class Voz
        {
            public Voz(string alias, SomInterface som) { Alias = alias; Som = som; }
            public string Alias { get; }
            public SomInterface Som { get; }
            public double Inicio = double.MinValue;
            public double Fim = double.MinValue;
            public double FadeInicio = -1;
            public int Volume;
        }

        private sealed class Deck
        {
            public Deck(string alias, int faixa) { Alias = alias; Faixa = faixa; }
            public string Alias { get; }
            public int Faixa { get; }
            public double Ganho;
            public double Alvo;
            public double Velocidade;  // ganho por ms
            public long Duracao;
            public bool Saindo;
            public bool Pausado;
            public int UltimoVolume = -1;
        }

        private readonly Dictionary<SomInterface, List<Voz>> _vozes = new Dictionary<SomInterface, List<Voz>>();
        private readonly HashSet<SomInterface> _indisponiveis = new HashSet<SomInterface>();
        private readonly Dictionary<SomInterface, double> _ultimaReproducao = new Dictionary<SomInterface, double>();
        private readonly Queue<SomInterface> _filaPrecarga = new Queue<SomInterface>();
        private readonly List<Deck> _decks = new List<Deck>();
        private readonly HashSet<int> _faixasComErro = new HashSet<int>();
        private int _proximaFaixa;
        private int _sequencia;
        private double _musicaAgendadaPara = -1;
        private double _abaixarMusicaAte;
        private double _fatorDucking = 1.0;
        private double _ultimoTick = -1;
        private double _ultimaChecagemPosicao;
        private bool _descartado;

        public AudioManager(IAudioBackend backend, Func<double>? relogio, bool usarTimer, PreferenciasAudio? preferencias = null, string? pastaAudio = null)
        {
            _backend = backend;
            _relogio = relogio ?? (() => _cronometro.Elapsed.TotalMilliseconds);
            _usarTimer = usarTimer;
            Preferencias = preferencias ?? PreferenciasAudio.Carregar();
            PastaAudio = pastaAudio ?? Path.Combine(DatabaseConnection.PastaAplicacao, "Assets", "Audio");
        }

        public PreferenciasAudio Preferencias { get; }
        public string PastaAudio { get; }

        /// <summary>A experiência sonora já foi iniciada nesta sessão.</summary>
        public bool ExperienciaIniciada { get; private set; }

        /// <summary>false quando o dispositivo de som não pôde ser usado.</summary>
        public bool Disponivel { get; private set; } = true;

        /// <summary>Título da faixa tocando (null se não houver música).</summary>
        public string? FaixaAtual
        {
            get
            {
                Deck? d = DeckPrincipal();
                return d == null ? null : CatalogoAudio.Faixas[d.Faixa].Titulo;
            }
        }

        /// <summary>Há música audível neste momento.</summary>
        public bool MusicaTocando => MusicaDeveTocar && _decks.Any(d => !d.Pausado && d.Ganho > 0.01);

        /// <summary>Disparado quando algo visível no painel muda (estado, faixa, preferências).</summary>
        public event EventHandler? EstadoAlterado;

        /// <summary>Disparado a cada efeito realmente reproduzido (diagnóstico e testes).</summary>
        public event EventHandler<SomInterface>? SomReproduzido;

        private bool MusicaDeveTocar => ExperienciaIniciada && Disponivel && Preferencias.MusicaAtiva && !Preferencias.Mudo;
        private bool EfeitosPodemTocar => ExperienciaIniciada && Disponivel && Preferencias.EfeitosAtivos && !Preferencias.Mudo && Preferencias.VolumeEfeitos > 0;

        // ================================================================ experiência
        /// <summary>
        /// Inicia a experiência sonora: efeito de entrada, trilha com fade-in e liberação dos efeitos.
        /// Chamado pelo botão "Ativar experiência sonora" ou na primeira interação (visitas seguintes).
        /// </summary>
        public void IniciarExperiencia()
        {
            if (ExperienciaIniciada || _descartado) return;
            ExperienciaIniciada = true;
            if (!Preferencias.ExperienciaAtivada)
            {
                Preferencias.ExperienciaAtivada = true;
                Preferencias.Salvar();
            }

            if (_usarTimer && _timer == null)
            {
                _timer = new System.Windows.Forms.Timer { Interval = IntervaloTickMs };
                _timer.Tick += (s, e) => Atualizar(_relogio());
                _timer.Start();
            }

            double agora = _relogio();
            Tocar(SomInterface.Entrada);
            _musicaAgendadaPara = agora + AtrasoMusicaMs;

            foreach (var par in CatalogoAudio.Efeitos)
                if (par.Value.Precarregar) _filaPrecarga.Enqueue(par.Key);

            NotificarEstado();
        }

        // ================================================================== efeitos
        /// <summary>Toca um efeito respeitando preferências, debounce, prioridades e limite de simultaneidade.</summary>
        public void Tocar(SomInterface som)
        {
            if (!EfeitosPodemTocar || _descartado) return;
            if (_indisponiveis.Contains(som)) return;
            DefinicaoSom def = CatalogoAudio.Efeitos[som];
            double agora = _relogio();

            // debounce por tipo de som
            if (_ultimaReproducao.TryGetValue(som, out double ultima) && agora - ultima < def.IntervaloMinimoMs) return;

            List<Voz> ativas = _vozes.Values.SelectMany(v => v).Where(v => agora < v.Fim && v.FadeInicio < 0).ToList();

            // um som menos importante logo após um mais importante é descartado (ex.: clique depois de "salvo")
            if (ativas.Any(v => agora - v.Inicio < 220 && Prioridade(v.Som) > def.Prioridade)) return;

            // sons menos importantes que acabaram de começar saem com fade (evita sobreposição confusa)
            foreach (Voz v in ativas.Where(v => Prioridade(v.Som) < def.Prioridade && agora - v.Inicio < 400))
                v.FadeInicio = agora;

            ativas = ativas.Where(v => v.FadeInicio < 0).ToList();
            if (ativas.Count >= MaxEfeitosSimultaneos)
            {
                Voz menor = ativas.OrderBy(v => Prioridade(v.Som)).ThenBy(v => v.Inicio).First();
                if (Prioridade(menor.Som) > def.Prioridade) return;
                PararVoz(menor, agora);
            }

            if (!CarregarVozes(som)) return;
            List<Voz> pool = _vozes[som];
            Voz voz = pool.FirstOrDefault(v => agora >= v.Fim) ?? pool.OrderBy(v => v.Inicio).First();

            int volume = (int)Math.Round(1000 * Preferencias.VolumeEfeitos / 100.0 * def.Ganho);
            bool ok = Executar(() =>
            {
                _backend.DefinirVolume(voz.Alias, volume);
                _backend.TocarDoInicio(voz.Alias);
            }, "tocar " + def.Arquivo);
            if (!ok) return;

            long duracao = Executar(() => _backend.DuracaoMs(voz.Alias), out long d, "duração") ? d : 0;
            voz.Inicio = agora;
            voz.Fim = agora + (duracao > 0 ? duracao : 1500);
            voz.FadeInicio = -1;
            voz.Volume = volume;
            _ultimaReproducao[som] = agora;
            if (def.AbaixaMusica) _abaixarMusicaAte = agora + 450;
            SomReproduzido?.Invoke(this, som);
        }

        private static int Prioridade(SomInterface som) => CatalogoAudio.Efeitos[som].Prioridade;

        private void PararVoz(Voz voz, double agora)
        {
            Executar(() => _backend.Parar(voz.Alias), "parar efeito");
            voz.Fim = agora;
            voz.FadeInicio = -1;
        }

        /// <summary>Abre (uma única vez) as vozes de um efeito. Retorna false se o arquivo não puder ser usado.</summary>
        private bool CarregarVozes(SomInterface som)
        {
            if (_vozes.ContainsKey(som)) return true;
            if (_indisponiveis.Contains(som)) return false;
            DefinicaoSom def = CatalogoAudio.Efeitos[som];
            string caminho = Path.Combine(PastaAudio, def.Arquivo.Replace('/', Path.DirectorySeparatorChar));
            if (!File.Exists(caminho))
            {
                RegistrarErroUnico("arquivo:" + def.Arquivo, new AudioException("Arquivo de áudio não encontrado: " + caminho));
                _indisponiveis.Add(som);
                return false;
            }
            var vozes = new List<Voz>();
            for (int i = 0; i < def.Vozes; i++)
            {
                var voz = new Voz($"vcc_{som.ToString().ToLowerInvariant()}_{i}", som);
                if (!Executar(() => _backend.Abrir(voz.Alias, caminho), "abrir " + def.Arquivo))
                {
                    foreach (Voz aberta in vozes) Executar(() => _backend.Fechar(aberta.Alias), "fechar");
                    _indisponiveis.Add(som);
                    return false;
                }
                vozes.Add(voz);
            }
            _vozes[som] = vozes;
            return true;
        }

        // =================================================================== música
        private Deck? DeckPrincipal() => _decks.LastOrDefault(d => !d.Saindo);

        private void IniciarDeck(int fadeMs)
        {
            int total = CatalogoAudio.Faixas.Count;
            for (int tentativa = 0; tentativa < total; tentativa++)
            {
                int faixa = _proximaFaixa;
                _proximaFaixa = (_proximaFaixa + 1) % total;
                if (_faixasComErro.Contains(faixa)) continue;

                string caminho = Path.Combine(PastaAudio, CatalogoAudio.Faixas[faixa].Arquivo.Replace('/', Path.DirectorySeparatorChar));
                var deck = new Deck($"vcc_musica_{++_sequencia}", faixa) { Ganho = 0, Alvo = 1, Velocidade = 1.0 / Math.Max(1, fadeMs) };
                bool ok = File.Exists(caminho) && Executar(() =>
                {
                    _backend.Abrir(deck.Alias, caminho);
                    _backend.DefinirVolume(deck.Alias, 0);
                    _backend.TocarDoInicio(deck.Alias);
                }, "abrir música " + CatalogoAudio.Faixas[faixa].Arquivo);

                if (!ok)
                {
                    if (!File.Exists(caminho))
                        RegistrarErroUnico("musica:" + faixa, new AudioException("Faixa não encontrada: " + caminho));
                    _faixasComErro.Add(faixa);
                    Executar(() => _backend.Fechar(deck.Alias), "fechar");
                    continue;
                }
                deck.Duracao = Executar(() => _backend.DuracaoMs(deck.Alias), out long d, "duração") ? d : 0;
                _decks.Add(deck);
                NotificarEstado();
                return;
            }
        }

        /// <summary>Faz a transição para a próxima faixa com crossfade.</summary>
        public void ProximaFaixa() => Crossfade(2500);

        private void Crossfade(int duracaoMs)
        {
            if (!MusicaDeveTocar) return;
            Deck? atual = DeckPrincipal();
            if (atual != null)
            {
                atual.Saindo = true;
                atual.Alvo = 0;
                atual.Velocidade = 1.0 / duracaoMs;
            }
            IniciarDeck(duracaoMs);
        }

        /// <summary>Liga/desliga a música conforme as preferências atuais (com fade).</summary>
        private void AplicarEstadoMusica()
        {
            if (!ExperienciaIniciada) return;
            if (MusicaDeveTocar)
            {
                Deck? principal = DeckPrincipal();
                if (principal == null)
                {
                    if (_musicaAgendadaPara < 0) IniciarDeck(1500);
                    return;
                }
                if (principal.Pausado)
                {
                    Executar(() => _backend.Retomar(principal.Alias), "retomar música");
                    principal.Pausado = false;
                }
                principal.Alvo = 1;
                principal.Velocidade = 1.0 / 1500;
            }
            else
            {
                foreach (Deck d in _decks)
                {
                    d.Alvo = 0;
                    d.Velocidade = 1.0 / FadeAlternarMs;
                }
            }
        }

        // ============================================================= ciclo (tick)
        /// <summary>Atualiza fades, crossfade, ducking e pré-carga. Chamado a cada 40 ms pelo timer.</summary>
        public void Atualizar(double agora)
        {
            if (_descartado) return;
            double dt = _ultimoTick < 0 ? IntervaloTickMs : Math.Max(0, agora - _ultimoTick);
            _ultimoTick = agora;

            // trilha agendada (entra depois do efeito de entrada)
            if (_musicaAgendadaPara >= 0 && agora >= _musicaAgendadaPara)
            {
                _musicaAgendadaPara = -1;
                if (MusicaDeveTocar && DeckPrincipal() == null) IniciarDeck(FadeEntradaMs);
            }

            // pré-carga gradual (um efeito por tick, sem travar a interface)
            if (_filaPrecarga.Count > 0) CarregarVozes(_filaPrecarga.Dequeue());

            // ducking: a música abaixa um pouco enquanto efeitos importantes tocam
            double alvoDucking = agora < _abaixarMusicaAte ? 0.55 : 1.0;
            _fatorDucking += (alvoDucking - _fatorDucking) * Math.Min(1, dt / (alvoDucking < _fatorDucking ? 60.0 : 300.0));
            if (Math.Abs(alvoDucking - _fatorDucking) < 0.01) _fatorDucking = alvoDucking;

            double volumeMusica = Preferencias.VolumeMusica / 100.0;
            foreach (Deck deck in _decks.ToList())
            {
                if (deck.Ganho < deck.Alvo) deck.Ganho = Math.Min(deck.Alvo, deck.Ganho + deck.Velocidade * dt);
                else if (deck.Ganho > deck.Alvo) deck.Ganho = Math.Max(deck.Alvo, deck.Ganho - deck.Velocidade * dt);

                if (deck.Saindo && deck.Ganho <= 0)
                {
                    Executar(() => _backend.Fechar(deck.Alias), "fechar música");
                    _decks.Remove(deck);
                    continue;
                }
                if (!MusicaDeveTocar && deck.Ganho <= 0 && !deck.Pausado)
                {
                    Executar(() => _backend.Pausar(deck.Alias), "pausar música");
                    deck.Pausado = true;
                }

                int volume = (int)Math.Round(1000 * deck.Ganho * volumeMusica * _fatorDucking);
                bool estavel = deck.Ganho == deck.Alvo && Math.Abs(_fatorDucking - 1.0) < 1e-9;
                if (Math.Abs(volume - deck.UltimoVolume) >= 2 || (volume != deck.UltimoVolume && (estavel || volume == 0)))
                {
                    Executar(() => _backend.DefinirVolume(deck.Alias, volume), "volume música");
                    deck.UltimoVolume = volume;
                }
            }

            // perto do fim da faixa: inicia a próxima e faz o crossfade (loop contínuo)
            if (agora - _ultimaChecagemPosicao >= 500)
            {
                _ultimaChecagemPosicao = agora;
                Deck? principal = DeckPrincipal();
                if (MusicaDeveTocar && principal != null && !principal.Pausado && principal.Duracao > 0)
                {
                    long posicao = Executar(() => _backend.PosicaoMs(principal.Alias), out long p, "posição") ? p : 0;
                    if (principal.Duracao - posicao <= CrossfadeMs) Crossfade(CrossfadeMs);
                }
            }

            // efeitos interrompidos saem com fade curto
            foreach (Voz voz in _vozes.Values.SelectMany(v => v).Where(v => v.FadeInicio >= 0).ToList())
            {
                double f = 1 - (agora - voz.FadeInicio) / FadeVozMs;
                if (f <= 0) PararVoz(voz, agora);
                else Executar(() => _backend.DefinirVolume(voz.Alias, (int)(voz.Volume * f)), "fade efeito");
            }
        }

        // ============================================================ preferências
        public void DefinirMusicaAtiva(bool ativa) { Preferencias.MusicaAtiva = ativa; AplicarEstadoMusica(); SalvarENotificar(); }
        public void DefinirEfeitosAtivos(bool ativos) { Preferencias.EfeitosAtivos = ativos; SalvarENotificar(); }

        public void DefinirMudo(bool mudo)
        {
            Preferencias.Mudo = mudo;
            if (mudo) PararTodosEfeitos();
            AplicarEstadoMusica();
            SalvarENotificar();
        }

        public void AlternarMudo() => DefinirMudo(!Preferencias.Mudo);

        /// <summary>Altera o volume da música (aplicado no próximo tick). Salve com SalvarPreferencias().</summary>
        public void DefinirVolumeMusica(int volume)
        {
            Preferencias.VolumeMusica = volume;
            foreach (Deck d in _decks) d.UltimoVolume = -1;
            if (!ExperienciaIniciada) return;
            Atualizar(_relogio());
        }

        public void DefinirVolumeEfeitos(int volume) => Preferencias.VolumeEfeitos = volume;

        public void SalvarPreferencias() => Preferencias.Salvar();

        private void SalvarENotificar()
        {
            Preferencias.Salvar();
            NotificarEstado();
        }

        private void PararTodosEfeitos()
        {
            double agora = _relogio();
            foreach (Voz v in _vozes.Values.SelectMany(v => v).Where(v => agora < v.Fim)) PararVoz(v, agora);
        }

        private void NotificarEstado() => EstadoAlterado?.Invoke(this, EventArgs.Empty);

        // =================================================================== erros
        private bool Executar(Action acao, string contexto) => Executar(() => { acao(); return 0L; }, out _, contexto);

        private bool Executar(Func<long> acao, out long resultado, string contexto)
        {
            resultado = 0;
            try
            {
                resultado = acao();
                return true;
            }
            catch (Exception ex) when (ex is DllNotFoundException || ex is EntryPointNotFoundException || ex is MarshalDirectiveException)
            {
                // não há dispositivo/biblioteca de som: segue em silêncio, sem afetar o sistema
                RegistrarErroUnico("backend", ex);
                _backend = new SilentAudioBackend();
                Disponivel = false;
                NotificarEstado();
                return false;
            }
            catch (Exception ex)
            {
                RegistrarErroUnico(contexto + ":" + ex.Message, ex);
                return false;
            }
        }

        private void RegistrarErroUnico(string chave, Exception ex)
        {
            if (_errosRegistrados.Add(chave)) RegistroErros.Registrar(ex);
        }

        public void Dispose()
        {
            if (_descartado) return;
            _descartado = true;
            _timer?.Stop();
            _timer?.Dispose();
            try { _backend.FecharTudo(); } catch (Exception) { /* encerrando: ignora */ }
        }
    }
}
