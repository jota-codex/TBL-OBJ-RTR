using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace ViceCityCentral.Audio
{
    /// <summary>Falha ao abrir ou reproduzir um arquivo de áudio.</summary>
    public class AudioException : Exception
    {
        public AudioException(string mensagem) : base(mensagem) { }
    }

    /// <summary>
    /// Abstração do dispositivo de som. O AudioManager só conversa com esta interface,
    /// o que permite trocar a implementação (Windows/MCI, silenciosa ou de testes).
    /// Cada som aberto é identificado por um "alias".
    /// </summary>
    public interface IAudioBackend
    {
        void Abrir(string alias, string caminho);
        void TocarDoInicio(string alias);
        void Pausar(string alias);
        void Retomar(string alias);
        void Parar(string alias);
        void DefinirVolume(string alias, int volume0a1000);
        long DuracaoMs(string alias);
        long PosicaoMs(string alias);
        void Fechar(string alias);
        void FecharTudo();
    }

    /// <summary>
    /// Implementação para Windows usando a MCI (winmm.dll), nativa do sistema:
    /// reproduz MP3 sem dependências externas e permite vários sons e volumes independentes.
    /// </summary>
    public sealed class MciAudioBackend : IAudioBackend
    {
        [DllImport("winmm.dll", CharSet = CharSet.Unicode, EntryPoint = "mciSendStringW")]
        private static extern int mciSendString(string comando, StringBuilder? retorno, int tamanho, IntPtr janela);

        [DllImport("winmm.dll", CharSet = CharSet.Unicode, EntryPoint = "mciGetErrorStringW")]
        private static extern bool mciGetErrorString(int erro, StringBuilder texto, int tamanho);

        private readonly HashSet<string> _abertos = new HashSet<string>();

        private static string Enviar(string comando)
        {
            var retorno = new StringBuilder(256);
            int codigo = mciSendString(comando, retorno, retorno.Capacity, IntPtr.Zero);
            if (codigo != 0)
            {
                var texto = new StringBuilder(256);
                mciGetErrorString(codigo, texto, texto.Capacity);
                throw new AudioException($"MCI {codigo}: {texto} [{comando}]");
            }
            return retorno.ToString();
        }

        public void Abrir(string alias, string caminho)
        {
            if (_abertos.Contains(alias)) return;
            Enviar($"open \"{caminho}\" type mpegvideo alias {alias}");
            Enviar($"set {alias} time format milliseconds");
            _abertos.Add(alias);
        }

        public void TocarDoInicio(string alias) => Enviar($"play {alias} from 0");
        public void Pausar(string alias) => Enviar($"pause {alias}");
        public void Retomar(string alias) => Enviar($"resume {alias}");
        public void Parar(string alias) => Enviar($"stop {alias}");
        public void DefinirVolume(string alias, int volume) => Enviar($"setaudio {alias} volume to {Math.Max(0, Math.Min(1000, volume))}");

        public long DuracaoMs(string alias) => long.TryParse(Enviar($"status {alias} length"), out long v) ? v : 0;
        public long PosicaoMs(string alias) => long.TryParse(Enviar($"status {alias} position"), out long v) ? v : 0;

        public void Fechar(string alias)
        {
            if (!_abertos.Remove(alias)) return;
            mciSendString($"close {alias}", null, 0, IntPtr.Zero);
        }

        public void FecharTudo()
        {
            foreach (string alias in _abertos) mciSendString($"close {alias}", null, 0, IntPtr.Zero);
            _abertos.Clear();
        }
    }

    /// <summary>Backend mudo, usado quando o dispositivo de som não está disponível.</summary>
    public sealed class SilentAudioBackend : IAudioBackend
    {
        public void Abrir(string alias, string caminho) { }
        public void TocarDoInicio(string alias) { }
        public void Pausar(string alias) { }
        public void Retomar(string alias) { }
        public void Parar(string alias) { }
        public void DefinirVolume(string alias, int volume0a1000) { }
        public long DuracaoMs(string alias) => 0;
        public long PosicaoMs(string alias) => 0;
        public void Fechar(string alias) { }
        public void FecharTudo() { }
    }
}
