using System;
using System.Collections.Generic;
using System.Globalization;
using ViceCityCentral.Repositories;
using ViceCityCentral.Services;

namespace ViceCityCentral.Audio
{
    /// <summary>Preferências de áudio do usuário (gravadas no banco, tabela Configuracoes).</summary>
    public class PreferenciasAudio
    {
        public const int VolumeMusicaPadrao = 20;   // 15–25% conforme a especificação
        public const int VolumeEfeitosPadrao = 70;

        private int _volumeMusica = VolumeMusicaPadrao;
        private int _volumeEfeitos = VolumeEfeitosPadrao;

        public bool MusicaAtiva { get; set; } = true;
        public bool EfeitosAtivos { get; set; } = true;
        public bool Mudo { get; set; }

        /// <summary>O usuário já iniciou a experiência sonora antes (nas próximas visitas inicia na 1ª interação).</summary>
        public bool ExperienciaAtivada { get; set; }

        public int VolumeMusica { get => _volumeMusica; set => _volumeMusica = Limitar(value); }
        public int VolumeEfeitos { get => _volumeEfeitos; set => _volumeEfeitos = Limitar(value); }

        private static int Limitar(int v) => v < 0 ? 0 : (v > 100 ? 100 : v);

        public PreferenciasAudio Clonar() => (PreferenciasAudio)MemberwiseClone();

        // ------------------------------------------------------------ persistência
        private const string Prefixo = "Audio.";

        public static PreferenciasAudio Carregar()
        {
            var p = new PreferenciasAudio();
            try
            {
                Dictionary<string, string> v = new ConfiguracaoRepository().CarregarTodas();
                p.MusicaAtiva = LerBool(v, nameof(MusicaAtiva), p.MusicaAtiva);
                p.EfeitosAtivos = LerBool(v, nameof(EfeitosAtivos), p.EfeitosAtivos);
                p.Mudo = LerBool(v, nameof(Mudo), p.Mudo);
                p.ExperienciaAtivada = LerBool(v, nameof(ExperienciaAtivada), p.ExperienciaAtivada);
                p.VolumeMusica = LerInt(v, nameof(VolumeMusica), p.VolumeMusica);
                p.VolumeEfeitos = LerInt(v, nameof(VolumeEfeitos), p.VolumeEfeitos);
            }
            catch (Exception ex)
            {
                RegistroErros.Registrar(ex); // usa os padrões se o banco não puder ser lido
            }
            return p;
        }

        public void Salvar()
        {
            try
            {
                new ConfiguracaoRepository().SalvarTodas(new Dictionary<string, string>
                {
                    [Prefixo + nameof(MusicaAtiva)] = MusicaAtiva.ToString(),
                    [Prefixo + nameof(EfeitosAtivos)] = EfeitosAtivos.ToString(),
                    [Prefixo + nameof(Mudo)] = Mudo.ToString(),
                    [Prefixo + nameof(ExperienciaAtivada)] = ExperienciaAtivada.ToString(),
                    [Prefixo + nameof(VolumeMusica)] = VolumeMusica.ToString(CultureInfo.InvariantCulture),
                    [Prefixo + nameof(VolumeEfeitos)] = VolumeEfeitos.ToString(CultureInfo.InvariantCulture)
                });
            }
            catch (Exception ex)
            {
                RegistroErros.Registrar(ex); // falha ao salvar preferências não interrompe o uso
            }
        }

        private static bool LerBool(Dictionary<string, string> v, string chave, bool padrao)
            => v.TryGetValue(Prefixo + chave, out string? s) && bool.TryParse(s, out bool b) ? b : padrao;

        private static int LerInt(Dictionary<string, string> v, string chave, int padrao)
            => v.TryGetValue(Prefixo + chave, out string? s) && int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out int i) ? i : padrao;
    }
}
