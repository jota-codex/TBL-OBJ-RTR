using System.Collections.Generic;

namespace ViceCityCentral.Audio
{
    /// <summary>Todos os sons de interface do sistema.</summary>
    public enum SomInterface
    {
        Hover,            // passar o mouse sobre botões
        Clique,           // clique em botões
        MenuAbrir,        // abrir menus/listas suspensas/painel
        MenuFechar,       // fechar menus/janelas
        TransicaoPagina,  // trocar de tela
        Selecionar,       // selecionar opção/linha
        Voltar,           // voltar à tela anterior
        ModalAbrir,       // abrir janelas/modais
        Confirmar,        // confirmar ação
        Cancelar,         // cancelar ação
        Sucesso,          // salvar informações
        Excluir,          // alerta antes de excluir
        Erro,             // erros e validações
        Notificacao,      // avisos e notificações
        Carregando,       // processamento/atualização
        Entrada           // entrada cinematográfica (início da experiência)
    }

    /// <summary>Como cada som deve se comportar (arquivo, prioridade, repetição, pré-carga).</summary>
    public sealed class DefinicaoSom
    {
        public DefinicaoSom(string arquivo, int prioridade, int intervaloMinimoMs, int vozes, bool precarregar, double ganho = 1.0, bool abaixaMusica = false)
        {
            Arquivo = arquivo;
            Prioridade = prioridade;
            IntervaloMinimoMs = intervaloMinimoMs;
            Vozes = vozes;
            Precarregar = precarregar;
            Ganho = ganho;
            AbaixaMusica = abaixaMusica;
        }

        /// <summary>Caminho relativo a Assets/Audio.</summary>
        public string Arquivo { get; }

        /// <summary>Sons de prioridade maior interrompem (com fade) os menores tocados logo antes.</summary>
        public int Prioridade { get; }

        /// <summary>Debounce: intervalo mínimo entre duas reproduções do mesmo som.</summary>
        public int IntervaloMinimoMs { get; }

        /// <summary>Quantas instâncias simultâneas do mesmo som podem existir.</summary>
        public int Vozes { get; }

        /// <summary>Carregar logo após iniciar a experiência (sons mais frequentes).</summary>
        public bool Precarregar { get; }

        /// <summary>Ajuste fino de volume (0..1) aplicado sobre o volume de efeitos.</summary>
        public double Ganho { get; }

        /// <summary>Abaixa a música momentaneamente para o efeito se destacar ("ducking").</summary>
        public bool AbaixaMusica { get; }
    }

    /// <summary>Catálogo central: liga cada som ao seu arquivo e às suas regras.</summary>
    public static class CatalogoAudio
    {
        public static readonly IReadOnlyDictionary<SomInterface, DefinicaoSom> Efeitos = new Dictionary<SomInterface, DefinicaoSom>
        {
            [SomInterface.Hover]           = new DefinicaoSom("ui/button-hover.mp3",    0,  90, 2, true, 0.55),
            [SomInterface.Clique]          = new DefinicaoSom("ui/button-click.mp3",    1,  45, 3, true),
            [SomInterface.Selecionar]      = new DefinicaoSom("ui/select.mp3",          1,  70, 2, true),
            [SomInterface.MenuAbrir]       = new DefinicaoSom("ui/menu-open.mp3",       1, 150, 1, true),
            [SomInterface.MenuFechar]      = new DefinicaoSom("ui/menu-close.mp3",      1, 150, 1, true),
            [SomInterface.Cancelar]        = new DefinicaoSom("ui/cancel.mp3",          2, 150, 1, true),
            [SomInterface.Voltar]          = new DefinicaoSom("ui/navigate-back.mp3",   2, 250, 1, false, 1.0, true),
            [SomInterface.ModalAbrir]      = new DefinicaoSom("ui/modal-open.mp3",      2, 200, 1, false),
            [SomInterface.TransicaoPagina] = new DefinicaoSom("ui/page-transition.mp3", 2, 250, 1, true, 0.9, true),
            [SomInterface.Carregando]      = new DefinicaoSom("ui/loading.mp3",         2, 600, 1, false),
            [SomInterface.Confirmar]       = new DefinicaoSom("ui/confirm.mp3",         3, 200, 1, true, 1.0, true),
            [SomInterface.Excluir]         = new DefinicaoSom("ui/delete.mp3",          3, 300, 1, false, 1.0, true),
            [SomInterface.Notificacao]     = new DefinicaoSom("ui/notification.mp3",    4, 300, 1, false, 1.0, true),
            [SomInterface.Sucesso]         = new DefinicaoSom("ui/success.mp3",         4, 300, 1, false, 1.0, true),
            [SomInterface.Erro]            = new DefinicaoSom("ui/error.mp3",           5, 300, 1, false, 1.0, true),
            [SomInterface.Entrada]         = new DefinicaoSom("ui/login.mp3",           6, 2000, 1, false, 1.0, true)
        };

        /// <summary>Faixas originais da trilha ambiente (tocadas em sequência com crossfade).</summary>
        public static readonly IReadOnlyList<(string Arquivo, string Titulo)> Faixas = new[]
        {
            ("music/vice-city-ambient.mp3", "Vice City Ambient"),
            ("music/ocean-drive-nights.mp3", "Ocean Drive Nights"),
            ("music/leonida-sunset.mp3", "Leonida Sunset")
        };
    }
}
