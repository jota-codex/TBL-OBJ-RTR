"""
Síntese procedural das trilhas e efeitos sonoros ORIGINAIS do Vice City Central.
Tudo é gerado do zero (osciladores, ruído, FM) — nenhum sample de terceiros.
"""
import os, subprocess, sys
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve

SR = 44100
OUT = sys.argv[1] if len(sys.argv) > 1 else 'out'
rng = np.random.default_rng(1986)

# ----------------------------------------------------------------- utilitários
def t_(dur): return np.arange(int(dur * SR)) / SR
def midi(n): return 440.0 * 2 ** ((n - 69) / 12)
def lp(x, f, order=2): return sosfilt(butter(order, min(f, SR/2-100), 'low', fs=SR, output='sos'), x)
def hp(x, f, order=2): return sosfilt(butter(order, f, 'high', fs=SR, output='sos'), x)
def bp(x, lo, hi, order=2): return sosfilt(butter(order, [lo, min(hi, SR/2-100)], 'band', fs=SR, output='sos'), x)
def env_adsr(n, a, d, s, r, dur_hold=None):
    a, d, r = int(a*SR), int(d*SR), int(r*SR)
    hold = n - a - d - r
    if hold < 0:
        e = np.minimum(np.linspace(0, 1, n), np.linspace(1, 0, n) * 4).clip(0, 1); return e
    return np.concatenate([np.linspace(0, 1, a, endpoint=False), np.linspace(1, s, d, endpoint=False),
                           np.full(hold, s), np.linspace(s, 0, r)])[:n]
def expdec(n, tau): return np.exp(-np.arange(n) / (tau * SR))
def saw(f, t, phase=0.0, maxk=40):
    # dente de serra com redução de aliasing (aditivo limitado em banda)
    y = np.zeros_like(t); k = 1
    fmax = np.max(f) if np.ndim(f) else f
    while k * fmax < SR / 2.2 and k <= maxk:
        y += np.sin(2*np.pi*k*(np.cumsum(f)/SR if np.ndim(f) else f*t) + phase*k) / k; k += 1
    return y * (2/np.pi)
def sq(f, t, pw=0.5):
    return saw(f, t) - saw(f, t, phase=2*np.pi*pw)
def place(buf, sig, start):
    s = int(start * SR)
    if s >= buf.shape[-1]: return
    e = min(buf.shape[-1], s + sig.shape[-1])
    buf[..., s:e] += sig[..., :e - s]
def pan(sig, p):  # p -1..1
    l = np.cos((p + 1) * np.pi / 4); r = np.sin((p + 1) * np.pi / 4)
    return np.vstack([sig * l, sig * r])
def reverb_ir(dur=2.6, decay=2.2, bright=6000, seed=0):
    r = np.random.default_rng(seed); n = int(dur*SR)
    ir = np.vstack([r.standard_normal(n), r.standard_normal(n)]) * np.exp(-np.arange(n)/(decay/6.9*SR))
    ir = np.vstack([lp(ir[0], bright), lp(ir[1], bright)])
    ir[:, :int(0.012*SR)] *= np.linspace(0, 1, int(0.012*SR))
    return ir / np.sqrt(np.sum(ir**2, axis=1, keepdims=True))
def reverb(st, mix, ir):
    wet = np.vstack([fftconvolve(st[0], ir[0])[:st.shape[1]], fftconvolve(st[1], ir[1])[:st.shape[1]]])
    return st + wet * mix
def mono_reverb(x, mix, dur=1.2, decay=1.0, bright=7000, seed=3):
    ir = reverb_ir(dur, decay, bright, seed)[0]
    return x + fftconvolve(x, ir)[:len(x)] * mix
def softclip(x, drive=1.0): return np.tanh(x * drive) / np.tanh(drive)
def normalize(x, peak_db):
    return x / (np.max(np.abs(x)) + 1e-9) * 10 ** (peak_db / 20)
def rms_db(x): return 20*np.log10(np.sqrt(np.mean(x**2)) + 1e-12)

# ------------------------------------------------------------------ instrumentos
def kick(vel=1.0, dur=0.5):
    t = t_(dur); f = 45 + 95 * np.exp(-t / 0.035)
    body = np.sin(2*np.pi*np.cumsum(f)/SR) * expdec(len(t), 0.16)
    click = hp(rng.standard_normal(len(t)), 2000) * expdec(len(t), 0.004) * 0.25
    return softclip((body + click) * vel, 1.5)
def snare(vel=1.0, dur=0.45):
    t = t_(dur)
    tone = (np.sin(2*np.pi*185*t) + 0.5*np.sin(2*np.pi*330*t)) * expdec(len(t), 0.05)
    noise = bp(rng.standard_normal(len(t)), 1200, 9000) * expdec(len(t), 0.11)
    return (0.55*tone + 0.9*noise) * vel
def clap(vel=1.0, dur=0.45):
    n = int(dur*SR); x = np.zeros(n); nz = bp(rng.standard_normal(n), 900, 6000)
    for off in (0, 0.011, 0.022):
        s = int(off*SR); x[s:] += nz[:n-s] * expdec(n - s, 0.012)
    x += nz * expdec(n, 0.14) * 0.6
    return x * vel
def hat(vel=1.0, open_=False):
    dur = 0.35 if open_ else 0.07; n = int(dur*SR)
    x = hp(rng.standard_normal(n), 7000, 4) * expdec(n, 0.12 if open_ else 0.018)
    return x * vel
def shaker(vel=1.0):
    n = int(0.12*SR); x = bp(rng.standard_normal(n), 4000, 12000) * env_adsr(n, 0.02, 0.03, 0.4, 0.06)
    return x * vel
def sub_bass(note, dur, vel=1.0):
    t = t_(dur); f = midi(note)
    x = np.sin(2*np.pi*f*t) + 0.25*np.sin(2*np.pi*2*f*t)
    return softclip(x * env_adsr(len(t), 0.008, 0.1, 0.85, 0.06), 1.3) * vel
def synth_bass(note, dur, vel=1.0, cutoff=900):
    t = t_(dur); f = midi(note)
    x = saw(f, t) * 0.7 + sq(f*0.5, t) * 0.3
    e = env_adsr(len(t), 0.004, 0.12, 0.5, 0.05)
    k = expdec(len(t), 0.06)  # filtro "abrindo" no ataque: mistura de versão brilhante e escura
    x = lp(x, cutoff + 1800, 2) * k + lp(x, cutoff, 2) * (1 - k)
    return x * e * vel
def pad(notes, dur, vel=1.0, cutoff=1800, detune=0.11):
    t = t_(dur); x = np.zeros((2, len(t)))
    for i, n in enumerate(notes):
        for d, p in ((-detune, -0.6), (0, 0), (detune, 0.6)):
            f = midi(n + d)
            lfo = 1 + 0.002*np.sin(2*np.pi*(0.3 + 0.07*i)*t)
            x += pan(saw(f*lfo, t, maxk=max(3, int(cutoff*1.4/f))), p * 0.7) / 3
    x = np.vstack([lp(x[0], cutoff, 2), lp(x[1], cutoff, 2)])
    return x * env_adsr(len(t), 0.9, 0.5, 0.8, 1.2) * vel / max(1, len(notes))
def fm_bell(note, dur, vel=1.0, ratio=2.0, index=3.0, tau=0.5, ratio2=None):
    t = t_(dur); f = midi(note)
    ie = index * expdec(len(t), tau * 0.4)
    mod = np.sin(2*np.pi*f*ratio*t)
    if ratio2: mod += 0.5*np.sin(2*np.pi*f*ratio2*t)
    x = np.sin(2*np.pi*f*t + ie*mod)
    return x * env_adsr(len(t), 0.002, 0.05, 1.0, 0.05) * expdec(len(t), tau) * vel
def steel_pan(note, dur=0.9, vel=1.0):  # timbre "steel drum" tropical (FM inarmônico)
    return fm_bell(note, dur, vel, ratio=2.0, index=2.2, tau=0.35, ratio2=3.01)
def marimba(note, dur=0.5, vel=1.0):
    return fm_bell(note, dur, vel, ratio=4.0, index=1.2, tau=0.12)
def rhodes(notes, dur, vel=1.0):
    t = t_(dur); x = np.zeros(len(t))
    for n in notes:
        x += fm_bell(n, dur, 1.0, ratio=1.0, index=1.4, tau=0.9)
    trem = 1 + 0.25*np.sin(2*np.pi*4.5*t)
    return pan(x * trem, 0) * vel / len(notes)
def pluck(note, dur, vel=1.0, cutoff=3000):
    t = t_(dur); f = midi(note)
    x = saw(f, t) * 0.6 + saw(f*1.005, t) * 0.4
    k = expdec(len(t), 0.08)
    x = lp(x, cutoff + 300) * k + lp(x, cutoff * 0.3 + 300) * (1 - k)
    return x * expdec(len(t), 0.22) * vel
def waves(dur, vel=1.0):
    n = int(dur*SR); w = np.cumsum(rng.standard_normal(n)); w = hp(w, 40); w = lp(w, 900)
    w /= np.max(np.abs(w)) + 1e-9
    t = np.arange(n)/SR; swell = 0.55 + 0.45*np.sin(2*np.pi*t/7.5)**2
    foam = hp(rng.standard_normal(n), 2500) * 0.05 * swell**3
    return np.vstack([w*swell*0.8 + foam, np.roll(w*swell*0.8, 900) + foam]) * vel
def vinyl(dur, vel=1.0):
    n = int(dur*SR); x = np.zeros(n); idx = rng.integers(0, n, int(dur*7)); x[idx] = rng.uniform(-1, 1, len(idx))
    return lp(hp(x, 1000), 6000) * vel + hp(rng.standard_normal(n), 4000) * 0.01 * vel

# ------------------------------------------------------------------ composição
def compose(bpm, bars, chords, bass_style, lead, seed, extras):
    global rng
    rng = np.random.default_rng(seed)
    beat = 60 / bpm; bar = beat * 4; total = bars * bar + 3.0
    n = int(total * SR)
    drums = np.zeros((2, n)); bass = np.zeros((2, n)); pads = np.zeros((2, n)); lead_bus = np.zeros((2, n)); amb = np.zeros((2, n))
    kick_times = []
    sw = 0.06 * beat  # swing hip-hop
    intro, outro = 4, 4
    for b in range(bars):
        t0 = b * bar
        ch = chords[b % len(chords)]
        section = 'intro' if b < intro else ('outro' if b >= bars - outro else ('A' if b < intro + (bars-intro-outro)//2 else 'B'))
        # pads em todas as seções
        pads_v = 0.55 if section in ('intro', 'outro') else 0.45
        cut = 900 + 1400 * (b / bars if section != 'outro' else (bars - b) / outro * 0.5)
        place(pads, pad(ch['pad'], bar + 0.6, pads_v, cutoff=cut), t0)
        if 'rhodes' in extras and section != 'intro':
            for k, beat_off in enumerate((0, 1.5, 2.5)):
                place(pads, rhodes(ch['pad'][1:], beat*1.4, 0.18), t0 + beat_off*beat)
        if section in ('A', 'B'):
            # bateria (boom-bap com swing)
            for s in range(16):
                tt = t0 + s * beat/4 + (sw if s % 2 else 0)
                if s in extras.get('kicks', (0, 7, 10)):
                    place(drums, pan(kick(0.95), 0), tt); kick_times.append(tt)
                if s in (4, 12):
                    place(drums, pan(snare(0.55) + clap(0.35 if extras.get('clap') else 0.0), 0.05), tt)
                if s % 2 == 0 or extras.get('hats16'):
                    v = 0.16 if s % 4 == 0 else 0.1
                    place(drums, pan(hat(v * rng.uniform(0.8, 1.1)), 0.35), tt)
                if s == 14 and b % 2: place(drums, pan(hat(0.12, True), 0.35), tt)
                if extras.get('shaker') and s % 2 == 1:
                    place(drums, pan(shaker(0.08), -0.4), tt)
            # baixo
            root = ch['bass']
            if bass_style == 'sub':
                for off, dur_b, nn in ((0, 1.5, root), (1.75, 0.5, root), (2.5, 1.4, root + ch.get('walk', 0))):
                    place(bass, pan(sub_bass(nn, dur_b*beat, 0.9), 0), t0 + off*beat)
            else:  # arpejo synthwave em colcheias
                for s in range(8):
                    nn = root + (12 if s % 2 else 0)
                    place(bass, pan(synth_bass(nn, beat/2*0.9, 0.55, cutoff=700 + 400*(section == 'B')), 0), t0 + s*beat/2)
                    place(bass, pan(sub_bass(root, beat/2*0.9, 0.35), 0), t0 + s*beat/2) if s % 2 == 0 else None
            # melodia na seção B
            if section == 'B':
                for (pos, note, d) in lead(b, ch):
                    sig = {'steel': steel_pan, 'marimba': marimba}.get(extras['lead'])
                    if sig: place(lead_bus, pan(sig(note, 1.0, 0.32), rng.uniform(-0.4, 0.4)), t0 + pos*beat)
                    else: place(lead_bus, pan(pluck(note, d*beat + 0.2, 0.22), rng.uniform(-0.3, 0.3)), t0 + pos*beat)
    amb += waves(total, 0.07 if 'waves' in extras else 0.0)
    amb += pan(vinyl(total, 0.05 if extras.get('vinyl') else 0), 0)
    # sidechain: abaixa pads/baixo quando o bumbo toca
    duck = np.ones(n)
    for kt in kick_times:
        s = int(kt*SR); e = min(n, s + int(0.25*SR))
        duck[s:e] = np.minimum(duck[s:e], 1 - 0.45*expdec(e - s, 0.09))
    pads *= duck; bass *= (0.6 + 0.4*duck)
    ir = reverb_ir(3.0, 2.8, 5500, seed)
    pads = reverb(pads, 0.55, ir); lead_bus = reverb(lead_bus, 0.45, ir)
    # balanço automático: cada grupo é ajustado para um nível RMS alvo (mixagem consistente)
    def nivel(bus, alvo_db):
        r = rms_db(bus)
        return bus * 10 ** ((alvo_db - r) / 20) if r > -100 else bus
    mix = nivel(drums, -21) + nivel(bass, -22) + nivel(pads, -19.5) + nivel(lead_bus, -25) + (nivel(amb, -31) if np.any(amb) else amb)
    mix = np.vstack([hp(mix[0], 28), hp(mix[1], 28)])
    mix = softclip(normalize(mix, -1.0) * 1.2, 1.1)
    # fade nas pontas (o crossfade do motor suaviza ainda mais)
    f = int(1.5*SR); mix[:, :f] *= np.linspace(0, 1, f); mix[:, -int(3*SR):] *= np.linspace(1, 0, int(3*SR))
    return normalize(mix, -3.0)

def chordset(spec):
    return [{'pad': p, 'bass': b, 'walk': w} for p, b, w in spec]

def lead_vice(b, ch):  # melodia tropical em A menor
    notes = [ch['pad'][-1] + 12, ch['pad'][-2] + 12, ch['pad'][-1] + 14, ch['pad'][-3] + 12]
    pat = [(0, 0), (0.75, 1), (1.5, 2), (2.5, 1), (3.0, 3)] if b % 2 == 0 else [(0.5, 0), (1.5, 3), (2.25, 1), (3.25, 0)]
    return [(p, notes[i], 0.5) for p, i in pat]
def lead_night(b, ch):
    top = ch['pad'][-1] + 12
    return [(s*0.5, top + (0, 3, 7, 12, 7, 3, 0, -5)[s], 0.4) for s in range(8)]
def lead_sunset(b, ch):
    tones = sorted(ch['pad'])[1:]
    return [(p, tones[i % len(tones)] + 12, 0.6) for i, p in enumerate((0, 1, 1.5, 2.5, 3.25))] if b % 2 else [(0.5, tones[-1] + 12, 1)]

def track_vice():  # 92 BPM — synthwave + hip-hop + tropical (A menor: Am9 F C G)
    chords = chordset([([57, 60, 64, 67, 71], 33, 3), ([53, 57, 60, 64, 67], 29, 2), ([48, 55, 60, 64, 67], 36, -1), ([55, 59, 62, 66, 69], 31, 2)])
    return compose(92, 32, chords, 'sub', lead_vice, 11, {'lead': 'steel', 'waves': 1, 'rhodes': 1, 'shaker': 1})
def track_night():  # 100 BPM — synthwave noturno (D menor: Dm Bb F C)
    chords = chordset([([50, 53, 57, 60, 64], 26, 0), ([46, 50, 53, 57, 60], 22, 0), ([45, 48, 53, 57, 60], 29, 0), ([48, 52, 55, 60, 64], 24, 0)])
    return compose(100, 32, chords, 'arp', lead_night, 22, {'lead': 'pluck', 'clap': 1, 'kicks': (0, 6, 8, 10), 'hats16': 1})
def track_sunset():  # 86 BPM — chill tropical (Fmaj7 Em7 Dm7 Cmaj7)
    chords = chordset([([53, 57, 60, 64, 69], 29, 0), ([52, 55, 59, 62, 67], 28, 0), ([50, 53, 57, 60, 65], 26, 2), ([48, 52, 55, 59, 64], 24, 0)])
    return compose(86, 24, chords, 'sub', lead_sunset, 33, {'lead': 'marimba', 'waves': 1, 'rhodes': 1, 'vinyl': 1, 'shaker': 1})

# ------------------------------------------------------------------ efeitos de UI
def tone_seq(seq, wave='sine', tau=0.08, gap=0.0):
    out = np.zeros(int(sum(d for _, d in seq)*SR + 0.6*SR)); t0 = 0
    for note, d in seq:
        tt = t_(d + 0.3); f = midi(note)
        if wave == 'bell': x = fm_bell(note, d + 0.3, 1.0, 3.5, 1.6, tau)
        elif wave == 'sq': x = lp(sq(f, tt, 0.3), 2600) * expdec(len(tt), tau)
        elif wave == 'saw': x = lp(saw(f, tt), 3000) * expdec(len(tt), tau)
        else: x = np.sin(2*np.pi*f*tt) * expdec(len(tt), tau)
        x[:int(0.002*SR)] *= np.linspace(0, 1, int(0.002*SR))
        place(out, x, t0); t0 += d + gap
    return out
def trim(x, thr=1e-4):
    idx = np.where(np.abs(x) > thr)[0]
    x = x[:idx[-1] + 1] if len(idx) else x
    fo = min(len(x)//4, int(0.01*SR)); x[-fo:] *= np.linspace(1, 0, fo); return x
def whoosh(dur, f0, f1, q=0.5):
    n = int(dur*SR); nz = rng.standard_normal(n); out = np.zeros(n); blk = 512
    fr = np.geomspace(f0, f1, n // blk + 1)
    for i in range(0, n, blk):
        c = fr[i // blk]; seg = nz[max(0, i-2048):i+blk]
        y = bp(seg, c*(1-q*0.5), c*(1+q)); out[i:i+blk] = y[-len(out[i:i+blk]):]
    e = np.sin(np.linspace(0, np.pi, n)) ** 1.5
    return out * e

def sfx():
    S = {}
    # hover: tic curtíssimo e baixo
    h = np.sin(2*np.pi*2600*t_(0.05)) * expdec(int(0.05*SR), 0.008) + hp(rng.standard_normal(int(0.05*SR)), 6000)*expdec(int(0.05*SR), 0.002)*0.3
    S['button-hover'] = (h, -22)
    # clique: transiente + blip FM descendente
    t = t_(0.09); f = 1500 * np.exp(-t/0.03) + 700
    c = np.sin(2*np.pi*np.cumsum(f)/SR + 1.2*np.sin(2*np.pi*2.01*np.cumsum(f)/SR)) * expdec(len(t), 0.02)
    c += hp(rng.standard_normal(len(t)), 3000) * expdec(len(t), 0.003) * 0.5
    S['button-click'] = (c, -10)
    # abrir menu: "boot" digital ascendente
    m = tone_seq([(76, 0.035), (81, 0.035), (88, 0.09)], 'sq', 0.05)
    S['menu-open'] = (mono_reverb(m, 0.25, 0.6, 0.5), -13)
    S['menu-close'] = (mono_reverb(tone_seq([(88, 0.035), (81, 0.035), (72, 0.08)], 'sq', 0.04), 0.2, 0.5, 0.4), -14)
    # transição de página: whoosh cinematográfico + pulso grave + brilho
    w = whoosh(0.55, 300, 5000, 0.6) * 0.8
    thump = np.sin(2*np.pi*np.cumsum(55 + 60*np.exp(-t_(0.4)/0.05))/SR) * expdec(int(0.4*SR), 0.12)
    shimmer = tone_seq([(93, 0.06), (100, 0.2)], 'bell', 0.15) * 0.25
    tr = np.zeros(int(0.9*SR)); place(tr, w, 0); place(tr, thump * 0.7, 0.3); place(tr, shimmer, 0.32)
    S['page-transition'] = (mono_reverb(tr, 0.35, 1.0, 0.8), -9)
    # selecionar: dois blips (quinta justa)
    S['select'] = (tone_seq([(84, 0.045), (91, 0.07)], 'sine', 0.03), -15)
    # voltar: whoosh descendente + blip grave
    b = np.zeros(int(0.5*SR)); place(b, whoosh(0.35, 4000, 400, 0.6) * 0.7, 0); place(b, tone_seq([(79, 0.04), (72, 0.08)], 'sine', 0.04), 0.18)
    S['navigate-back'] = (mono_reverb(b, 0.2, 0.6, 0.5), -11)
    # abrir modal: swell suave + carrilhão vítreo
    sw = lp(saw(midi(64), t_(0.35)) + saw(midi(71), t_(0.35)), 1800) * env_adsr(int(0.35*SR), 0.15, 0.1, 0.6, 0.1) * 0.25
    mo = np.zeros(int(0.7*SR)); place(mo, sw, 0); place(mo, tone_seq([(88, 0.25)], 'bell', 0.2) * 0.5, 0.12)
    S['modal-open'] = (mono_reverb(mo, 0.4, 1.0, 0.8), -14)
    # confirmar: dois tons de sino ascendentes (assinatura do sistema)
    S['confirm'] = (mono_reverb(tone_seq([(76, 0.08), (83, 0.28)], 'bell', 0.18), 0.35, 1.0, 0.8), -9)
    # cancelar: discreto, grave e descendente
    S['cancel'] = (tone_seq([(67, 0.05), (62, 0.09)], 'sine', 0.05), -16)
    # sucesso: arpejo brilhante maior com cauda
    S['success'] = (mono_reverb(tone_seq([(72, 0.07), (76, 0.07), (79, 0.07), (84, 0.45)], 'bell', 0.25), 0.45, 1.6, 1.3), -8)
    # excluir (alerta): pulso de dois tons, timbre quadrado filtrado
    S['delete'] = (mono_reverb(tone_seq([(81, 0.12), (77, 0.12), (81, 0.12), (77, 0.2)], 'sq', 0.09), 0.2, 0.6, 0.5), -12)
    # erro: zumbido negativo descendente (segunda menor)
    e1 = tone_seq([(58, 0.12), (57, 0.25)], 'saw', 0.14)
    S['error'] = (softclip(mono_reverb(e1, 0.15, 0.5, 0.4) * 1.5, 1.4), -10)
    # notificação: ping de celular (quarta ascendente) com eco
    nt = tone_seq([(81, 0.09), (86, 0.25)], 'bell', 0.16)
    ec = np.zeros(len(nt) + int(0.5*SR)); place(ec, nt, 0); place(ec, nt * 0.35, 0.18); place(ec, nt * 0.12, 0.36)
    S['notification'] = (mono_reverb(ec, 0.3, 0.8, 0.6), -11)
    # carregamento: "processamento" — blips rápidos ascendentes
    ld = np.zeros(int(0.9*SR))
    for i in range(14):
        place(ld, tone_seq([(int(84 + rng.integers(-5, 8) + i*0.6), 0.025)], 'sq', 0.015) * (0.5 + i/28), i*0.042)
    place(ld, tone_seq([(96, 0.15)], 'bell', 0.12) * 0.6, 0.6)
    S['loading'] = (mono_reverb(ld, 0.25, 0.6, 0.5), -13)
    # entrada cinematográfica (login): boom + riser + acorde + brilho
    T = 3.4; L = np.zeros(int(T*SR))
    riser = whoosh(1.4, 200, 9000, 0.4) * np.linspace(0.2, 1, int(1.4*SR)) ** 2
    place(L, riser * 0.5, 0)
    boom = np.sin(2*np.pi*np.cumsum(38 + 80*np.exp(-t_(2.0)/0.08))/SR) * expdec(int(2.0*SR), 0.6)
    place(L, softclip(boom * 1.6, 1.5) * 0.9, 1.35)
    chord = pad([57, 64, 67, 71, 74], 2.0, 1.0, cutoff=2600)[0] * 2.2
    place(L, chord, 1.35)
    for i, nn in enumerate((81, 84, 88, 91, 96)):
        place(L, fm_bell(nn, 0.8, 0.22, 3.0, 1.2, 0.35), 1.45 + i*0.08)
    S['login'] = (mono_reverb(L, 0.55, 2.4, 2.2, 6000), -6)
    return S

def to_mp3(x, path, stereo=False, kbps=128):
    wav = path.replace('.mp3', '.wav')
    data = (np.clip(x, -1, 1) * 32767).astype('<i2')
    data = data.T.reshape(-1) if stereo else data
    import wave
    with wave.open(wav, 'wb') as w:
        w.setnchannels(2 if stereo else 1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(data.tobytes())
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-codec:a', 'libmp3lame', '-b:a', f'{kbps}k', path], check=True)
    os.remove(wav)

if __name__ == '__main__':
    os.makedirs(f'{OUT}/music', exist_ok=True); os.makedirs(f'{OUT}/ui', exist_ok=True)
    for nome, (x, db) in sfx().items():
        x = trim(normalize(x, db) if nome != 'button-hover' else normalize(x, db))
        to_mp3(x, f'{OUT}/ui/{nome}.mp3')
        print(f'ui/{nome}.mp3  {len(x)/SR:.2f}s  pico {db} dBFS  rms {rms_db(x):.1f} dB')
    for nome, fn in (('vice-city-ambient', track_vice), ('ocean-drive-nights', track_night), ('leonida-sunset', track_sunset)):
        x = fn(); to_mp3(x, f'{OUT}/music/{nome}.mp3', stereo=True, kbps=160)
        print(f'music/{nome}.mp3  {x.shape[1]/SR:.1f}s  rms {rms_db(x):.1f} dB')
