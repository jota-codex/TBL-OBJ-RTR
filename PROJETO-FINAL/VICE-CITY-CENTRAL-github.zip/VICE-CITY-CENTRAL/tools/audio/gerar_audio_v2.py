"""
Pacote 2 de áudio do Vice City Central (original).
Efeitos com timbre de guitarra dedilhada (Karplus-Strong), madeira e "whooshes" cinematográficos,
e uma faixa retrô de rock suave (clima de estrada ao pôr do sol). Nada é copiado de músicas existentes.
"""
import os, sys
import numpy as np
import gerar_audio as S
from gerar_audio import SR, t_, midi, lp, hp, bp, expdec, env_adsr, place, pan, softclip, normalize, mono_reverb, reverb, reverb_ir, whoosh, trim, to_mp3, rms_db

rng = np.random.default_rng(2026)

def ks(note, dur, vel=1.0, brilho=0.5, decay=0.996):
    """Corda dedilhada (Karplus-Strong)."""
    f = midi(note); n = int(dur*SR); p = max(2, int(SR/f))
    exc = np.zeros(n); exc[:p] = lp(rng.uniform(-1, 1, p*4), 1500 + 6000*brilho)[-p:]
    from scipy.signal import lfilter
    den = np.zeros(p + 2); den[0] = 1; den[p] = -decay*0.5; den[p+1] = -decay*0.5
    out = lfilter([1.0], den, exc)
    out[:int(0.003*SR)] *= np.linspace(0, 1, int(0.003*SR))
    return out * vel
def strum(notas, dur, vel=1.0, atraso=0.012, brilho=0.55, decay=0.997):
    out = np.zeros(int((dur + atraso*len(notas))*SR))
    for i, n in enumerate(notas): place(out, ks(n, dur, vel/len(notas)**0.5, brilho, decay), i*atraso)
    return out
def madeira(f=900, dur=0.06):
    t = t_(dur); x = np.sin(2*np.pi*f*t) * expdec(len(t), 0.012) + bp(rng.standard_normal(len(t)), f, f*3) * expdec(len(t), 0.004) * 0.6
    return x
def chorus(x):
    d = (0.012 + 0.003*np.sin(2*np.pi*0.8*np.arange(len(x))/SR)) * SR
    idx = np.clip(np.arange(len(x)) - d, 0, len(x)-1).astype(int)
    return np.vstack([x + 0.5*x[idx], x + 0.5*x[np.clip(idx - 40, 0, len(x)-1)]])

def efeitos():
    E = {}
    E['button-hover'] = (hp(madeira(2200, 0.04), 800), -24)
    t = t_(0.08); f = 520*np.exp(-t/0.02) + 260
    ck = np.sin(2*np.pi*np.cumsum(f)/SR) * expdec(len(t), 0.018); place(ck, madeira(1800, 0.06)*0.5, 0)
    E['button-click'] = (ck, -11)
    a = np.zeros(int(0.5*SR)); place(a, whoosh(0.18, 600, 4000, 0.5)*0.4, 0); place(a, ks(76, 0.4, 0.8, 0.7), 0.08); place(a, ks(83, 0.4, 0.8, 0.7), 0.14)
    E['menu-open'] = (mono_reverb(a, 0.25, 0.6, 0.5), -13)
    c = np.zeros(int(0.5*SR)); place(c, whoosh(0.16, 4000, 600, 0.5)*0.4, 0); place(c, ks(79, 0.35, 0.8, 0.5), 0.06); place(c, ks(72, 0.35, 0.8, 0.5), 0.12)
    E['menu-close'] = (mono_reverb(c, 0.2, 0.5, 0.4), -14)
    tr = np.zeros(int(1.1*SR))
    rev = whoosh(0.5, 200, 7000, 0.7) * np.linspace(0, 1, int(0.5*SR))**2
    place(tr, rev*0.8, 0)
    boom = np.sin(2*np.pi*np.cumsum(40 + 70*np.exp(-t_(0.6)/0.06))/SR) * expdec(int(0.6*SR), 0.18)
    place(tr, softclip(boom*1.4, 1.3)*0.8, 0.48); place(tr, strum([62, 66, 69, 74], 0.6, 0.6, 0.008), 0.49)
    E['page-transition'] = (mono_reverb(tr, 0.4, 1.4, 1.1), -9)
    E['select'] = (mono_reverb(ks(81, 0.3, 1, 0.8), 0.15, 0.4, 0.3), -15)
    b = np.zeros(int(0.6*SR)); place(b, whoosh(0.3, 5000, 300, 0.6)*0.6, 0); place(b, ks(74, 0.3, 0.9, 0.5), 0.2); place(b, ks(69, 0.35, 0.9, 0.4), 0.27)
    E['navigate-back'] = (mono_reverb(b, 0.25, 0.6, 0.5), -11)
    mo = np.zeros(int(0.9*SR)); sw = lp(S.saw(midi(57), t_(0.5)) + S.saw(midi(64), t_(0.5)), 1200) * env_adsr(int(0.5*SR), 0.25, 0.1, 0.5, 0.15) * 0.2
    place(mo, sw, 0); place(mo, strum([69, 73, 76, 81], 0.6, 0.5, 0.02, 0.7), 0.18)
    E['modal-open'] = (mono_reverb(mo, 0.45, 1.2, 0.9), -14)
    cf = np.zeros(int(0.9*SR)); place(cf, ks(78, 0.6, 1, 0.8), 0); place(cf, ks(85, 0.7, 1, 0.85), 0.07)
    E['confirm'] = (mono_reverb(chorus(cf)[0], 0.35, 1.0, 0.8), -9)
    ca = lp(ks(57, 0.3, 1, 0.3, 0.99), 1500); place(ca, madeira(500, 0.06)*0.3, 0)
    E['cancel'] = (ca, -16)
    su = np.zeros(int(1.6*SR))
    for i, n in enumerate((62, 66, 69, 73, 74, 78)): place(su, ks(n, 1.0, 0.8, 0.75), i*0.055)
    place(su, S.fm_bell(90, 0.8, 0.15, 3.0, 1.0, 0.4), 0.33)
    E['success'] = (mono_reverb(su, 0.4, 1.6, 1.3), -8)
    dl = np.zeros(int(0.9*SR))
    for i in range(2):
        tt = t_(0.18); x = softclip(S.sq(midi(52), tt, 0.4) * env_adsr(len(tt), 0.005, 0.05, 0.7, 0.05), 2.0)
        place(dl, lp(x, 1800), i*0.22)
    E['delete'] = (mono_reverb(dl, 0.25, 0.6, 0.5), -12)
    er = np.zeros(int(0.8*SR))
    for i, n in enumerate((50, 49)):
        tt = t_(0.22); x = (S.sq(midi(n), tt, 0.3) + S.sq(midi(n)*1.012, tt, 0.3)) * env_adsr(len(tt), 0.004, 0.05, 0.8, 0.06)
        place(er, softclip(lp(x, 1400), 1.6), i*0.17)
    place(er, bp(rng.standard_normal(int(0.25*SR)), 300, 2000) * expdec(int(0.25*SR), 0.06) * 0.3, 0)
    E['error'] = (mono_reverb(er, 0.15, 0.5, 0.4), -10)
    nt = np.zeros(int(1.0*SR)); place(nt, S.marimba(83, 0.5, 1), 0); place(nt, S.marimba(88, 0.6, 1), 0.12); place(nt, S.marimba(95, 0.5, 0.4), 0.24)
    E['notification'] = (mono_reverb(nt, 0.35, 0.9, 0.7), -11)
    ld = np.zeros(int(1.0*SR))
    for i in range(10): place(ld, madeira(1200 + i*90, 0.05) * (0.4 + i/16), i*0.07)
    place(ld, ks(86, 0.4, 0.8, 0.8), 0.72)
    E['loading'] = (mono_reverb(ld, 0.2, 0.5, 0.4), -13)
    L = np.zeros(int(4.0*SR))
    sw = whoosh(1.5, 150, 8000, 0.4) * np.linspace(0, 1, int(1.5*SR))**2.5
    place(L, sw*0.6, 0)
    hit = np.sin(2*np.pi*np.cumsum(36 + 90*np.exp(-t_(2.2)/0.07))/SR) * expdec(int(2.2*SR), 0.7)
    place(L, softclip(hit*1.7, 1.6)*0.9, 1.45)
    place(L, strum([50, 57, 62, 66, 69, 74], 2.4, 1.6, 0.03, 0.7, 0.9985), 1.47)
    place(L, S.pad([62, 66, 69, 73], 2.4, 1.0, 2200)[0]*1.5, 1.5)
    E['login'] = (mono_reverb(L, 0.55, 2.6, 2.4, 6000), -6)
    return E

# ------------------------------------------------------------- faixa retrô opcional
def faixa_retro(bpm=82, bars=28):
    """Rock suave retrô: guitarras dedilhadas, piano elétrico, baixo e bateria leve (progressão D–Bm–G–A)."""
    beat = 60/bpm; bar = beat*4; total = bars*bar + 4; n = int(total*SR)
    gtr = np.zeros(n); keys = np.zeros((2, n)); bass = np.zeros(n); dr = np.zeros(n)
    prog = [([50, 57, 62, 66, 69, 74], 38), ([47, 54, 59, 62, 66, 71], 35), ([43, 50, 55, 59, 62, 67], 31), ([45, 52, 57, 61, 64, 69], 33)]
    padrao = [0, 1, 2, 3, 4, 3, 2, 1]
    for b in range(bars):
        t0 = b*bar; notas, raiz = prog[(b//2) % 4]
        intro = b < 4; fim = b >= bars - 3
        for s, idx in enumerate(padrao):  # dedilhado em colcheias
            place(gtr, ks(notas[idx] + 12*(s == 4), beat*1.6, 0.42 if intro else 0.36, 0.5), t0 + s*beat/2)
        if not intro and not fim:
            for k in (0, 2):
                place(keys, S.rhodes(notas[2:5], beat*1.8, 0.35), t0 + k*beat + beat/2)
            for off, d in ((0, 1.5), (1.5, 0.5), (2, 1.5), (3.5, 0.5)):
                place(bass, S.sub_bass(raiz - 12 + (7 if off == 3.5 else 0), d*beat*0.95, 0.8), t0 + off*beat)
            for s in range(8):
                tt = t0 + s*beat/2
                if s in (0, 5): place(dr, S.kick(0.8), tt)
                if s in (2, 6): place(dr, S.snare(0.45), tt)
                place(dr, S.hat(0.09 if s % 2 else 0.13), tt)
        if b % 4 == 3 and not intro and not fim:  # pequena frase de guitarra (melodia original)
            for i, (pos, nn) in enumerate(((0, 78), (0.5, 76), (1, 74), (2, 76), (2.5, 81))):
                place(gtr, ks(nn, beat*1.2, 0.5, 0.75), t0 + pos*beat)
    warble = 1 + 0.0015*np.sin(2*np.pi*0.5*np.arange(n)/SR)  # leve oscilação de fita
    idx = np.clip((np.arange(n) * warble).astype(int), 0, n-1); gtr = gtr[idx]
    ir = reverb_ir(2.4, 2.0, 5000, 9)
    def nivel(x, alvo): r = rms_db(x); return x * 10**((alvo - r)/20) if r > -100 else x
    mix = nivel(reverb(chorus(gtr), 0.35, ir), -18) + nivel(reverb(keys, 0.4, ir), -24) + nivel(pan(bass, 0), -21) + nivel(pan(dr, 0), -22)
    mix = np.vstack([hp(mix[0], 30), hp(mix[1], 30)])
    mix = softclip(normalize(mix, -1)*1.15, 1.1)
    f = int(1.5*SR); mix[:, :f] *= np.linspace(0, 1, f); mix[:, -int(3*SR):] *= np.linspace(1, 0, int(3*SR))
    return normalize(mix, -3)

if __name__ == '__main__':
    out = sys.argv[1]
    os.makedirs(f'{out}/ui', exist_ok=True); os.makedirs(f'{out}/music', exist_ok=True)
    for nome, (x, db) in efeitos().items():
        x = trim(normalize(x, db)); to_mp3(x, f'{out}/ui/{nome}.mp3')
        print(f'ui/{nome}.mp3 {len(x)/SR:.2f}s rms {rms_db(x):.1f}')
    x = faixa_retro(); to_mp3(x, f'{out}/music/vice-city-ambient.mp3', stereo=True, kbps=160)
    print(f'music/vice-city-ambient.mp3 {x.shape[1]/SR:.1f}s rms {rms_db(x):.1f}')
