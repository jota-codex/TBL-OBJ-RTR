using System;
using System.IO;
using System.Linq;
using ViceCityCentral.Data;
using ViceCityCentral.Exceptions;

namespace ViceCityCentral.Services
{
    /// <summary>
    /// Copia as imagens escolhidas pelo usuário para a pasta do aplicativo
    /// (Assets/Images/Uploads/...) e resolve caminhos relativos gravados no banco.
    /// </summary>
    public static class ImagemService
    {
        public static readonly string[] ExtensoesPermitidas = { ".png", ".jpg", ".jpeg", ".bmp", ".gif" };
        public const long TamanhoMaximoBytes = 10L * 1024 * 1024; // 10 MB

        public const string FiltroDialogo = "Imagens (*.png;*.jpg;*.jpeg;*.bmp;*.gif)|*.png;*.jpg;*.jpeg;*.bmp;*.gif";

        /// <summary>Converte um caminho gravado no banco em caminho absoluto.</summary>
        public static string? ResolverCaminho(string? caminho)
        {
            if (string.IsNullOrWhiteSpace(caminho)) return null;
            string normalizado = caminho!.Replace('\\', Path.DirectorySeparatorChar).Replace('/', Path.DirectorySeparatorChar);
            return Path.IsPathRooted(normalizado) ? normalizado : Path.Combine(DatabaseConnection.PastaAplicacao, normalizado);
        }

        public static bool Existe(string? caminho)
        {
            string? absoluto = ResolverCaminho(caminho);
            return absoluto != null && File.Exists(absoluto);
        }

        /// <summary>Valida a imagem escolhida (extensão, tamanho e existência).</summary>
        public static void Validar(string origem)
        {
            if (!File.Exists(origem))
                throw new ValidacaoException("O arquivo de imagem selecionado não foi encontrado.");
            string ext = Path.GetExtension(origem).ToLowerInvariant();
            if (!ExtensoesPermitidas.Contains(ext))
                throw new ValidacaoException("Formato de imagem não suportado. Use PNG, JPG, BMP ou GIF.");
            if (new FileInfo(origem).Length > TamanhoMaximoBytes)
                throw new ValidacaoException("A imagem deve ter no máximo 10 MB.");
        }

        /// <summary>Copia a imagem para a pasta do sistema e devolve o caminho relativo a ser gravado.</summary>
        public static string Importar(string origem, string subpasta)
        {
            Validar(origem);
            string relativoPasta = Path.Combine("Assets", "Images", "Uploads", subpasta);
            string pastaDestino = Path.Combine(DatabaseConnection.PastaAplicacao, relativoPasta);
            Directory.CreateDirectory(pastaDestino);

            string nomeArquivo = $"{DateTime.Now:yyyyMMddHHmmss}_{Guid.NewGuid().ToString("N").Substring(0, 8)}{Path.GetExtension(origem).ToLowerInvariant()}";
            File.Copy(origem, Path.Combine(pastaDestino, nomeArquivo), overwrite: false);

            // Gravamos com "/" para o caminho funcionar em qualquer sistema.
            return Path.Combine(relativoPasta, nomeArquivo).Replace('\\', '/');
        }
    }
}
