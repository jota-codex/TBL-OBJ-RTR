using System.Reflection;

namespace ViceCityCentral.Services
{
    /// <summary>Informações institucionais exibidas na tela de Configurações.</summary>
    public static class AppInfo
    {
        public const string Nome = "Vice City Central";
        public const string Subtitulo = "GTA VI Management System";
        public const string Disciplina = "Programação Orientada a Objetos I";
        public const string Projeto = "Projeto Final de POO I";

        public const string Descricao =
            "Central administrativa inspirada no universo de Grand Theft Auto VI. Permite gerenciar personagens, " +
            "veículos, missões e localidades de Vice City e do estado de Leonida, com banco de dados SQLite, " +
            "operações CRUD completas, validações e dashboard com indicadores em tempo real.";

        /// <summary>
        /// Integrantes do grupo (até 5). Edite esta lista com os nomes e RAs da equipe.
        /// </summary>
        public static readonly string[] Desenvolvedores =
        {
            "Integrante 1 — Nome Sobrenome (RA 000000)",
            "Integrante 2 — Nome Sobrenome (RA 000000)",
            "Integrante 3 — Nome Sobrenome (RA 000000)"
        };

        public static readonly string[] Tecnologias =
        {
            "C# 12 / .NET 8 (Windows Forms)",
            "SQLite (Microsoft.Data.Sqlite)",
            "ADO.NET com consultas parametrizadas",
            "Ícones: Material Design Icons (Apache 2.0)"
        };

        public const string AvisoLegal =
            "Projeto acadêmico sem fins lucrativos. Grand Theft Auto, GTA VI, Vice City e Leonida são marcas da " +
            "Rockstar Games / Take-Two Interactive. As ilustrações do sistema são artes originais criadas para este projeto.";

        public static string Versao
        {
            get
            {
                var v = Assembly.GetExecutingAssembly().GetName().Version;
                return v == null || (v.Major == 0 && v.Minor == 0) ? "1.0.0" : $"{v.Major}.{v.Minor}.{v.Build}";
            }
        }
    }
}
