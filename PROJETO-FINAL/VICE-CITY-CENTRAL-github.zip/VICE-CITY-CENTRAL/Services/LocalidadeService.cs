using System;
using System.Collections.Generic;
using System.Linq;
using ViceCityCentral.Exceptions;
using ViceCityCentral.Models;
using ViceCityCentral.Repositories;

namespace ViceCityCentral.Services
{
    public class LocalidadeService : ServiceBase<Localidade>
    {
        private readonly LocalidadeRepository _repo;

        public LocalidadeService() : this(new LocalidadeRepository()) { }
        public LocalidadeService(LocalidadeRepository repo) : base(repo) { _repo = repo; }

        public List<Localidade> Pesquisar(FiltroLocalidade filtro) => _repo.Pesquisar(filtro);

        /// <summary>Regiões cadastradas + regiões sugeridas, sem repetição, em ordem alfabética.</summary>
        public List<string> ListarRegioes()
            => _repo.ListarRegioes()
                .Concat(Localidade.RegioesSugeridas)
                .Where(r => !string.IsNullOrWhiteSpace(r))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(r => r, StringComparer.CurrentCultureIgnoreCase)
                .ToList();

        protected override void ValidarRegrasNegocio(Localidade l, List<string> erros)
        {
            if (_repo.ExisteNome(l.Nome, l.Id))
                erros.Add($"Já existe uma localidade chamada \"{l.Nome}\".");
        }

        protected override void VerificarPossibilidadeExclusao(Localidade l)
        {
            int missoes = _repo.ContarMissoesVinculadas(l.Id);
            if (missoes > 0)
                throw new RegraNegocioException(
                    $"\"{l.Nome}\" está vinculada a {missoes} missão(ões).\n" +
                    "Altere ou exclua essas missões antes de excluir a localidade.");
        }
    }
}
