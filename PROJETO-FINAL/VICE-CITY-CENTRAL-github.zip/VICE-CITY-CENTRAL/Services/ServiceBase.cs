using System;
using System.Collections.Generic;
using System.Linq;
using ViceCityCentral.Exceptions;
using ViceCityCentral.Models;
using ViceCityCentral.Repositories;

namespace ViceCityCentral.Services
{
    /// <summary>
    /// Regras de negócio comuns a todos os cadastros.
    /// Fluxo de gravação: validação da entidade → regras específicas (duplicidade, vínculos) → repositório.
    /// </summary>
    public abstract class ServiceBase<T> where T : EntidadeBase
    {
        protected ServiceBase(IRepository<T> repositorio)
        {
            Repositorio = repositorio ?? throw new ArgumentNullException(nameof(repositorio));
        }

        protected IRepository<T> Repositorio { get; }

        public List<T> ObterTodos() => Repositorio.ObterTodos();

        public T? ObterPorId(int id) => Repositorio.ObterPorId(id);

        public int Contar() => Repositorio.Contar();

        /// <summary>Insere ou atualiza o registro.</summary>
        /// <returns>true quando o registro foi criado; false quando foi atualizado.</returns>
        public bool Salvar(T entidade)
        {
            if (entidade == null) throw new ArgumentNullException(nameof(entidade));

            var erros = entidade.Validar().ToList();
            if (erros.Count == 0) ValidarRegrasNegocio(entidade, erros);
            if (erros.Count > 0) throw new ValidacaoException(erros);

            if (entidade.EhNovo)
            {
                Repositorio.Inserir(entidade);
                return true;
            }

            Repositorio.Atualizar(entidade);
            return false;
        }

        /// <summary>Exclui o registro, desde que as regras de exclusão permitam.</summary>
        public void Excluir(T entidade)
        {
            if (entidade == null) throw new ArgumentNullException(nameof(entidade));
            if (entidade.EhNovo) throw new RegraNegocioException("Selecione um registro salvo para excluir.");
            VerificarPossibilidadeExclusao(entidade);
            Repositorio.Excluir(entidade.Id);
        }

        /// <summary>Regras específicas (ex.: duplicidade). Adicione mensagens à lista de erros.</summary>
        protected abstract void ValidarRegrasNegocio(T entidade, List<string> erros);

        /// <summary>Por padrão, qualquer registro pode ser excluído. Classes derivadas podem impedir.</summary>
        protected virtual void VerificarPossibilidadeExclusao(T entidade) { }
    }
}
