using System.Collections.Generic;
using System.Linq;
using ViceCityCentral.Models;
using ViceCityCentral.Repositories;

namespace ViceCityCentral.Services
{
    /// <summary>Dados consolidados exibidos no Dashboard.</summary>
    public class ResumoDashboard
    {
        public int TotalPersonagens { get; set; }
        public int TotalVeiculos { get; set; }
        public int TotalMissoes { get; set; }
        public int TotalLocalidades { get; set; }
        public int MissoesConcluidas { get; set; }
        public int MissoesPendentes { get; set; }
        public int PersonagensProcurados { get; set; }
        public Dictionary<CategoriaVeiculo, int> VeiculosPorCategoria { get; set; } = new Dictionary<CategoriaVeiculo, int>();
        public Dictionary<StatusMissao, int> MissoesPorStatus { get; set; } = new Dictionary<StatusMissao, int>();

        /// <summary>Lista polimórfica: personagens, veículos, missões e localidades juntos.</summary>
        public List<EntidadeBase> UltimosRegistros { get; set; } = new List<EntidadeBase>();
    }

    public class DashboardService
    {
        private readonly PersonagemRepository _personagens = new PersonagemRepository();
        private readonly VeiculoRepository _veiculos = new VeiculoRepository();
        private readonly MissaoRepository _missoes = new MissaoRepository();
        private readonly LocalidadeRepository _localidades = new LocalidadeRepository();

        public ResumoDashboard ObterResumo(int quantidadeUltimos = 8)
        {
            var porStatus = _missoes.ContarPorStatus();

            var resumo = new ResumoDashboard
            {
                TotalPersonagens = _personagens.Contar(),
                TotalVeiculos = _veiculos.Contar(),
                TotalMissoes = _missoes.Contar(),
                TotalLocalidades = _localidades.Contar(),
                VeiculosPorCategoria = _veiculos.ContarPorCategoria(),
                MissoesPorStatus = porStatus,
                MissoesConcluidas = porStatus[StatusMissao.Concluida],
                MissoesPendentes = porStatus[StatusMissao.Disponivel] + porStatus[StatusMissao.EmAndamento],
                PersonagensProcurados = _personagens.Pesquisar(new FiltroPersonagem { Status = StatusPersonagem.Procurado }).Count
            };

            // Junta os últimos registros de cada tabela e ordena pela data de cadastro.
            var todos = new List<EntidadeBase>();
            todos.AddRange(_personagens.ObterUltimos(quantidadeUltimos));
            todos.AddRange(_veiculos.ObterUltimos(quantidadeUltimos));
            todos.AddRange(_missoes.ObterUltimos(quantidadeUltimos));
            todos.AddRange(_localidades.ObterUltimos(quantidadeUltimos));
            resumo.UltimosRegistros = todos
                .OrderByDescending(e => e.DataCadastro)
                .ThenByDescending(e => e.Id)
                .Take(quantidadeUltimos)
                .ToList();

            return resumo;
        }
    }
}
