using System;
using System.Collections.Generic;
using System.Globalization;
using ViceCityCentral.Models;
using ViceCityCentral.Repositories;

namespace ViceCityCentral.Services
{
    /// <summary>
    /// Carrega/salva as preferências do usuário. Mantém uma instância atual em memória
    /// e avisa a interface quando as configurações mudam (evento).
    /// </summary>
    public class ConfiguracaoService
    {
        private static ConfiguracaoService? _instancia;
        private readonly ConfiguracaoRepository _repo = new ConfiguracaoRepository();

        public static ConfiguracaoService Instancia => _instancia ??= new ConfiguracaoService();

        public Configuracoes Atual { get; private set; } = Configuracoes.Padrao();

        /// <summary>Disparado sempre que as configurações forem salvas ou restauradas.</summary>
        public event EventHandler? ConfiguracoesAlteradas;

        public Configuracoes Carregar()
        {
            var valores = _repo.CarregarTodas();
            var padrao = Configuracoes.Padrao();
            Atual = new Configuracoes
            {
                NomeOperador = Ler(valores, nameof(Configuracoes.NomeOperador), padrao.NomeOperador),
                ExibirSegundosRelogio = LerBool(valores, nameof(Configuracoes.ExibirSegundosRelogio), padrao.ExibirSegundosRelogio),
                AtualizarDashboardAutomaticamente = LerBool(valores, nameof(Configuracoes.AtualizarDashboardAutomaticamente), padrao.AtualizarDashboardAutomaticamente),
                DestacarLinhasAlternadas = LerBool(valores, nameof(Configuracoes.DestacarLinhasAlternadas), padrao.DestacarLinhasAlternadas),
                ExibirNotificacoesSucesso = LerBool(valores, nameof(Configuracoes.ExibirNotificacoesSucesso), padrao.ExibirNotificacoesSucesso),
                IntervaloAtualizacaoSegundos = LerInt(valores, nameof(Configuracoes.IntervaloAtualizacaoSegundos), padrao.IntervaloAtualizacaoSegundos)
            };
            return Atual;
        }

        public void Salvar(Configuracoes config)
        {
            var valores = new Dictionary<string, string>
            {
                [nameof(Configuracoes.NomeOperador)] = config.NomeOperador,
                [nameof(Configuracoes.ExibirSegundosRelogio)] = config.ExibirSegundosRelogio.ToString(),
                [nameof(Configuracoes.AtualizarDashboardAutomaticamente)] = config.AtualizarDashboardAutomaticamente.ToString(),
                [nameof(Configuracoes.DestacarLinhasAlternadas)] = config.DestacarLinhasAlternadas.ToString(),
                [nameof(Configuracoes.ExibirNotificacoesSucesso)] = config.ExibirNotificacoesSucesso.ToString(),
                [nameof(Configuracoes.IntervaloAtualizacaoSegundos)] = config.IntervaloAtualizacaoSegundos.ToString(CultureInfo.InvariantCulture)
            };
            _repo.SalvarTodas(valores);
            Atual = config;
            ConfiguracoesAlteradas?.Invoke(this, EventArgs.Empty);
        }

        public Configuracoes RestaurarPadrao()
        {
            Salvar(Configuracoes.Padrao());
            return Atual;
        }

        /// <summary>Notifica a interface sem gravar (ex.: após restaurar o banco).</summary>
        public void NotificarAlteracao() => ConfiguracoesAlteradas?.Invoke(this, EventArgs.Empty);

        private static string Ler(Dictionary<string, string> v, string chave, string padrao)
            => v.TryGetValue(chave, out string? s) && !string.IsNullOrWhiteSpace(s) ? s : padrao;

        private static bool LerBool(Dictionary<string, string> v, string chave, bool padrao)
            => v.TryGetValue(chave, out string? s) && bool.TryParse(s, out bool b) ? b : padrao;

        private static int LerInt(Dictionary<string, string> v, string chave, int padrao)
            => v.TryGetValue(chave, out string? s) && int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out int i) ? i : padrao;
    }
}
