using System;
using System.Collections.Generic;
using System.Linq;
using ViceCityCentral.Exceptions;
using ViceCityCentral.Models;
using ViceCityCentral.Repositories;

namespace ViceCityCentral.Services
{
    public class MissaoService : ServiceBase<Missao>
    {
        private readonly MissaoRepository _repo;
        private readonly PersonagemRepository _personagens;
        private readonly LocalidadeRepository _localidades;

        public MissaoService() : this(new MissaoRepository(), new PersonagemRepository(), new LocalidadeRepository()) { }

        public MissaoService(MissaoRepository repo, PersonagemRepository personagens, LocalidadeRepository localidades)
            : base(repo)
        {
            _repo = repo;
            _personagens = personagens;
            _localidades = localidades;
        }

        public List<Missao> Pesquisar(FiltroMissao filtro) => _repo.Pesquisar(filtro);

        public Dictionary<StatusMissao, int> ContarPorStatus() => _repo.ContarPorStatus();

        public List<Personagem> ListarPersonagens() => _personagens.ObterTodos();
        public List<Localidade> ListarLocalidades() => _localidades.ObterTodos();

        protected override void ValidarRegrasNegocio(Missao m, List<string> erros)
        {
            if (_repo.ExisteNome(m.Nome, m.Id))
                erros.Add($"Já existe uma missão chamada \"{m.Nome}\".");
            if (m.PersonagemId.HasValue && _personagens.ObterPorId(m.PersonagemId.Value) == null)
                erros.Add("O personagem selecionado não existe mais. Atualize a lista.");
            if (m.LocalidadeId.HasValue && _localidades.ObterPorId(m.LocalidadeId.Value) == null)
                erros.Add("A localidade selecionada não existe mais. Atualize a lista.");
        }
    }
}
