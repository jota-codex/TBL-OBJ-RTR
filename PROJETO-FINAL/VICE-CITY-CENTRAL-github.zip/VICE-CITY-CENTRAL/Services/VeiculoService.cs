using System;
using System.Collections.Generic;
using System.Linq;
using ViceCityCentral.Exceptions;
using ViceCityCentral.Models;
using ViceCityCentral.Repositories;

namespace ViceCityCentral.Services
{
    public class VeiculoService : ServiceBase<Veiculo>
    {
        private readonly VeiculoRepository _repo;

        public VeiculoService() : this(new VeiculoRepository()) { }
        public VeiculoService(VeiculoRepository repo) : base(repo) { _repo = repo; }

        public List<Veiculo> Pesquisar(FiltroVeiculo filtro) => _repo.Pesquisar(filtro);

        public Dictionary<CategoriaVeiculo, int> ContarPorCategoria() => _repo.ContarPorCategoria();

        protected override void ValidarRegrasNegocio(Veiculo v, List<string> erros)
        {
            if (_repo.ExisteVeiculo(v.Fabricante, v.Nome, v.Modelo, v.Id))
                erros.Add($"O veículo \"{v.Fabricante} {v.Nome} ({v.Modelo})\" já está registrado.");
        }
    }
}
