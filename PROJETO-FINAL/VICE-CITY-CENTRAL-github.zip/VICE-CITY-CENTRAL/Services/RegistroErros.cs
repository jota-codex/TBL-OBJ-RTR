using System;
using System.IO;
using ViceCityCentral.Data;

namespace ViceCityCentral.Services
{
    /// <summary>Grava erros inesperados em logs/erros.log (ajuda no diagnóstico).</summary>
    public static class RegistroErros
    {
        public static string CaminhoLog => Path.Combine(DatabaseConnection.PastaAplicacao, "logs", "erros.log");

        public static void Registrar(Exception ex)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(CaminhoLog)!);
                File.AppendAllText(CaminhoLog, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex}{Environment.NewLine}{Environment.NewLine}");
            }
            catch
            {
                // o log nunca deve derrubar a aplicação
            }
        }
    }
}
