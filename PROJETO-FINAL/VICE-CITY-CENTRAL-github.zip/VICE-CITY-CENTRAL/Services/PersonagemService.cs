using System;
using System.Collections.Generic;
using System.Linq;
using ViceCityCentral.Exceptions;
using ViceCityCentral.Models;
using ViceCityCentral.Repositories;

namespace ViceCityCentral.Services
{
    public class PersonagemService : ServiceBase<Personagem>
    {
        private readonly PersonagemRepository _repo;

        public PersonagemService() : this(new PersonagemRepository()) { }
        public PersonagemService(PersonagemRepository repo) : base(repo) { _repo = repo; }

        public List<Personagem> Pesquisar(FiltroPersonagem filtro) => _repo.Pesquisar(filtro);

        protected override void ValidarRegrasNegocio(Personagem p, List<string> erros)
        {
            if (_repo.ExisteNomeCompleto(p.Nome, p.Sobrenome, p.Id))
                erros.Add($"Já existe um personagem chamado \"{p.NomeCompleto}\".");
        }

        protected override void VerificarPossibilidadeExclusao(Personagem p)
        {
            int missoes = _repo.ContarMissoesVinculadas(p.Id);
            if (missoes > 0)
                throw new RegraNegocioException(
                    $"\"{p.NomeCompleto}\" está vinculado(a) a {missoes} missão(ões).\n" +
                    "Altere ou exclua essas missões antes de excluir o personagem.");
        }
    }
}
