using System;
using System.Data.Common;
using System.IO;
using System.Text;
using ViceCityCentral.Exceptions;

namespace ViceCityCentral.Data
{
    /// <summary>
    /// Cria o banco de dados na primeira execução, a partir do script Database/vice_city.sql
    /// (estrutura + dados iniciais), e permite restaurar o banco ao estado original.
    /// </summary>
    public static class DatabaseInitializer
    {
        public const string NomeScript = "vice_city.sql";

        private static readonly string[] TabelasObrigatorias = { "Personagens", "Localidades", "Veiculos", "Missoes", "Configuracoes" };

        public static string CaminhoScript => Path.Combine(DatabaseConnection.PastaAplicacao, "Database", NomeScript);

        /// <summary>Garante que o banco exista e possua todas as tabelas.</summary>
        /// <returns>true se o banco foi criado agora.</returns>
        public static bool Inicializar()
        {
            bool existe = File.Exists(DatabaseConnection.CaminhoBanco);
            if (existe && EstruturaCompleta()) return false;

            if (existe)
            {
                // Arquivo existe mas está incompleto/corrompido: recria do zero.
                ApagarArquivoBanco();
            }

            ExecutarScript(LerScript());
            return true;
        }

        /// <summary>Apaga o banco atual e recria com os dados iniciais.</summary>
        public static void RestaurarBancoPadrao()
        {
            string script = LerScript(); // lê antes de apagar: se faltar o script, nada é perdido
            ApagarArquivoBanco();
            ExecutarScript(script);
        }

        private static bool EstruturaCompleta()
        {
            using (var conexao = DatabaseConnection.Abrir())
            {
                foreach (string tabela in TabelasObrigatorias)
                {
                    using (var cmd = conexao.CreateCommand())
                    {
                        cmd.CommandText = "SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = @nome;";
                        var p = cmd.CreateParameter();
                        p.ParameterName = "@nome";
                        p.Value = tabela;
                        cmd.Parameters.Add(p);
                        if (Convert.ToInt32(cmd.ExecuteScalar()) == 0) return false;
                    }
                }
            }
            return true;
        }

        private static string LerScript()
        {
            if (!File.Exists(CaminhoScript))
                throw new DatabaseException(
                    $"O script de criação do banco não foi encontrado em:\n{CaminhoScript}\n\n" +
                    "Verifique se a pasta Database foi copiada junto com o executável.");
            return File.ReadAllText(CaminhoScript, Encoding.UTF8);
        }

        private static void ExecutarScript(string script)
        {
            try
            {
                using (var conexao = DatabaseConnection.Abrir())
                using (DbTransaction transacao = conexao.BeginTransaction())
                {
                    using (var cmd = conexao.CreateCommand())
                    {
                        cmd.Transaction = transacao;
                        cmd.CommandText = script;
                        cmd.ExecuteNonQuery();
                    }
                    transacao.Commit();
                }
            }
            catch (DbException ex)
            {
                throw new DatabaseException("Falha ao criar a estrutura do banco de dados: " + ex.Message, ex);
            }
        }

        private static void ApagarArquivoBanco()
        {
            DatabaseConnection.LiberarConexoes();
            try
            {
                if (File.Exists(DatabaseConnection.CaminhoBanco)) File.Delete(DatabaseConnection.CaminhoBanco);
            }
            catch (IOException ex)
            {
                throw new DatabaseException("O arquivo do banco está em uso e não pôde ser substituído. Feche outros programas que o utilizem.", ex);
            }
        }
    }
}
