using System;
using System.Data.Common;
using System.Globalization;

namespace ViceCityCentral.Data
{
    /// <summary>Leitura segura e tipada das colunas retornadas pelo SQLite.</summary>
    public static class DataReaderExtensions
    {
        public const string FormatoData = "yyyy-MM-dd HH:mm:ss";

        public static string Texto(this DbDataReader r, string coluna)
        {
            object v = r[coluna];
            return v == DBNull.Value ? string.Empty : Convert.ToString(v, CultureInfo.InvariantCulture) ?? string.Empty;
        }

        public static string? TextoOuNulo(this DbDataReader r, string coluna)
        {
            object v = r[coluna];
            return v == DBNull.Value ? null : Convert.ToString(v, CultureInfo.InvariantCulture);
        }

        public static int Inteiro(this DbDataReader r, string coluna)
        {
            object v = r[coluna];
            return v == DBNull.Value ? 0 : Convert.ToInt32(v, CultureInfo.InvariantCulture);
        }

        public static int? InteiroOuNulo(this DbDataReader r, string coluna)
        {
            object v = r[coluna];
            return v == DBNull.Value ? (int?)null : Convert.ToInt32(v, CultureInfo.InvariantCulture);
        }

        public static decimal Decimal(this DbDataReader r, string coluna)
        {
            object v = r[coluna];
            return v == DBNull.Value ? 0m : Convert.ToDecimal(v, CultureInfo.InvariantCulture);
        }

        public static DateTime Data(this DbDataReader r, string coluna)
        {
            object v = r[coluna];
            if (v is DateTime dt) return dt;
            string texto = v == DBNull.Value ? string.Empty : Convert.ToString(v, CultureInfo.InvariantCulture) ?? string.Empty;
            if (DateTime.TryParseExact(texto, FormatoData, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime exata))
                return exata;
            return DateTime.TryParse(texto, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime livre)
                ? livre
                : DateTime.Now;
        }

        public static string ParaBanco(this DateTime data) => data.ToString(FormatoData, CultureInfo.InvariantCulture);
    }
}
