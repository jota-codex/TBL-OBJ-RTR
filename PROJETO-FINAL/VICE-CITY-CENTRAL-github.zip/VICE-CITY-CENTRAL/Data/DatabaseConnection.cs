using System;
using System.Data.Common;
using System.IO;
using ViceCityCentral.Exceptions;
#if MONO
using SqliteConnection = Mono.Data.Sqlite.SqliteConnection;
#else
using SqliteConnection = Microsoft.Data.Sqlite.SqliteConnection;
#endif

namespace ViceCityCentral.Data
{
    /// <summary>
    /// Responsável por localizar o arquivo do banco e abrir conexões SQLite.
    /// Toda conexão aberta ativa a verificação de chaves estrangeiras.
    /// </summary>
    public static class DatabaseConnection
    {
        public const string NomeArquivo = "vice_city.db";

        private static string? _caminhoPersonalizado;

        /// <summary>Pasta base do aplicativo (onde fica o executável).</summary>
        public static string PastaAplicacao => AppDomain.CurrentDomain.BaseDirectory;

        /// <summary>Caminho completo do arquivo .db.</summary>
        public static string CaminhoBanco =>
            _caminhoPersonalizado ?? Path.Combine(PastaAplicacao, "Database", NomeArquivo);

        /// <summary>Permite apontar para outro arquivo (usado em testes automatizados).</summary>
        public static void DefinirCaminho(string? caminho) => _caminhoPersonalizado = caminho;

        public static string StringConexao => $"Data Source={CaminhoBanco}";

        /// <summary>Abre uma nova conexão. Quem chama é responsável por descartá-la (using).</summary>
        public static DbConnection Abrir()
        {
            try
            {
                string? pasta = Path.GetDirectoryName(CaminhoBanco);
                if (!string.IsNullOrEmpty(pasta)) Directory.CreateDirectory(pasta);

                var conexao = new SqliteConnection(StringConexao);
                conexao.Open();
                using (var cmd = conexao.CreateCommand())
                {
                    cmd.CommandText = "PRAGMA foreign_keys = ON;";
                    cmd.ExecuteNonQuery();
                }
                return conexao;
            }
            catch (Exception ex) when (ex is DbException || ex is IOException || ex is UnauthorizedAccessException)
            {
                throw new DatabaseException(
                    $"Não foi possível conectar ao banco de dados.\nArquivo: {CaminhoBanco}\nDetalhe: {ex.Message}", ex);
            }
        }

        /// <summary>Libera conexões mantidas em pool (necessário antes de apagar o arquivo).</summary>
        public static void LiberarConexoes()
        {
#if !MONO
            SqliteConnection.ClearAllPools();
#endif
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        /// <summary>Testa rapidamente se o banco está acessível.</summary>
        public static bool TestarConexao(out string mensagem)
        {
            try
            {
                using (var conexao = Abrir())
                using (var cmd = conexao.CreateCommand())
                {
                    cmd.CommandText = "SELECT sqlite_version();";
                    mensagem = "SQLite " + Convert.ToString(cmd.ExecuteScalar());
                    return true;
                }
            }
            catch (Exception ex)
            {
                mensagem = ex.Message;
                return false;
            }
        }
    }
}
