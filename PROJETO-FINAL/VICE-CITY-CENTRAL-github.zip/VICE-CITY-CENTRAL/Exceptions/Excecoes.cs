using System;
using System.Collections.Generic;
using System.Linq;

namespace ViceCityCentral.Exceptions
{
    /// <summary>Lançada quando os dados informados não passam nas validações.</summary>
    public class ValidacaoException : Exception
    {
        public ValidacaoException(IEnumerable<string> erros)
            : base("Existem campos inválidos ou não preenchidos.")
        {
            Erros = erros.ToList();
        }

        public ValidacaoException(string erro) : this(new[] { erro }) { }

        public IReadOnlyList<string> Erros { get; }
    }

    /// <summary>Lançada quando uma operação viola uma regra de negócio (ex.: duplicidade, vínculo).</summary>
    public class RegraNegocioException : Exception
    {
        public RegraNegocioException(string mensagem) : base(mensagem) { }
    }

    /// <summary>Encapsula falhas de acesso ao banco com mensagens compreensíveis ao usuário.</summary>
    public class DatabaseException : Exception
    {
        public DatabaseException(string mensagem, Exception? interna = null) : base(mensagem, interna) { }
    }
}
