-- =====================================================================
--  VICE CITY CENTRAL – GTA VI MANAGEMENT SYSTEM
--  Script de criação do banco de dados SQLite (estrutura + dados iniciais)
--
--  Este arquivo é executado automaticamente pelo DatabaseInitializer
--  na primeira execução do sistema (ou ao restaurar o banco).
--  Também pode ser executado manualmente:
--      sqlite3 vice_city.db < vice_city.sql
--
--  Observação: as chaves estrangeiras só são verificadas pelo SQLite quando
--  "PRAGMA foreign_keys = ON;" está ativo na conexão (o sistema faz isso
--  automaticamente em toda conexão aberta).
--
--  Os personagens, veículos e locais são inspirados no universo de GTA VI.
--  Idades, descrições, números e missões são ilustrativos/fictícios.
-- =====================================================================

-- ---------------------------------------------------------------------
--  TABELA: Personagens
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Personagens (
    Id             INTEGER PRIMARY KEY AUTOINCREMENT,
    Nome           TEXT    NOT NULL CHECK (length(trim(Nome)) > 0),
    Sobrenome      TEXT    NOT NULL CHECK (length(trim(Sobrenome)) > 0),
    Idade          INTEGER NOT NULL CHECK (Idade BETWEEN 1 AND 120),
    Genero         TEXT    NOT NULL DEFAULT 'NaoInformado'
                           CHECK (Genero IN ('Masculino','Feminino','NaoBinario','NaoInformado')),
    Profissao      TEXT    NOT NULL,
    Nacionalidade  TEXT    NOT NULL,
    Descricao      TEXT    NOT NULL DEFAULT '',
    Status         TEXT    NOT NULL DEFAULT 'Ativo'
                           CHECK (Status IN ('Ativo','Inativo','Procurado')),
    ImagemPath     TEXT    NULL,
    DataCadastro   TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE (Nome COLLATE NOCASE, Sobrenome COLLATE NOCASE)
);

-- ---------------------------------------------------------------------
--  TABELA: Localidades
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Localidades (
    Id             INTEGER PRIMARY KEY AUTOINCREMENT,
    Nome           TEXT    NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(Nome)) > 0),
    Regiao         TEXT    NOT NULL,
    Tipo           TEXT    NOT NULL DEFAULT 'Bairro'
                           CHECK (Tipo IN ('Bairro','Praia','Comercio','AreaResidencial','AreaIndustrial',
                                           'PontoTuristico','RegiaoRural','Outros')),
    Descricao      TEXT    NOT NULL DEFAULT '',
    NivelPerigo    TEXT    NOT NULL DEFAULT 'Baixo'
                           CHECK (NivelPerigo IN ('Baixo','Moderado','Alto','Extremo')),
    Status         TEXT    NOT NULL DEFAULT 'Liberada'
                           CHECK (Status IN ('Liberada','Restrita','Interditada')),
    ImagemPath     TEXT    NULL,
    DataCadastro   TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

-- ---------------------------------------------------------------------
--  TABELA: Veiculos
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Veiculos (
    Id               INTEGER PRIMARY KEY AUTOINCREMENT,
    Nome             TEXT    NOT NULL CHECK (length(trim(Nome)) > 0),
    Fabricante       TEXT    NOT NULL,
    Modelo           TEXT    NOT NULL,
    Categoria        TEXT    NOT NULL
                             CHECK (Categoria IN ('CarroEsportivo','Supercarro','Motocicleta','Caminhonete',
                                                  'SUV','Barco','Aeronave','Outros')),
    Ano              INTEGER NOT NULL CHECK (Ano >= 1900),
    Cor              TEXT    NOT NULL,
    VelocidadeMaxima INTEGER NOT NULL CHECK (VelocidadeMaxima > 0),
    Tipo             TEXT    NOT NULL DEFAULT 'Terrestre'
                             CHECK (Tipo IN ('Terrestre','Aquatico','Aereo')),
    Status           TEXT    NOT NULL DEFAULT 'Disponivel'
                             CHECK (Status IN ('Disponivel','EmUso','Apreendido')),
    ImagemPath       TEXT    NULL,
    DataCadastro     TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE (Fabricante COLLATE NOCASE, Nome COLLATE NOCASE, Modelo COLLATE NOCASE)
);

-- ---------------------------------------------------------------------
--  TABELA: Missoes  (relaciona-se com Personagens e Localidades)
--  ON DELETE RESTRICT: não é possível excluir um personagem/localidade
--  que ainda possua missões vinculadas (integridade referencial).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Missoes (
    Id             INTEGER PRIMARY KEY AUTOINCREMENT,
    Nome           TEXT    NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(Nome)) > 0),
    Descricao      TEXT    NOT NULL DEFAULT '',
    PersonagemId   INTEGER NULL REFERENCES Personagens(Id) ON UPDATE CASCADE ON DELETE RESTRICT,
    LocalidadeId   INTEGER NULL REFERENCES Localidades(Id) ON UPDATE CASCADE ON DELETE RESTRICT,
    Categoria      TEXT    NOT NULL
                           CHECK (Categoria IN ('Principal','Secundaria','Corrida','Investigacao','Desafio','Especial')),
    Dificuldade    TEXT    NOT NULL
                           CHECK (Dificuldade IN ('Facil','Media','Dificil','Extrema')),
    Recompensa     REAL    NOT NULL DEFAULT 0 CHECK (Recompensa >= 0),
    Status         TEXT    NOT NULL DEFAULT 'Disponivel'
                           CHECK (Status IN ('Disponivel','EmAndamento','Concluida','Cancelada')),
    DataCadastro   TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE INDEX IF NOT EXISTS IX_Missoes_PersonagemId ON Missoes (PersonagemId);
CREATE INDEX IF NOT EXISTS IX_Missoes_LocalidadeId ON Missoes (LocalidadeId);
CREATE INDEX IF NOT EXISTS IX_Missoes_Status       ON Missoes (Status);
CREATE INDEX IF NOT EXISTS IX_Veiculos_Categoria   ON Veiculos (Categoria);

-- ---------------------------------------------------------------------
--  TABELA: Configuracoes  (preferências do aplicativo, chave/valor)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Configuracoes (
    Chave  TEXT PRIMARY KEY,
    Valor  TEXT NOT NULL
);

-- =====================================================================
--  DADOS INICIAIS
-- =====================================================================

-- Personagens (inspirados nos personagens divulgados de GTA VI; dados ilustrativos)
INSERT INTO Personagens (Id, Nome, Sobrenome, Idade, Genero, Profissao, Nacionalidade, Descricao, Status, ImagemPath, DataCadastro) VALUES
 (1, 'Lucia', 'Caminos', 27, 'Feminino', 'Ex-detenta / criminosa', 'Estadunidense (Leonida)',
  'Recém-saída da Penitenciária de Leonida, é determinada, estratégica e não foge de uma briga. Forma uma dupla com Jason em busca de uma vida melhor em Vice City.',
  'Procurado', 'Assets/Images/Personagens/lucia_caminos.png', '2026-10-01 09:00:00'),
 (2, 'Jason', 'Duval', 30, 'Masculino', 'Ex-militar / motorista', 'Estadunidense',
  'Cresceu cercado de golpistas e criminosos. Depois de servir no exército, passou a fazer trabalhos para traficantes nas Leonida Keys. Parceiro de Lucia.',
  'Procurado', 'Assets/Images/Personagens/jason_duval.png', '2026-10-01 09:05:00'),
 (3, 'Cal', 'Hampton', 38, 'Masculino', 'Teórico da conspiração', 'Estadunidense',
  'Amigo e parceiro de Jason. Prefere ficar em casa monitorando a rádio da polícia e desconfia de tudo e de todos.',
  'Ativo', 'Assets/Images/Personagens/cal_hampton.png', '2026-10-02 10:15:00'),
 (4, 'Boobie', 'Ike', 45, 'Masculino', 'Empresário', 'Estadunidense (Vice City)',
  'Lenda local de Vice City. Dono de imóveis, de um clube e de um estúdio de gravação; sabe transformar dinheiro sujo em negócios legítimos.',
  'Ativo', 'Assets/Images/Personagens/boobie_ike.png', '2026-10-02 11:30:00'),
 (5, 'Dre''Quan', 'Priest', 34, 'Masculino', 'Produtor musical', 'Estadunidense',
  'Fundador da gravadora Only Raw Records. Sempre em busca do próximo grande talento de Vice City.',
  'Ativo', 'Assets/Images/Personagens/drequan_priest.png', '2026-10-03 14:00:00'),
 (6, 'Bae-Luxe', 'Dimez', 25, 'Feminino', 'Rapper (Real Dimez)', 'Estadunidense (Vice City)',
  'Metade da dupla de rap Real Dimez, que faz sucesso nas redes sociais de Vice City.',
  'Ativo', 'Assets/Images/Personagens/bae_luxe.png', '2026-10-03 14:20:00'),
 (7, 'Roxy', 'Dimez', 25, 'Feminino', 'Rapper (Real Dimez)', 'Estadunidense (Vice City)',
  'Amiga de infância de Bae-Luxe e a outra metade da dupla Real Dimez.',
  'Ativo', 'Assets/Images/Personagens/roxy_dimez.png', '2026-10-03 14:25:00'),
 (8, 'Raul', 'Bautista', 50, 'Masculino', 'Assaltante de bancos', 'Estrangeiro',
  'Assaltante experiente, carismático e disposto a correr riscos cada vez maiores por um bom golpe.',
  'Procurado', 'Assets/Images/Personagens/raul_bautista.png', '2026-10-04 08:45:00'),
 (9, 'Brian', 'Heder', 58, 'Masculino', 'Contrabandista', 'Estadunidense',
  'Veterano do contrabando nas Leonida Keys. Dá trabalho a Jason em troca de "favores" e de um teto para morar.',
  'Inativo', 'Assets/Images/Personagens/brian_heder.png', '2026-10-04 09:10:00');

-- Localidades de Vice City e do estado de Leonida
INSERT INTO Localidades (Id, Nome, Regiao, Tipo, Descricao, NivelPerigo, Status, ImagemPath, DataCadastro) VALUES
 (1, 'Downtown Vice City', 'Vice City', 'Comercio',
  'Centro financeiro com arranha-céus, bancos e joalherias. Muito policiamento durante o dia.',
  'Alto', 'Liberada', 'Assets/Images/Localidades/downtown.png', '2026-10-01 08:00:00'),
 (2, 'Vice Beach', 'Vice City', 'Praia',
  'Orla famosa por letreiros neon, hotéis art déco, festas e turistas o ano inteiro.',
  'Moderado', 'Liberada', 'Assets/Images/Localidades/vice_beach.png', '2026-10-01 08:10:00'),
 (3, 'Little Havana', 'Vice City', 'Bairro',
  'Bairro tradicional com cafés, comércio local e muita música nas ruas.',
  'Moderado', 'Liberada', 'Assets/Images/Localidades/little_havana.png', '2026-10-01 08:20:00'),
 (4, 'Starfish Island', 'Vice City', 'AreaResidencial',
  'Ilha de mansões à beira-mar habitada por celebridades e empresários.',
  'Baixo', 'Restrita', 'Assets/Images/Localidades/starfish_island.png', '2026-10-01 08:30:00'),
 (5, 'Porto de Vice City', 'Vice City', 'AreaIndustrial',
  'Terminal de contêineres e armazéns. Ponto estratégico para cargas que não aparecem em nenhum registro.',
  'Alto', 'Liberada', 'Assets/Images/Localidades/porto.png', '2026-10-01 08:40:00'),
 (6, 'Leonida Keys', 'Leonida Keys', 'PontoTuristico',
  'Arquipélago de ilhas com águas cristalinas, marinas e esconderijos de contrabandistas.',
  'Moderado', 'Liberada', 'Assets/Images/Localidades/leonida_keys.png', '2026-10-01 08:50:00'),
 (7, 'Grassrivers', 'Grassrivers', 'RegiaoRural',
  'Pântanos extensos repletos de jacarés, aerobarcos e laboratórios clandestinos.',
  'Extremo', 'Restrita', 'Assets/Images/Localidades/grassrivers.png', '2026-10-01 09:00:00'),
 (8, 'Port Gellhorn', 'Port Gellhorn', 'AreaIndustrial',
  'Cidade portuária decadente, com motéis baratos, estaleiros e muitos segredos.',
  'Alto', 'Liberada', 'Assets/Images/Localidades/port_gellhorn.png', '2026-10-01 09:10:00'),
 (9, 'Ambrosia', 'Ambrosia', 'AreaIndustrial',
  'Polo agroindustrial dominado por uma grande refinaria de açúcar e por gangues de motociclistas.',
  'Alto', 'Interditada', 'Assets/Images/Localidades/ambrosia.png', '2026-10-01 09:20:00'),
 (10, 'Mount Kalaga National Park', 'Mount Kalaga', 'RegiaoRural',
  'Parque nacional com trilhas, rios e acampamentos. Ideal para quem precisa sumir por uns dias.',
  'Moderado', 'Liberada', 'Assets/Images/Localidades/mount_kalaga.png', '2026-10-01 09:30:00');

-- Veículos (fabricantes fictícios do universo GTA)
INSERT INTO Veiculos (Id, Nome, Fabricante, Modelo, Categoria, Ano, Cor, VelocidadeMaxima, Tipo, Status, ImagemPath, DataCadastro) VALUES
 (1,  'Cheetah Classic', 'Grotti',      'CC-87',      'Supercarro',     1987, 'Vermelho',        298, 'Terrestre', 'Disponivel', 'Assets/Images/Veiculos/cheetah_classic.png', '2026-10-05 10:00:00'),
 (2,  'Infernus',        'Pegassi',     'Coupé V12',  'Supercarro',     2025, 'Rosa neon',       322, 'Terrestre', 'EmUso',      'Assets/Images/Veiculos/infernus.png',        '2026-10-05 10:10:00'),
 (3,  'Dominator GT',    'Vapid',       'GT Convers.', 'CarroEsportivo', 2024, 'Azul-turquesa',   265, 'Terrestre', 'Disponivel', 'Assets/Images/Veiculos/dominator_gt.png',    '2026-10-05 10:20:00'),
 (4,  'Banshee',         'Bravado',     '900R',       'CarroEsportivo', 2023, 'Branco perolado', 280, 'Terrestre', 'Apreendido', 'Assets/Images/Veiculos/banshee.png',         '2026-10-05 10:30:00'),
 (5,  'PCJ-600',         'Shitzu',      'Sport 600',  'Motocicleta',    2022, 'Preto',           230, 'Terrestre', 'Disponivel', 'Assets/Images/Veiculos/pcj600.png',          '2026-10-05 10:40:00'),
 (6,  'Bagger',          'Western',     'Touring',    'Motocicleta',    2021, 'Grafite',         180, 'Terrestre', 'EmUso',      'Assets/Images/Veiculos/bagger.png',          '2026-10-05 10:50:00'),
 (7,  'Bison',           'Bravado',     'Cabine Dupla','Caminhonete',   2024, 'Prata',           175, 'Terrestre', 'Disponivel', 'Assets/Images/Veiculos/bison.png',           '2026-10-05 11:00:00'),
 (8,  'Granger',         'Declasse',    '3600LX',     'SUV',            2025, 'Preto fosco',     190, 'Terrestre', 'EmUso',      'Assets/Images/Veiculos/granger.png',         '2026-10-05 11:10:00'),
 (9,  'Squalo',          'Shitzu',      'Lancha 32',  'Barco',          2024, 'Lilás',            95, 'Aquatico',  'Disponivel', 'Assets/Images/Veiculos/squalo.png',          '2026-10-05 11:20:00'),
 (10, 'Maverick',        'Buckingham',  'Heli M-2',   'Aeronave',       2023, 'Branco e roxo',   260, 'Aereo',     'Apreendido', 'Assets/Images/Veiculos/maverick.png',        '2026-10-05 11:30:00');

-- Missões (fictícias) vinculadas a personagens e localidades
INSERT INTO Missoes (Id, Nome, Descricao, PersonagemId, LocalidadeId, Categoria, Dificuldade, Recompensa, Status, DataCadastro) VALUES
 (1,  'Saída da Penitenciária', 'Buscar Lucia na saída da Penitenciária de Leonida e levá-la a um esconderijo seguro.', 2, NULL, 'Principal', 'Facil', 5000, 'Concluida', '2026-10-06 09:00:00'),
 (2,  'Golpe na Loja de Conveniência', 'Primeiro trabalho da dupla: render o caixa de uma loja de conveniência sem chamar atenção.', 1, 3, 'Principal', 'Media', 12000, 'Concluida', '2026-10-06 10:00:00'),
 (3,  'Carga no Porto', 'Interceptar um contêiner suspeito no Porto de Vice City antes da chegada da polícia.', 2, 5, 'Principal', 'Dificil', 85000, 'EmAndamento', '2026-10-07 13:00:00'),
 (4,  'Corrida da Orla Neon', 'Vencer a corrida clandestina que atravessa a orla de Vice Beach à meia-noite.', 1, 2, 'Corrida', 'Media', 25000, 'Disponivel', '2026-10-08 22:00:00'),
 (5,  'Frequências Suspeitas', 'Ajudar Cal a decifrar transmissões estranhas captadas na rádio da polícia.', 3, NULL, 'Investigacao', 'Facil', 3000, 'Concluida', '2026-10-09 15:00:00'),
 (6,  'Clipe em Starfish Island', 'Garantir a segurança da gravação do novo clipe das Real Dimez em uma mansão alugada.', 6, 4, 'Secundaria', 'Media', 18000, 'Disponivel', '2026-10-10 11:00:00'),
 (7,  'Lavagem no Estúdio', 'Organizar a contabilidade "criativa" do estúdio de Boobie Ike.', 4, 1, 'Secundaria', 'Dificil', 40000, 'EmAndamento', '2026-10-11 16:00:00'),
 (8,  'Travessia das Keys', 'Levar uma encomenda de Brian de lancha entre as ilhas sem ser abordado pela guarda costeira.', 9, 6, 'Desafio', 'Dificil', 30000, 'Cancelada', '2026-10-12 07:30:00'),
 (9,  'O Grande Golpe', 'Planejar com Raul o assalto ao principal banco de Downtown Vice City.', 8, 1, 'Especial', 'Extrema', 750000, 'Disponivel', '2026-10-13 20:00:00'),
 (10, 'Pântano Silencioso', 'Localizar um laboratório clandestino escondido em Grassrivers.', 2, 7, 'Investigacao', 'Extrema', 60000, 'Concluida', '2026-10-14 05:45:00');

-- Preferências padrão
INSERT INTO Configuracoes (Chave, Valor) VALUES
 ('NomeOperador', 'Operador'),
 ('ExibirSegundosRelogio', 'True'),
 ('AtualizarDashboardAutomaticamente', 'True'),
 ('DestacarLinhasAlternadas', 'True'),
 ('ExibirNotificacoesSucesso', 'True'),
 ('IntervaloAtualizacaoSegundos', '30');
